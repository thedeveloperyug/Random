#include<iostream>
#include<cstring>

class UnderflowException : public std::exception
{
    char message[50];

    public:
    UnderflowException() { }
    UnderflowException(const char *p)
    {
        strcpy(message,p);
    }
    char * getMessage()
    {
        return message;
    }
};

class OverflowException : public std::exception
{
    char  mess[50];

    public:
    OverflowException() { }
    OverflowException(const char *ptr)
    {
        strcpy(mess,ptr);
    }
    char * getmess()
    {
        return mess;
    }
};

class Account
{
    int balance;
    public:
    Account()
    {
        balance = 5000;
    }
    Account(int b)
    {
        balance = b;
    }
    void withdraw(int amt)
    {
        if(balance-amt < 5000)
        {
            // throw "Minimum balace is less than 5000";
            // throw -1111;
            throw UnderflowException("Minimum balance should 5000");
        }
        else
        {
            balance -=amt;
            std::cout<<"\n Done";
        }
    }
    void deposite(int amt)
    {
        if(balance+amt > 20000)
        {
            // throw "Minimum balace is less than 5000";
            // throw -1111;
            throw OverflowException("Maximum balance should 20000");
        }
        else
        {
            balance +=amt;
            std::cout<<"\n Done";
        }
    }

};

int main()
{
    Account obj(15000);
    try
    {
        // obj.withdraw(36000);
        obj.deposite(10000);
    }

    catch (UnderflowException obj)
    {
        std::cout<<obj.getMessage()<<std::endl;
    }
    catch (OverflowException obj)
    {
        std::cout<<obj.getmess()<<std::endl;
    }
    catch (const char* msg)
    {
        std::cout<<msg<<std::endl;
    }
    catch (float ele)
    {
        std::cout<<"Minimum balance 50000"<<std::endl;
    }
    // catch (int ele)
    // {
    //     std::cout<<"Minimum balance 50000"<<std::endl;
    // }
    catch (std::string msg)
    {
        std::cout<<msg<<std::endl;
    }
    catch(...)  //Generic catch block , It will catch any data type
    {
        std::cout<<"\n Some error"<<std::endl;
    }



    return 0;
}