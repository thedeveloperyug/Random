#include<iostream>

//template function

template<class T>  //it will include in all functions whenever we defiene from outside the class.

// void exchange(int &a,int &b)
// {

// }

void exchange(T &a,T &b)
{
    T temp;
    temp = a;
    a = b;
    b =temp;
}


int main()
{
    int x=10,y=20;
    exchange(x,y);
    std::cout<<x<<" "<<y<<std::endl;

    double d1=10.44,d2=5.66;
    exchange(d1,d2);
    std::cout<<d1<<" "<<d2<<std::endl;

    int p=3,q=9;
}