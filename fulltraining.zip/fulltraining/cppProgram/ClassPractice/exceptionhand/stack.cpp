#include<iostream>
#include<cstring>

class UnderflowException : public std::exception
{
    char message[50];

    public:
    UnderflowException() { }
    UnderflowException(const char *p)
    {
        strcpy(message,p);
    }
    char * getMessage()
    {
        return message;
    }
};

class OverflowException : public std::exception
{
    char  message[50];

    public:
    OverflowException() { }
    OverflowException(const char *ptr)
    {
        strcpy(message,ptr);
    }
    char * getmessage()
    {
        return message;
    }
};


class Mystack
{
    int *arr;
    int size,top;
    public:
    Mystack()
    {
        size=2;
        top=-1;
        arr=new int[size];
    }
    Mystack(int s)
    {
        size=s;
        top=-1;
        arr=new int[size];
    }
    bool isFull()
    {
        return top==size-1;
    }
    bool isEmpty()
    {
        return top==-1;
    }
    void push(int ele)
    {
        if(!isFull())
        {
            arr[++top] = ele;

        }
        else
        throw OverflowException("Stack is Full");
    }
    int pop()
    {
        if(!isEmpty())
           return arr[top--];
        else
           throw UnderflowException("Stack is Empty");
    }
};

int main()
{
    Mystack s1;
    try
    {
        s1.push(10);
        s1.push(20);
        s1.push(30);
    }
    catch (OverflowException e)
    {
        std::cerr << e.getmessage()<<std::endl;
    }
    
    try
    {
            s1.pop();
            s1.pop();
            s1.pop();

    }
    catch(UnderflowException e)
    {
        std::cerr << e.what() << '\n';
    }
    
}