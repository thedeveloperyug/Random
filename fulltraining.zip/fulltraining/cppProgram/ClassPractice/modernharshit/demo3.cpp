#include <iostream>

// STATICALLY TYPE LANGUAGE!

enum Department
{
    IT,
    HR,
    ADMIN
};

class Project
{
    private:
    std::string _car;
    int _carid;
    public:

    Project(std::string car,int carid);
    ~Project();
};

/*
   IS A - INHERITANCE
   HAS A - COMPOSITION/AGGRIGATION
*/


class Employee
{
private:
   int _id;
   std::string _name;
   Department _dept;
   Project* _empProject;

public:
    Employee(int id,std::string name,Department dep,Project* pr)
: _id(id),_name(name),_dept(dep),_empProject(pr)
{}
    ~Employee() {}
};

Employee::Employee(int id,std::string name,Department dep,Project* pr)
: _id(id),_name(name),_dept(dep),_empProject(pr)
{
}

Employee::~Employee()
{
}



int main()
{
    Project* p1 = new Project("BMW CHASIS",11101);
    Employee* e1 = new Employee(
        101,
        "Shiavm",
        Department::IT,
        p1

    );

    Project* p2 = new Project("HONDA CHASIS",12101);
    Employee* e2 = new Employee(
        123,
        "ROHAN",
        Department::IT,
        p2

    );

    Employee* arr[2] = {e1, e2}

}