#include<iostream>

/*
   Magic takes  1 integer pointer and returns an integer pointer The function should read the input
   parameter number.
   Calculate it's square and store it in a different location than input.

   data-type& Create a reference
   &variable-name : a pointer
*/

int *magic(int* ptr)
{
    int number = (*ptr); //dereference ptr and store in number.

    int ans = number * number;

    return &ans;   //???  When we have to return the address then we can take the pointer as function.
}