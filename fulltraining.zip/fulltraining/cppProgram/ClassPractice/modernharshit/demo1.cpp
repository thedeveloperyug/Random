#include<iostream>

// magic function take  one parameter and return void

// void magic(int number)
// {
//     std::cout<<" Address of number: "<<&number<<std::endl;
//     std::cout<<"Value of number: "<<number<<std::endl;
// }

/*
   magic function that takes one integer reference and returns void
*/
void magic(int &number)
{
    std::cout<<" Address of number: "<<&number<<std::endl;
    std::cout<<"Value of number: "<<number<<std::endl;
}

int main()
{
    //* Anything in the stack is called atomated storage.
    
    int n1=10;  //Anything which you give the name is L-value, R-values are temporaries value(or does not have any address in the RAM).


    // magic(n1);

    // std::cout<<"Address of n1 in main: "<<&n1<<std::endl;
    // std::cout<< "Value of n1 is: "<<n1<<std::endl;

    magic(n1);

    std::cout<<"Address of n1 in main: "<<&n1<<std::endl;
    std::cout<< "Value of n1 is: "<<n1<<std::endl;
}