#include<iostream>
#include "cricket.h"
#include "batsman.h"

int main()
{
     Batsman player(777,"Dhoni",38,Playerclass::BOWLER,200,12000,40.0,150);
    
     player.display();

    return 0;
}