#include<iostream>
#include "cricket.h"

// class Cricketer
// {
//     int playerId;
//     std::string playername;
//     int age;
    
// }
// class Batsman : virtual public Cricketer
// {
// };
// class Bowler : virtual public Cricketer
// {
// };
// class AllRounder:public  Batsman,Bowler 
// {
// }


Cricketer::Cricketer(int pId=0, std::string pName="Null", int age1=0,Playerclass pClass=Playerclass::BATSMAN, int matchNo=0)
 :playerId(pId),playername(pName),age(age1),playerClass(pClass),no_ofMatches(matchNo)
{

}
std::string Cricketer::getPlayerC(Playerclass pc)
{
    switch(pc)
    {
        case Playerclass::BATSMAN:
           return "BATSMAN";
           break;
        case Playerclass::BOWLER:
           return "BOWLER";
           break;
        case Playerclass::ALLROUNDER:
           return "ALLROUNDER";
           break;
        default:
           return "BATSMAN";
           break;
    }
    
}

void Cricketer::display()
{
    std::cout<<std::endl;
    std::cout<<"Player Id: "<<playerId<<std::endl;
    std::cout<<"Player Name: "<<playername<<std::endl;
    std::cout<<"Age: "<<age<<std::endl;
    std::cout<<"Player Class: "<<getPlayerC(playerClass)<<std::endl;
    std::cout<<"Number of Matches: "<<no_ofMatches<<std::endl;
}

