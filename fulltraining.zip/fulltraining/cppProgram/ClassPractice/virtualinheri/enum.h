#ifndef ENUM_H
#define ENUM_H

#include<iostream>

enum Playerclass
{
    BATSMAN,
    BOWLER,
    ALLROUNDER
};

#endif // ENUM_H
