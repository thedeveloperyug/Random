#ifndef BOLWER_H
#define BOLWER_H

#include<iostream>
#include "cricket.h"

class Bolwer : virtual public Cricketer
{
    int wickets;
    float economy;
    int dotBall;
    float avgSpeed;

    public:
    Bolwer();
    Bolwer(int,float,int,float);
    void display();

};

#endif // BOLWER_H
