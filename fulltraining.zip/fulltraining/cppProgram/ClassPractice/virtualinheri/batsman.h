#ifndef BATSMAN_H
#define BATSMAN_H

#include<iostream>
#include "cricket.h"

class Batsman : public  Cricketer
{
    int runs;
    float avg;
    int number_ofSix;
    public:
    Batsman();
    Batsman(int, std::string, int,Playerclass,int,int,float,int);
    void display();

};

#endif // BATSMAN_H
