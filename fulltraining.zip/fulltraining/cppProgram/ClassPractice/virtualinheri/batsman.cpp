#include<iostream>
#include "batsman.h"

Batsman::Batsman(int pId=0, std::string pName="Null", int age1=0,Playerclass pClass=Playerclass::BATSMAN, int matchNo=0,int run=0, float average=0, int six=0)
:Cricketer(pId,pName,age1,pClass,matchNo)
{
    runs=run;
    avg=average;
    number_ofSix=six;
}

void Batsman::display()
{
    Cricketer::display();
    std::cout<<"Runs= "<<runs<<std::endl;
    std::cout<<"Average= "<<avg<<std::endl;
    std::cout<<"Six= "<<number_ofSix<<std::endl;
}
