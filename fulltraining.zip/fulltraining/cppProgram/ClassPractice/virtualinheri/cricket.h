#ifndef CRICKET_H
#define CRICKET_H

#include <iostream>
#include "enum.h"

class Cricketer
{
    int playerId;
    std::string playername;
    int age;
    enum Playerclass playerClass;
    int no_ofMatches;

public:
    Cricketer();
    Cricketer(int, std::string, int,Playerclass,int);
    virtual void display();
    std::string getPlayerC(Playerclass);

    enum Playerclass getPlayerClass() const;
    void setPlayerClass(const enum Playerclass &playerClass_) { playerClass = playerClass_; }
};

#endif // CRICKET_H
