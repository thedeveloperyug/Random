#include<iostream>
#include "header.h"

Employee::Employee()
{
    // std::cout<<"\nConstructor Called for Employee"<<std::endl;
    empid = 1011;
    ename = "Jay";
    basicsalary = 25000;
    calculateAllowance();
    etype = EmployeeType::INTERN;
}
Employee::Employee(int eid,std::string enam,double salary, EmployeeType et)
 : empid(eid), ename(enam),basicsalary(salary),etype(et)
{
    calculateAllowance();
}
Employee::~Employee()
{
    // std::cout<<"\nDestructor Called for Employee"<<std::endl;
}

void Employee::accept()
{
    //Accept
    std::cout<<"Enter Employee id: ";
    std::cin>>empid;
    std::cout<<"Enter Employee name: ";
    std::cin>>ename;
    std::cout<<"Enter Basic Salary of employee (in Rs): ";
    std::cin>>basicsalary;

    int ecat;
    std::cout<<"Enter value for Employee type: 1.PARMANENT 2.TEMP 3.INTERN "<<std::endl;
    std::cin>>ecat;
    switch(ecat)
    {
        case 1:
        etype = EmployeeType::PARMANENT;
        break;
        case 2:
        etype = EmployeeType::TEMP;
        break;
        case 3:
        etype = EmployeeType::INTERN;
        break;
        default:
        break;


    }
}
std::string getEmptype(EmployeeType et)
{
    if(et==EmployeeType::PARMANENT)
    return "PARMANENT";
    else if(et == EmployeeType::TEMP )
    return "TEMPORARY";
    else if(et == EmployeeType::INTERN)
    return "INTERN";
    else
    return "";
}
void Employee::display()
{
    std::cout<<"\n Employee id = "<<empid;
    std::cout<<"\n Employee id = "<<ename;
    std::cout<<"\n Employee id = "<<basicsalary;
    std::cout<<"\n Employee id = "<<getEmptype(etype);
}
double Employee::calculateTotalSalary()
{
    return basicsalary+houserantlelowance+medicalAllownce-professionalTax-providentFund;
}