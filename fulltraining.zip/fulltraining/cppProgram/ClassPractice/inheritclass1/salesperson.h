#ifndef SELSPERSON_H
#define SELSPERSON_H

#include<iostream>
#include "header.h"

//public: inherting selsperson class from Employee class in public mode
//mode of inheritance


class Salesperson : public Employee
{
    double salesamount , commissionrate;

    public:
        Salesperson();
        Salesperson(int eid,std::string enam,double salary, EmployeeType et,double samount,double comi);
        ~Salesperson();
        void calculateCommision();
        void display();
};

#endif // SELSPERSON_H
