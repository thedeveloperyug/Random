#include<iostream>

enum EmployeeType
{
    PARMANENT,
    TEMP,
    INTERN
}; 