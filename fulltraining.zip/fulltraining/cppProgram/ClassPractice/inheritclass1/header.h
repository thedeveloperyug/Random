#ifndef HEADER_H
#define HEADER_H

#include <iostream>
#include "enum.h"

class Employee
{
protected:
    double basicsalary;

private:
    int empid;
    std::string ename;
    double houserantlelowance, medicalAllownce, professionalTax, providentFund;
    enum EmployeeType etype;

    void calculateAllowance()
    {
        houserantlelowance = basicsalary * 0.5;
        medicalAllownce = basicsalary * 0.05;
        professionalTax = 2500;
        providentFund = 1700;
    }

public:
    Employee();
    Employee(int, std::string, double, EmployeeType);
    virtual void accept();
    virtual void display();
    // virtual void fun() =0;   //Pure virtual function, initialized 0 beacause function should not be empty.
    double calculateTotalSalary();
    virtual ~Employee();    //Only distructor can be virtual constructor will not.

    EmployeeType getEtype() const { return etype; }
    void setEtype(const EmployeeType &etype_) { etype = etype_; }

    int getEmpid() const { return empid; }
    void setEmpid(int empid_) { empid = empid_; }

    std::string getEname() const { return ename; }
    void setEname(const std::string &ename_) { ename = ename_; }

    double getBasicsalary() const { return basicsalary; }
    void setBasicsalary(double basicsalary_) { basicsalary = basicsalary_; }
};

#endif // HEADER_H
