#include<iostream>
#include "salesperson.h"

void Salesperson::calculateCommision()
{
    
}
Salesperson::Salesperson()
{
    // std::cout<<"\nSalesperon() called"<<std::endl;
}
Salesperson::Salesperson(int eid,std::string enam,double salary, EmployeeType et,double samount,double comi)
 :Employee(eid,enam,salary,et)
{
salesamount=samount;
commissionrate=comi;
}
Salesperson::~Salesperson()
{
    // std::cout<<"Destructo for Salesperson"<<std::endl;
}
void Salesperson::display()
{
    Employee::display();
    std::cout<<"\n Salesamount= "<<salesamount;
    std::cout<<"\n Commision= "<<commissionrate<<std::endl;;

}
