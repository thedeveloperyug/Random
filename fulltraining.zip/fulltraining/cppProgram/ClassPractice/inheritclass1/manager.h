#ifndef MANAGER_H
#define MANAGER_H

#include<iostream>
#include "header.h"

class Manager : public Employee
{
    int noof_subordinates;
    double incentive;

    public:
    Manager();
    Manager(int, std::string, double,EmployeeType,int,double);
    void accept();
    void display();
    ~Manager();
    double calculateTotalSalary();
    void calculateInsentive();
};

#endif // MANAGER_H
