#include<iostream>
#include "manager.h"

void Manager::calculateInsentive()
{
    
}

Manager::Manager()
{
    noof_subordinates=1;
    incentive=5000;

}

Manager::Manager(int, std::string, double,EmployeeType,int,double)
{

}

void Manager::accept()
{

}

Manager::~Manager()
{

}

double Manager::calculateTotalSalary()
{
    return 0.0;
}
void Manager::display()
{
    std::cout<<"\n Noof_subordinates = "<<noof_subordinates;
    std::cout<<"\n Incentative = "<<incentive<<std::endl;
}
