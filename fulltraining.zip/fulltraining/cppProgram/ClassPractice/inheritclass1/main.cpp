#include <iostream>
#include "header.h"
#include "salesperson.h"
#include "manager.h"

void showdata(Employee *ep)
{
    ep->accept();
    ep->display();
    std::cout<<"\n Total salary = "<<ep->calculateTotalSalary();

    //RTTI - Runtime Time Type Identification
    if(typeid(*ep)==typeid(Salesperson))
    {
    Salesperson *s=dynamic_cast<Salesperson*>(ep);
    if(s!=nullptr)
        s->calculateCommision();
    else
        std::cout<<"\n Tyep caste falied,!!";     
    }
    else if(typeid(*ep)==typeid(Manager))
    {
        Manager *mr = dynamic_cast<Manager*>(ep);
        mr->calculateInsentive();
    }
}
int main()
{
    // showdata(new Employee());

    // showdata(new Manager());
    // showdata(new Salesperson());

    // /****/ Employee e1;  //*** Object will not create beacause it belongs to abstract class.


    Employee *eptr=new Salesperson(1,"aaa",500,EmployeeType::INTERN,4000,0.5);
    eptr->display();
    Salesperson *sp = dynamic_cast<Salesperson *>(eptr);  //By type casting we can access the function of Derived class from Base class pointer/object, Because we don't want to make new pointer type object.
    sp->calculateCommision();

    
    // eptr= new Manager();
    // Manager *mr = dynamic_cast<Manager*>(eptr);
    // mr->calculateInsentive();
    



    // delete eptr;

    // Employee *eptr=new Salesperson(023,"Priya",34000,EmployeeType::PARMANENT,130000,0.03);
    // eptr->display();


    // Manager m1;
    // m1.display();

    Salesperson sp2(2023,"Priya",34000,EmployeeType::PARMANENT,130000,0.03);
    sp2.display();

    // std::cout<<"\n-----Salesperson total salary= "<<sp.calculatesalary;

    // Salesperson *sp = new Salesperson();
    // sp->accept();
    // sp->display();
    // delete sp;

    // Salesperson s1;
    // Employee *e = new Employee();
    // // set the employee details using set functions of class Employee
    // e->accept();
    // e->display();
    // std::cout << "\nTotal salary= " << e->calculateTotalSalary();
    return 0;
}