#include<iostream>
using namespace std;

class Complex
{
    int real,imag;
    public:
    Complex()
    {
        cout<<"This is default constructor"<<endl;
    }
    Complex(int r,int i)
    {
        real=r;
        imag=i;
        
    }
    
    int sum()
    {
        return real+imag;
    }

    Complex  operator+(Complex c2)
    {
        Complex temp;
        temp.real=real+c2.real;
        temp.imag=imag+c2.imag;


        return temp;
    }
    
    Complex operator++()
    {
        ++this->real;
        ++this->imag;
        return *this;  //return reference of c1;
    }
    Complex operator++(int) 
    {
        Complex tempobj=*this;
        real++;
        imag++;
        return tempobj;
    }
    int operator-(Complex c2)
    {
        return this->sum()-c2.sum();
    }
    void display(int S)
    {
        cout<<S<<endl;
    }
    friend void operator<<(std::ostream &os, const Complex &c);
};
void operator<<(std::ostream &os, const Complex &c)
{
    os << c.real << " "<< c.imag;
}

int main()
{
    Complex c1(3,5),c2(4,5),c3;  //,c3
    // (cout << "Before increment: ") ;   // printing before incrementing the object using prefix
    // ((c1).operator++)().display('a');
    // c3=(c1+c2);

    // int m[5]={10,20,30,40,50};
    // Complex s1(m);
    // int ele=s1[2];
    // std::cout<<"\n Element ="<<ele;
    
    c3=c1+c2;
    std::cout<<c3;
    std::cout<<endl;
// std::cout<<(c1+c2)<<std::endl<<(c1-c2)<<std::endl;



    // int Sum_result=(c1+c2);
    // c3.display(Sum_result);


return 0;

}