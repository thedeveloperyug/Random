#include<iostream>
using namespace std;


void swap(int &x,int &y)
{
    int t;
    t=x;
    x=y;
    y=t;

}
class Demo
{
    int p;
    public:
    Demo()
    {
        p=100;
    }
    void show()
    {
        cout<<p<<endl;
    }

};
void print(Demo d2)
{

}
int main()
{
    Demo d1;

    print(d1);


    int a=10;
    int b=20;
    swap(a,b);

    // print(a);

    return 0;
}