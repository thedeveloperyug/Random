#include "player.h"
#include<iostream>

Player::Player()
{
}

void Player::Accept()
{
}

void Player::Display()
{
}
