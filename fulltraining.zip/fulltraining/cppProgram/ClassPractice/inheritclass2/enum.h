#ifndef ENUM_H
#define ENUM_H

#include<iostream>

enum Playerclass
{
    CRICKET,
    FOOTBALL,
    HOCKEY,
    NA
};
#endif // ENUM_H
