#include<iostream>
#include "player.h"

int main()
{
    
}