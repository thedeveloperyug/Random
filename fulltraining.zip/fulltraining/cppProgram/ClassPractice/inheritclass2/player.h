#ifndef HEADER_H
#define HEADER_H

#include <iostream>
#include "enum.h"

class Player
{
    std::string playerName;
    enum Playerclass playerClass;
    char playerGrade;
    int playerNumber;

public:
    Player();  
    void Accept();
    void Display();
    
};

#endif // HEADER_H
