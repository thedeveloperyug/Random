#include<iostream>

// int a=10;
int a[5]={10,20,30,40,50};

int& fun()
{
    // int c=20;
    // return c;   //warning can't return local veriabal..

    // return a;  //-Global veriable can returning.

    return a[2];   // returns reference to memmory of a[2]..
}

int main()
{
    fun()=a[3];  // means back

    // int b=fun();
    // std::cout<<b<<std::endl;
    return 0;
}