#include<iostream>

class Complex
{
    int real,imag;
    public:
    Complex()
    {
        std::cout<<"This is default constructor"<<std::endl;
    }
    Complex(int r,int i)
    {
        real=r;
        imag=i;
        
    }
    void show()
    {
        std::cout<<"\nreal= "<<real<<"\nimag= "<<imag<<std::endl;
    }

};
class SmartClass
{
    Complex *obj;
    public:
    SmartClass()
    {
        obj=new Complex;
    }
    ~SmartClass()
    {
        delete obj;
    } //destructor to delete the object when class goes out of
    Complex *operator->()
    {
        return obj;
    }
    Complex operator*()
    {
        return *obj;  //*obj returning the object of Complex class
    }
};

int main()
{
    SmartClass sm1;
    sm1->show();

    (*sm1).show();   // *sm1 is an object of Complex class that's why using (.)dot operator

}