#include <iostream>
using namespace std;

class Shop
{
    int itemId[100];
    int itemPrice[100];
    int counter;

public:
    Shop()
    {
        counter = 0;
    }
    void displayPrice(void);
    void setPrice(void);
};

void Shop::setPrice(void)
{
    int n;
    cout<<"Enter the Amount of Item you want to Add"<<endl;
    cin>>n;
    for(int i=0;i<n;i++){
    cout << "Enter Id of Your item no: "<<counter+1<< endl;
    cin >> itemId[counter];
    cout << "Enter Price of Your item" << endl;
    cin >> itemPrice[counter];
    counter++;
    }
}
void Shop::displayPrice(void)
{
    for(int i=0;i<counter;i++)
    {
        cout<<"The Price of item with Id "<<itemId[i]<<" is "<<itemPrice[i]<<endl;
    }
}

int main()
{
    Shop dukan;
    dukan.setPrice();
    dukan.displayPrice();

    return 0;
}