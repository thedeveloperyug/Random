#include<iostream>

class Complex
{
    int real;
    int imag;
    public:
    void setNumber(int n1,int n2)
    {
        real = n1;
        imag = n2;
    }
    void displayNumbers()
    {
        std::cout<<"Your number is "<<real<<" + "<<imag<<"i";
    }
};
