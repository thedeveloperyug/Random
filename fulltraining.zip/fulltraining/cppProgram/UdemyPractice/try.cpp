#include<iostream>
#include<vector>
#include<algorithm>

long solve(std::vector<int> arr)
{
    int n=arr.size();
    int count =0;
    for(int i=0;i<n-1;i++)
    {
        int max_so_far = arr[i];
        for(int j=i+1;j<n;j++)
        {
            max_so_far =std::max(max_so_far,arr[j]);
            
            if(arr[i] * arr[j] <= (max_so_far))
            {
                count++;
            }
        }
    }
    return count;
}

int main()
{
    std::vector<int> arr {1,1,2,4,2,5,6,7,5,8};
    std::cout<<"\n"<<solve(arr)<<std::endl;
}