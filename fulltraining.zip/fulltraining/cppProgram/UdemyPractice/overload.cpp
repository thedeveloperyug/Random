#include<iostream>
using namespace std;

class Complex
{
    int real;
    int imag;
    public:

    Complex(int r=0,int i=0)
    {
        real=r;
        imag=i;
        // cout<<"Constror called!"<<endl;
    }
    void Display()
    {
        cout<<real<<"+i"<<imag<<endl;
    }
   friend Complex operator+(Complex x,Complex y);
   friend ostream & operator<<(ostream &out,Complex c);


};
Complex operator+(Complex x,Complex y)
    {
        Complex temp;
        temp.real=x.real+y.real;
        temp.imag=x.imag+y.imag;
        return temp;
    }
ostream & operator<<(ostream &out,Complex c)
{
    out<<c.real<<"+i"<<c.imag;
    return out;
}


int main()
{
    Complex c1(5,9),c2(6,11),c3;
    c3=c1+c2;

    cout<<c3<<endl;

    return 0;
}