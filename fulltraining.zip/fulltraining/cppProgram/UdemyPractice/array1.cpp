#include<iostream>

class Employee
{
    int id;
    int salary;
    public:
    void setId()
    {
        salary = 122;
        std::cout<<"Enter the Id of Employee "<<std::endl;
        std::cin>>id;
    }
    //Getter function to get value from private data member "salary"
    void getId()
    {
        std::cout<<"The Id of this Employee is  "<<id<<std::endl;
    }
};

int main()
{
    Employee fb[5];

    for(int i=0;i<5;i++)
    {
        fb[i].setId();
        fb[i].getId();
    }

    return 0;
}