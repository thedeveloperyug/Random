#include <iostream>
using namespace std;
class Student{
    private:
        string name;
        int roll;
        int marks[5];
    public:
        static int roll_no;
        Student(){
            this->name = "Unknown";
            this->roll = roll_no;
            roll_no++;
            for(int i=0;i<5;i++)
                this->marks[i] = 0;
        }
        void SetName(string name){
            this->name = name;
        }
        void SetRoll(int roll){
            this->roll = roll;
        }
        void SetMarks(int marks[],int size){
            for(int i=0;i<size;i++)
                this->marks[i] = marks[i];
        }
        string GetName(){
            return this->name;
        }
        int GetRoll(){
            return this->roll;
        }
        int *GetMarks(){
            return this->marks;
        }
        int MarksSum(int marks[],int size){
            int sum = 0;
            for(int i=0;i<size;i++)
                sum+=marks[i];
            return sum;
        }
        int MinimumMarks(){
            int min = marks[0];
            for(int i=1;i<5;i++)
                if(marks[i]<min)
                    min = marks[i];
            return min;
        }
        int MaximumMarks(){
            int max = marks[0];
            for(int i=1;i<5;i++)
                if(marks[i]>max)
                    max = marks[i];
            return max;
        }
        char StudentGrade(){
            float avg = Average();
            if(avg>=90)
                return 'A';
            else if(avg>=80)
                return 'B';
            else if(avg>=70)
                return 'C';
            else if(avg>=60)
                return 'D';
            else
                return 'E';
        }
};    
        int main()
        {

            return 0;
        }