#ifndef EMPLOYEE1_H
#define EMPLOYEE1_H

//what it check ? 

#include <iostream>

class Employee1
{
    int empid;
    double salary;
    std::string ename;

public:
    Employee1();
    Employee1(int eid, std::string enm, double salary);
    void show();
};

#endif // EMPLOYEE1_H
