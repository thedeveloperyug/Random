#include<iostream>
using namespace std;

class 
{



};

int main()
{


    return 0;
}