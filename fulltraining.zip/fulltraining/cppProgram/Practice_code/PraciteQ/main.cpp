#include<iostream>
#include "Employee1.h"

int main()
{
    Employee1  e1;
    e1.show();
    Employee1  e2(119078,"Kumar",30000);
    e2.show();

}