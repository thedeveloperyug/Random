#include <iostream>
#include "Employee1.h"

/* returntype classname :: functionName(parameters)
{

}
*/

Employee1::Employee1()
{
    empid = 101;
    ename = "Ram";
    salary = 30000;
    
}
Employee1::Employee1(int eid, std::string enm, double salary)
{
    empid = eid;
    ename = enm;
    this->salary = salary;
    
}
void Employee1::show()
{
    std::cout<<empid<<" "<<ename<<" "<<salary<<std::endl;
}
