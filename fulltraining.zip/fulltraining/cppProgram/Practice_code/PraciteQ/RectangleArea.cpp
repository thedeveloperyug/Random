#include<iostream>
using namespace std;

class rectangle
{
    float length;
    float breadth;
    public:
    
    rectangle()
    {
        cout<<"Enter the Length and Breadth of Rectangle:"<<endl;
        cout<<"Length: ";
        cin>>length;
        cout<<"Breadth: ";
        cin>>breadth;
    }
    
    float Area()
    {
       float area= length*breadth;
        return area;
    }
    float Perimeter()
    {
        float perimeter = 2*(length+breadth);
        return perimeter;
    }
    void Display(float area,float perimeter)
    {
        cout<<"Area= "<<area<<endl<<"Perimeter= "<<perimeter<<endl;
    }

};
// float rectangle::Area()
// {
//     float area;
//     area= length*breadth;
//         return area;
// }
// float rectangle::Perimeter()
// {
//     float perimeter;
//     perimeter = 2*(length+breadth);
//         return perimeter;
// }

int main()
{


    rectangle r;
                              // rectangle *r1=&r; --> pointer type object in stack memmory.
    float area;
    float perimeter;
    area=r.Area();
    perimeter=r.Perimeter();
    
    r.Display(area,perimeter);



    /* rectangle *r = new rectangle;   //--> Dynamic type pointer..
    float area;
    float perimeter;
    area=(*r).Area();
    perimeter=r->Perimeter();
    
    r->Display(area,perimeter); */



    return 0;
}