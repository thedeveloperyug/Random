#include <iostream>
using namespace std;

class Employee
{
    string name;
    float salary;
    char doj[10];

public:
    void getdata(Employee *arr, int n)
    {
        cout << "Enter the Name  Salary  Date_of_Joining" << endl;

        for (int i = 0,j=0; i,j < n; i++,j++)
        {
            
            cout << "\nEmployee" <<j+1<< endl;
            cout << "Name: ";
            cin >> arr[i].name;
            cout << endl<<"Salary: ";
            cin >> arr[i].salary;
            cout << endl<< "doj: ";
            cin >> arr[i].doj;
        }
    }
    void showdata(Employee *arr, int n)
    {
        cout << "****Ditails****" << endl;
        for (int i = 0,j=0; i,j < n; i++,j++)
        {
            
            cout << "Employee:-" << j+1 << endl;
            cout << "Name: " << arr[i].name << endl;
            cout << "Salary: " << arr[i].salary << endl;
            cout << "Doj :" << arr[i].doj << endl;
        }
    }
};

int main()
{
    Employee *e1;
    int n;
    cout << "Enter the size of Employee: ";
    cin >> n;
    Employee arr[100];
    e1->getdata(arr, n);
    e1->showdata(arr, n);
}