#include<iostream>
using namespace std;

class student
{
    int roll;
    int phone;
    string name;
    string address;
    public:
    void input()
    {
        cout<<"Enter the roll no: ";
        cin>>roll;
        cout<<endl<<"Enter phone no: ";
        cin>>phone;
        cout<<endl<<"Enter the name: ";
        cin>>name;
        cout<<endl<<"Enter the address: ";
        cin>>address;
        cout<<endl;
    }
    void display()
    {
        cout<<"*******Display******"<<endl;
        cout<<"Roll no= "<<roll<<endl<<"Phone= "<<phone<<endl<<"name= "<<name<<endl<<"address= "<<address<<endl;
        
    }
};

int main()
{
    
    int n;
    cout<<"Enter the size of student"<<endl;
    cin>>n;
    student arr[n];
    
    
    arr[n].input(arr,n);

    
return 0;
    
}