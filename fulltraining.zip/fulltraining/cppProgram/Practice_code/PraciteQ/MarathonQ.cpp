#include <iostream>
using namespace std;
class flight
{
    int Flight_number;
    string Destination;
    float Distance;
    float Fuel;

public:
    flight()
    {
        cout<<"This is Default Construction."<<endl;
    }
    flight(string cons)
    {
        cout<<"This is "<<cons<<endl;
    }
    float calculateFuelQuantity(float distance)
    {
        if(distance<=1000)
        Fuel=500;
        else if(distance >1000 && distance <=2000)
        Fuel=1100;
        else
        Fuel=2200;

        return Fuel;

    }
    float feedInfo()
    {
        cout<<"Enter the Flight number: ";
        cin>>Flight_number;
        cout<<"Enter the Destination: ";
        cin>>Destination;
        cout<<"Enter the distance: ";
        cin>>Distance;
        return Distance;

    }
    void showInfo(float distance,float Fuel2)
    {
        cout<<"\nCustomer Details are:-"<<endl;
        cout<<"Flight number: "<<Flight_number<<endl;
        cout<<"Destination: "<<Destination<<endl;
        cout<<"Distance: "<<distance<<endl;
        cout<<"Fuel: "<<Fuel2<<endl;
    }

};

int main()
{
    flight f1,f2("Parameterized construtor");
    float Distance1,Fuel1;
    Distance1=f1.feedInfo();
    Fuel1=f1.calculateFuelQuantity(Distance1);
    
    f1.showInfo(Distance1,Fuel1);

    return 0;
}