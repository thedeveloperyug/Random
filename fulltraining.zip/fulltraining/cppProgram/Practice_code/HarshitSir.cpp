#include <iostream>
using namespace std;
class Employee
{
    int empid;
    float salary;
    string location;

public:
    Employee(int empid1, float salary1, string loc)
    {
        empid = empid1;
        salary = salary1;
        location = loc;
    }
    void show()
    {
        cout << empid << " " << salary << " " << location;
    }
};
int main()
{
    // Employee e2;
    // e2.show();
    Employee e1(76345, 3745.75, "india");
    e1.show();
    
    return 0;
}