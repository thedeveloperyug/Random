#include <iostream>

class Account

{
    int accno;

    std::string name;

    double balance;

public:
    // getter method

    int getAccno()
    {

        return accno;
    }

    std::string getname()
    {

        return name;
    }

    double getbalance()
    {

        return balance;
    }

    // setter method

    void setAccno(int num)
    {

        accno = num;
    }

    void setname(std::string name)
    {

        name = name;
    }

    void setbalance(double b)
    {

        balance = b;
    }

    Account()
    {

        accno = 1011;

        name = "vipul";

        balance = 3400;
    }

    Account(int a, std::string nm, double b)

    {

        accno = a;

        name = nm;

        balance = b;
    }

    void show()
    {

        std::cout << accno << " " << name << " " << balance;
    }
};

void search(Account arr[], int n)
{

    int no;

    std::cout << "\nEnter account number to search";

    std::cin >> no;

    for (int i = 0;; i < n; i++)
    {

        // if()
    }
}

int main()

{

    Account *ptr = new Account

                       ptr->shpw();

    search(, 3)

        delete ptr;

    return 0;
}