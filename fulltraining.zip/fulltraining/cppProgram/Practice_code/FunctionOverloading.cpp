#include <iostream>
using namespace std;

// Polymerphism many forms of the same massage
// function overloading

class A
{
public:
    static void swap(int a, int b)   // do for swap..
    {
        cout << a + b<<endl;
    }
    static void swap(double a, double b)
    {
        cout << a + b<<endl;
    }
    static void swap(float a, float b)
    {
        cout << a + b<<endl;
    }
};

int main()
{
    // A::add(2, 3);
    // A::add(2.555, 3.445);
    // A::add(2.5f, 3.5f);

    A::swap(2, 3);
    A::swap(2.555, 4.445);
    A::swap(6.5f, 7.5f);
    

    return 0;
}