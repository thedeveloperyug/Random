#include<bits/stdc++.h>
using namespace std;

 

int chooseStudent(int index){
    cout<<"Choose student from 0 to "<<index<<" : ";
    int choose;
    cin>>choose;
    return choose;    
}
void merge(int *arr,int low,int mid,int high){
    int size1 = mid-low+1;
    int size2 = high-mid;
    int arr1[size1];
    int arr2[size2];

    for(int i=low;i<=mid;i++)
        arr1[i-low] = arr[i];
    for(int i=mid+1;i<=high;i++){
        arr2[i-(mid+1)] = arr[i];
    }
    int i=0,j=0;
    int k=low;
    while(i<size1 && j<size2){
        if(arr1[i]<arr2[j]){
            arr[k++] = arr1[i++];
        }else{
            arr[k++] = arr2[j++];
        }
    }
    while(i<size1)
        arr[k++]=arr1[i++];
    while(j<size2)
        arr[k++]=arr2[j++];
}
void Sort(int *arr,int low,int high){
    if(low>=high){
        int mid = (low+high)/2;
        Sort(arr,low,mid);
        Sort(arr,mid+1,high);
        merge(arr,low,mid,high);
    }
}
int* mergeSort(int arr[]){
    int size = 5;
    Sort(arr,0,4);
    return arr;
}

 

int MarksSum(int arr[]){
    int sum = 0;
    for(int i=0;i<5;i++)
        sum += arr[i];
    return sum;
}
class Student{
    string name;
    int roll;
    int marks[5];
    void Accept(){
            cout<<"Enter Student name: ";
            cin>>this->name;
            this->roll = roll_no;
            cout<<"Enter the Marks of 5 Subjects :";
            for(int i=0;i<5;i++)
                cin>>this->marks[i];
        }
    public:
        static int roll_no;
        Student(){
            cout<<"This Constructor"<<endl;
            roll_no += 1;
            Accept();
        }
        int* Sorting(){
            return mergeSort(this->marks);
        }
        int MinimumMarks(){
            int min_Marks = INT_MAX;
            for(int i=0;i<5;i++)
                min_Marks = min(min_Marks,this->marks[i]);
            return min_Marks;
        }
        int MaximumMarks(){
            int max_Marks = 0;
            for(int i=0;i<5;i++)
                max_Marks = max(max_Marks,this->marks[i]);
            return max_Marks;
        }
        char StudentGrade(){
//            float totalMarks = 500;
            float marks = MarksSum(this->marks);
            float percentage = marks/5;
            if(percentage>=90.0)
                return 'A';
            else if(percentage>=70.0)
                return 'B';
            else if(percentage>=50.0)
                return 'C';
            else if(percentage>=40.0)
                return 'D';
            else
                return 'F';
        }
        float Average(){
            float size = 5;
            float sum = MarksSum(this->marks);
            return sum/size;
        }
        bool compAvg(Student s2){
            float avg1 = Average();
            float avg2 = s2.Average();
            return avg1>avg2;
        }
        void Display(){
            cout<<"Student : "<<this->name<<endl;
            cout<<"Roll No : "<<this->roll<<endl;
            float avg = Average();
            cout<<"Average Marks : "<<avg<<endl;
        }

};
int Student::roll_no = 0;
int main(){
    int noOfStudents;
    cout<<"Enter Number of Student you Have : ";
    cin>>noOfStudents;
    Student students[noOfStudents];
    int index=0;
    while(true){
    cout<<"1. Creating New Object"<<endl;
    cout<<"2. Display"<<endl;
    cout<<"3. Sorting"<<endl;
    cout<<"4. Minimum Marks"<<endl;
    cout<<"5. Maximum Marks"<<endl;
    cout<<"6. Average Marks"<<endl;
    cout<<"7. Grade"<<endl;
    cout<<"8. Compare"<<endl;
    cout<<"9. Clear"<<endl;
    cout<<"10. Exit"<<endl<<endl;
    cout<<"Enter Your Choice : ";
    int choice;
    cin>>choice;
    int id,id1,id2;
    int *sortedMarks;
    float avg;
    char grade;
    bool result;
    switch(choice){
        case 1:
            if(index>=noOfStudents)
                cout<<"you reached your limit"<<endl;
            else{
                Student s1;
                students[index] = s1;
                index++;
            }
            break;
        case 2:
            id = chooseStudent(index);
            students[id].Display();
            break;
        case 3:
            id = chooseStudent(index);
            sortedMarks = students[id].Sorting();
            cout<<"Sorted Marks : ";
            for(int i=0;i<5;i++)
                cout<<sortedMarks[i]<<" ";
            cout<<endl;
            break;
        case 4:
            id = chooseStudent(index);
            cout<<"Minimum marks : "<<students[id].MinimumMarks()<<endl;
            break;
        case 5:
            id = chooseStudent(index);
            cout<<"Maximum marks : "<<students[id].MaximumMarks()<<endl;
            break;
        case 6:
            id = chooseStudent(index);
            avg = students[id].Average();
            cout<<"Average Marks : "<<avg<<endl;
            break;    
        case 7:
            id = chooseStudent(index);
            grade = students[id].StudentGrade();
            cout<<"Grade is "<<grade<<endl;
            break;
        case 8:
            cout<<"Choose 2 Students : ";
            id1 = chooseStudent(index);
            id2 = chooseStudent(index);
            result = students[id1].compAvg(students[id2]);
            if(result)
                students[id1].Display();
            else
                students[id2].Display();
            break;
        case 9:
               system("cls");
            break;
        case 10:
            exit(1);
        default:
            cout<<"Choice is Invalid";        
        }
    }
    return 0;
}