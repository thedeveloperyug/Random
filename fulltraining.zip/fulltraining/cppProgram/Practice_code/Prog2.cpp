#include<iostream>
using namespace std;
#include<vector>

long solve(vector<int> arr)
{
    int n=arr.size();
    int count =0;
    for(int i=0;i<n-1;i++)
    {
        int max_so_far = arr[i];
        for(int j=i+1;j<n;j++)
        {
            max_so_far = max(max_so_far,arr[j]);
            if(arr[i] * arr[j] > max_so_far)
            {
                count++;
            }
        }
    }
    return count;
}

int main()
{
    vector<int> arr;
    cout<<"\n"<<solve(arr)<<endl;
}