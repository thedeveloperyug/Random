#include <iostream>

class Account
{
    int accno;
    std::string name;
    double balance;
public:
   //getter method
    // int getAccno() const { return accno; }
    // void setAccno(int accno_) { accno = accno_; }  // using ctr+. automatic generate
   int getAccno(){
    return accno;
   }
   std::string getname(){
    return name;
   }
   double getbalance(){
    return balance;
   }
   //setter method
   void setAccno(int num){
    accno = num;
   }
   void setname(std::string name){
    this->name = name;
   }
   void setbalance(double b){
    balance = b;
   }
    Account(){
        accno = 1011;
        name = "vipul";
        balance = 3400;
    }
    Account(int a, std::string nm, double b)
    {
        accno = a;
        name = nm;
        balance = b;
    }
    void show(){
        std::cout<<accno<<" "<<name<<" "<<balance<<"\n";
    }
};
void search(Account arr[],int n){
    int no;
    std::cout<<"\nEnter account number to search"<<"\t";
    std::cin>>no;
    bool flag= false;
    for(int i=0;i<n;i++){
        if(arr[i].getAccno()==no){
        std::cout<<"Acoount found"<<"\n";
        flag=true;
        break;
        }
    }
    if(flag ==false){
        std::cout<<"Account not found";
    }
}
void modify(Account arr[],int n){
       int no,choice;
       std::cout<<"Enter account number to modify"<<"\t";
       std::cin>>no;
       std::cout<<"\n"<<"Select option"<<"\n";
       std::cout<<"Menu"<<"\t"<<"1.Name "<<"\t"<<"2.Balance"<<"\n";
       std::cin>>choice;
       for(int i=0;i<n;i++){
        switch(choice){
            case 1:
            if(arr[i].getAccno()==no){
                arr[i].setname("yadav");
                arr[i].show();
            }
            break;
            case 2:
            if(arr[i].getAccno()==no){
                arr[i].setbalance(58000);
                arr[i].show();
            }
            break;
        }

        }

       }

// void Display(Account arr[], int n){
    // for (int i = 0; i < n; i++)
    // {
    //    std::cout << "Account Number: " << arr[i].getAccno()<<"\t"<< "Name: " << arr[i].getname()<<"\t"<< "Balance: " << arr[i].getbalance()<<"\n";

    //    };
    // }
int main()
{
    //  const Account obj;
    //  obj.show();
    //  Account obj2;
    //  obj.show();
    //  Account *p = new Account(n);
    //  std::cin>>n;
    //  do {
    //     //menu driven application
    //     //1.Add 2.Display 3.Search 4.Modify 5.Exit
    //  } while(1);
    Account arr[3]={
         {101,"Vipul",5000},{102,"Shivam",3400},{103,"Satyam",6600}
    };
    search(arr,3);
    modify(arr,3);
    // display(arr,3);
    // delete ptr;
    return 0;
}
