#include <iostream>
using namespace std;
#include "header.h"

int main()
{
    Flight f1, f2("parameterized constractor");
    float Distance, Fuel;
    Distance = f1.feedInfo();
    Fuel = f1.calculateFuelQuantity(Distance);
    f1.showInfo(Fuel);


    return 0;
}