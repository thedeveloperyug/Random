#include<iostream>
using namespace std;
#include "header.h"

Flight::Flight()
{
    cout<<"This is defalut Constructor"<<endl;
}
Flight::Flight(string parameter)
{
    cout<<"This is "<<parameter<<endl;
}
float Flight::calculateFuelQuantity(float Distance)
{
    this->Distance=Distance;
    if(Distance <= 1000)
    Fuel = 500;
    else if(Distance >1000 && Distance <=2000)
    Fuel = 1100;
    else
    Fuel = 2200;

    return Fuel;
}
float Flight::feedInfo()
{
    cout<<"Enter the Flight number: "<<endl;
    cin>>FlightNum;
    cout<<"Enter the Destination: "<<endl;
    cin>>Destination;
    cout<<"Enter the Distance: "<<endl;
    cin>>Distance;

    return Distance;
}
void Flight::showInfo(float Fuel)
{
    this->Fuel=Fuel;
    cout<<"The Details of the customer are:- "<<endl<<endl;
    cout<<"Flight number is: "<<FlightNum<<endl;
    cout<<"Destination is: "<<Destination<<endl;
    cout<<"Distance is: "<<Distance<<endl;
    cout<<"Fuel to be charged: "<<Fuel<<endl;
}

//
