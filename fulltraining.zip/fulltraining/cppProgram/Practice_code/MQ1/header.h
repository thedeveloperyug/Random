#ifndef HEADER_H
#define HEADER_H

#include <iostream>
using namespace std;

class Flight
{
    int FlightNum;
    string Destination;
    float Distance;
    float Fuel;

public:
    Flight();
    Flight(string parameter);
    float calculateFuelQuantity(float distance);
    float feedInfo();
    void showInfo(float fuel);
};

#endif // HEADER_H
