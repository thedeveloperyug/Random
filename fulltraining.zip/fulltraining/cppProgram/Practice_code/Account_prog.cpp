#include <iostream>
using namespace std;

class Account
{
    int accno;
    string name;
    float balance;

    static int cnt;

    static int x;

public:
    Account()
    {
        accno = 11907900;
        name = "Shivam";
        balance = 10000;
    }
    Account(int accno, string name, float balance)
    {
        this->accno = accno;
        this->name = name;
        this->balance = balance;
    }
    // Account()
    // {
    //     cnt=10;
    //     cout<<"Constructor called "<<cnt<<endl;
    // }
    // Account(int cnt)
    // {
        
    //     this->accno=cnt;
    // }
    // Account(int accno, string name)
    // {
    //     this->accno=accno;
    //     this->name=name;
    //     cout<<"This for name= "<<&this->name<<endl;
    // }

    int getAccno(){
        return accno;
    }
    int setAccno(int ac)
    {
        accno=ac;
    }
    void show()
    {
        cout << accno <<" "<<name<<" "<<balance<<endl;
    }
    static int getX()
    {
        return x;
    }
    void deposite(int amount)
    {
        balance+=amount;
        cout<<"\nDeposited amount= "<<amount<<"\tTotal Balance= "<<balance<<endl;
    }
    void withdraw(int amount)
    {
        
        if(balance-amount < 1000)
        {
            cout<<"Error"<<endl;
        }
        else
        {
            balance-=amount;
            cout<<"Withdrawal sucessfull !\nTotal Balance= "<<balance<<endl;
        }
    }
};

int Account::cnt=10;
int Account::x=12;

int main()
{
    // cout<<"\n count= "<<Account::getX()<<endl;  //static data members can be acces with any object. And static data member can call only static function,
    
    Account a1;








    // a1.deposite(2000);
    // a1.withdraw(5000);

    // cout<<" Address of a1 "<<&a1<<endl;
    // a1.show();
    
    // Account *a2= new Account(15);
    // a2->show();

    // Account temp(22,"shivam");
    // temp.show();

    // Account b1(15);
    // b1.show();

    //Static allocation.
    // Account a1;
    // a1.setAccno(102);
    // cout<<" Account number= "<<a1.getAccno()<<endl;
    // //Dynamin allocation.
    
    Account *b1 = new Account;
    b1->setAccno(500);
    cout<<"Dynamic account= "<<(*b1).getAccno()<<endl;
    cout<<"Dynamic account2= "<<b1->getAccno()<<endl;

    a1.getAccno();
    a1.name="shivam";

    a1.show();
    Account arr[3]={
        {12345,"Rohit",2500.00},{54321,"Ravi",4000.00},{32154,"vipul",5000.25} };
    
    Account a2(arr[1]);
    a2.show();

    cout<<"Account number =  "<<a1.getAccno()<<endl;
    a1.setAccno(102);
    cout<<"New Account = "<<a1.getAccno()<<endl;
    

    return 0;
}