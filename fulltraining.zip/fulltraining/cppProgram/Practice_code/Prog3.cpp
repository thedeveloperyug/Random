#include<iostream>

class Employee
{
    int empid;
    int salary;
    std::string ename;
    public:
    Employee() // to initialize attributes/data members of object of a class..
    {
        //Every construction have this pointer which holds the address of current variable.

        empid=101;
        salary=6000;
        ename="Ram";
    }
    void show()
    {
        std::cout<<empid<<" "<<salary<<" "<<ename<<std::endl;
        
    }
};
int main(){
    Employee e1; // object /instance
    e1.show();
    Employee e2;
    e2.show();
    return 0;
}