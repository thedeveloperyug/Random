#include<iostream>

//main() - entry point of application.
//cout is an object of ostream class
//  << insertion operator is used with with cout
//cin is an object of istream class
//   >> extraction operator is used with cin
// cout and cin objects are declared in iostream header
// endl is manipulator ??- types of function..
// code segment ? in exe..

void display(){

    // int *p=(int*)malloc(sizeof(int)*5);  /created in heap memory-- Used in c..
    // int p= / it is local variable so stored in stack ...
    int *p = new int[5];    // used in c++..
    for(int i=0;i<5;i++)
    {
        std::cout<<" Enter the number ";
        std::cin>>p[i];
    }
    for(int i=0;i<5;i++)
    {
        std::cout<<p[i]<<std::endl;
    }
    // free(p);  Used in c for pop out.. // free memory pointed by p before we leave display function.

    delete[] p;  // delete p;- delete only the first element from heap 
}

int main(){

    static int a; // it is stored in data section not in heap not in stack.

    display();

    return 0;

}