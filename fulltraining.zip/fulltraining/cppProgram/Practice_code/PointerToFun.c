#include<stdio.h>
struct BankAccount
{
    //function pointer
    void (*ptr)(int);//pointer to function taking int as argument..
};
void deposite(int amount)
{
    printf("In deposite");
}
int main()
{
    // deposite(2000);

    struct BankAccount b1;
    
    // initialization of function pointer with address.

    b1.ptr=&deposite;
    b1.ptr(3000);

    
}
