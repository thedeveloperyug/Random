#include<iostream>
using namespace std;

//WE can set default value then it works for maximum 4 attributes and minimum 2 attributes.
//it has rule that we should always give default 0 from right side.

void avg(int a,int b,int c=0,int d=0)
{

}

int main()
{
    add(10,20,30,40);
    add(10,20,30);
    add(10,20);
    add(10);

    return 0;

}