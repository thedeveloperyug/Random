#ifndef WATERSLABS_H
#define WATERSLABS_H

#include<iostream>

enum WaterSlabs
{
    W1=10,
    W2=15
};

#endif // WATERSLABS_H
