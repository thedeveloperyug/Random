#ifndef ELECTRICITYSLABS_H
#define ELECTRICITYSLABS_H

#include<iostream>

enum ElectricitySlabs
{
    E1=125,
    E2=150,
    E3=200
};

#endif // ELECTRICITYSLABS_H
