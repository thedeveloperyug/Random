#include<iostream>
#include "electricity.h"
#include "water.h"

int main()
{
    std::cout<<"\nElectricity Bill of E1= ";
    Electricity *e1=new Electricity(60,400,300,ElectricitySlabs::E1);
    delete e1;
    std::cout<<"Electricity Bill of E2= ";
    Electricity *e2=new Electricity(40,600,400,ElectricitySlabs::E2);
    delete e2;
    std::cout<<"Electricity Bill of E3= ";
    Electricity* e3=new Electricity(20,200,150,ElectricitySlabs::E3);
    delete e3;

    Water w(20000,100);

    return 0;
}