#ifndef WATER_H
#define WATER_H

#include<iostream>
#include "waterslabs.h"

class Water
{
    long PresentReading;
    long PreviousReading;
    WaterSlabs Wslabs;


public:
    long presentReading() const { return PresentReading; }
    void setPresentReading(long presentReading) { PresentReading = presentReading; }

    long previousReading() const { return PreviousReading; }
    void setPreviousReading(long previousReading) { PreviousReading = previousReading; }

    Water(long,long);

    int calculateWaterBill();

    WaterSlabs wslabs() const { return Wslabs; }
    void setWslabs(const WaterSlabs &wslabs) { Wslabs = wslabs; }
    
};

#endif // WATER_H
