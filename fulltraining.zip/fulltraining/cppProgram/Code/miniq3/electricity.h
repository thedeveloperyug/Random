#ifndef ELECTRICITY_H
#define ELECTRICITY_H

#include<iostream>
#include "electricityslabs.h"

class Electricity
{
    int SectionLoad;
    long PresentReading;
    long PreviousReading;
    ElectricitySlabs Eslabs;

public:
    int sectionLoad() const { return SectionLoad; }
    void setSectionLoad(int sectionLoad) { SectionLoad = sectionLoad; }

    long presentReading() const { return PresentReading; }
    void setPresentReading(long presentReading) { PresentReading = presentReading; }

    long previousReading() const { return PreviousReading; }
    void setPreviousReading(long previousReading) { PreviousReading = previousReading; }

    Electricity(int,long,long,ElectricitySlabs);

    int calculateElectricityBill();

    ElectricitySlabs eslabs() const { return Eslabs; }
    void setEslabs(const ElectricitySlabs &eslabs) { Eslabs = eslabs; }

};

#endif // ELECTRICITY_H
