#include "water.h"
#include<iostream>

Water::Water(long presentReading, long previousReading)
 :PresentReading(presentReading),PreviousReading(previousReading)
{
    std::cout<<"\nWater Bill= "<<calculateWaterBill()<<std::endl;
}

int Water::calculateWaterBill()
{
    long Consumption=PresentReading-PreviousReading;
    long amount;
    if(PresentReading > PreviousReading)
    {
        if(Consumption <1000)
        {
    
            amount = (150 + (Consumption * 0.010));
        }
        else{
            amount = (150 + (Consumption * 0.015));
        }
        
        return ((WaterSlabs::W1 * 10) + (amount * WaterSlabs::W2)/1000);

    }
    else
    return 0;
}
