#include "electricity.h"
#include<iostream>

Electricity::Electricity(int SectionLoad,long PresentReading,long PreviousReading,ElectricitySlabs Eslabs)
{
    this->SectionLoad=SectionLoad;
    this->PresentReading = PresentReading ;
    this->PreviousReading = PreviousReading ;
    this->Eslabs = Eslabs;

    std::cout<<calculateElectricityBill()<<std::endl;

}

int Electricity::calculateElectricityBill()
{
    int Consumtion= this->PresentReading - this->PreviousReading;
    if (Consumtion > 0 )
    {
        if(this->Eslabs == 125)
        {
            return ((this->SectionLoad * 125) + (Consumtion * 125/100));
        }
        else if(this->Eslabs == 150)
        {
            return ((this->SectionLoad * 150) + (Consumtion * 150/100));
        }
        else if(this->Eslabs == 200)
        {
            return ((this->SectionLoad * 200) + (Consumtion * 200/100));
        }
        else
        return 20;

    }

    return 0;
}
