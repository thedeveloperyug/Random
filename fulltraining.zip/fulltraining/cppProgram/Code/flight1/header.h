#ifndef HEADER_H
#define HEADER_H

#include <iostream>
#include "enum.h"

class Train
{
private:
    std::string flightnumber;
    enum Flightclass flightClass;
    static int ticketsavialable;
    int ticketsissued;
    std::string fromplace;
    std::string toplace;

public:
    Train();

    void display();

    std::string getFlightnumber() const { return flightnumber; }
    void setFlightnumber(const std::string &flightnumber_) { flightnumber = flightnumber_; }

    enum Flightclass getFlightClass() const { return flightClass; }
    void setFlightClass(const enum Flightclass &flightClass_) { flightClass = flightClass_; }

    static int getTicketsavialable() { return Train::ticketsavialable; }
    static void setTicketsavialable(int ticketsavialable) { Train::ticketsavialable = ticketsavialable; }

    
    int getTicketsissued() const { return ticketsissued; }
    void setTicketsissued(int ticketsissued_) { ticketsissued = ticketsissued_; }

    std::string getFromplace() const { return fromplace; }
    void setFromplace(const std::string &fromplace_) { fromplace = fromplace_; }

    std::string getToplace() const { return toplace; }
    void setToplace(const std::string &toplace_) { toplace = toplace_; }

    void bookflight();

    int calculateFare();

    
    
};



#endif // HEADER_H
