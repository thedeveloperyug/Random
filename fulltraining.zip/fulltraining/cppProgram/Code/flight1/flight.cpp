#include "header.h"
#include<iostream>

int choiceToplace=0;   //Taking Global veriable for using two functions 1st in chosing Toplace 2nd for calculating the fare.
Train::Train()
{
    flightnumber="NULL";
    flightClass=Flightclass::NA;
    ticketsissued=0;
    fromplace="Mumbai";
    toplace="";

}

void Train::display()
{
    std::cout<<"\nFlight Number: "<<flightnumber<<std::endl;
    // std::cout<<"Flight Class: "<<flightClass<<std::endl;
    switch(flightClass)
    {
        case 0:
            std::cout<<"Flight Class: ECONOMY"<<std::endl;
            break;
        case 1:
            std::cout<<"Flight Class: PREMIUMECONOMY"<<std::endl;
            break;
        case 2:
            std::cout<<"Flight Class: BUSINESS"<<std::endl;
            break;
        case 3:
            std::cout<<"Flight Class: FIRSTCLASS"<<std::endl;
            break;
        default:
            std::cout<<"Default Flight Class will be choosen"<<std::endl;
            break;
    }
    std::cout<<"Ticket Booked: "<<ticketsissued<<std::endl;
    std::cout<<"The Flight from Mumbai to "<<toplace<<std::endl;
    calculateFare();

}
enum Flightclass takingclass(int ch)
{
    switch (ch)
    {
    case 1:
        return Flightclass::ECONOMY;
        break;
    case 2:
        return Flightclass::PREMIUMECONOMY;
        break;
    case 3:
        return Flightclass::BUSINESS;
        break;
    case 4:
        return Flightclass::FIRSTCLASS;
    
    default:
        return Flightclass::NA;
        break;
    }
}
std::string takingtoplace(int ch2)
{
   switch (ch2)
    {
    case 1:
        return "Goa";
        break;
    case 2:
        return "Delhi";
        break;
    case 3:
        return "Bangalore";
        break;
    case 4:
        return "Ahmedabad";
        break;
    default:
        return "NA";
        break;
    } 
 
}

void Train::bookflight()
{
    int choiceclass;    //Taking choice veriable for selecting the class form enum.
    std::cout<<"Book a Flight from Mumbai--"<<std::endl;
    std::cout<<"Tickets avialable is: "<<ticketsavialable<<std::endl;  //if ticketavialable=0 you can't book
    if(ticketsavialable > 0)
    {
    std::cout<<"Enter the flight number: ";
    std::cin>>flightnumber;
    std::cout<<" Book your class: Press"<<std::endl;
    std::cout<<" 1.ECONOMY\n 2.PREMIUM ECONOMY\n 3.BUSINESS\n 4.FIRST CLASS\n";
    std::cin>>choiceclass;
    flightClass=takingclass(choiceclass);
    std::cout<<"How much Ticket you want:"<<std::endl;
    std::cin>>ticketsissued;
    ticketsavialable-=ticketsissued;
    std::cout<<"Enter the Destination: Press"<<std::endl;
    std::cout<<" 1.Goa\n 2.Delhi\n 3.Banglore\n 4.Ahmedabad"<<std::endl;
    std::cin>>choiceToplace;
    
    toplace=takingtoplace(choiceToplace);
    if(toplace=="NA")
    {
        std::cout<<"\nNo Trains are avialable on your choice Ticket cannot book";
        exit(1);
    }
    
    std::cout<<"\nTicket Booked Confirm ";
    }
    else
    {
    std::cout<<"Ticket is not avialable, You can't book!"<<std::endl;
    return ;
    }


}

int Train::calculateFare()
{
    switch(choiceToplace)
    {
        case 1:
            std::cout<<"Total fare= "<<4470*ticketsissued<<" Rs"<<std::endl;
            return 4470*ticketsissued;
            break;
        case 2:
            std::cout<<"Total fare= "<<4181*ticketsissued<<" Rs"<<std::endl;
            return 4181*ticketsissued;
            break;
        case 3:
            std::cout<<"Total fare= "<<2170*ticketsissued<<" Rs"<<std::endl;
            return 2170*ticketsissued;
            break;
        case 4:
            std::cout<<"Total fare= "<<1752*ticketsissued<<" Rs"<<std::endl;
            return 1752*ticketsissued;
        default:
            return 0;
            break;
            
    }
    return 0;
}
int Train::ticketsavialable = 100;
