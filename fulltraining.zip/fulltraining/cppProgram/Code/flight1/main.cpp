#include<iostream>
#include "header.h"

void searchflight(Train obj2[],int size)
{
    std::string flightNumber;
    std::cout<<"Enter Flight number: ";
    std::cin>>flightNumber;
    for(int i=0;i<size;i++)
    {
       if(obj2[i].getFlightnumber()==flightNumber)
       {
       std::cout<<"Flight Found"<<std::endl;
       return ;
       }
    }
    std::cout<<"Flight not Found"<<std::endl;
    return ;
}
void createobject()
{
    Train *obj;
    obj=new Train[5];
    std::cout<<"\n-----WELCOME TO FLIGHT BOOKING YOU CAN BOOK UPTO 5 FLIGHTS-----"<<std::endl;
    int num=0;
    while(1)
    {
        std::cout<<std::endl;
        std::cout<<"    Press:    "<<std::endl;
        std::cout<<" 1.Book Ticket"<<std::endl;
        std::cout<<" 2.Calculate Fare"<<std::endl;
        std::cout<<" 3.Display"<<std::endl;
        std::cout<<" 4.Seacrch Flight"<<std::endl;
        std::cout<<" 5.EXIT"<<std::endl;
        int choice;
        std::cout<<"Enter Your Choice: ";
        std::cin>>choice;
        switch(choice)
        {
            case 1:
                if(num<5)
                {
                    obj[num].bookflight();
                    obj[num].calculateFare();
                    num++;
                }
                else
                  std::cout<<"\nYou have cross limit"<<std::endl;
                break;
            case 2:
                for(int i=0;i<num;i++)
                {
                    obj[i].calculateFare();
                }
                break;
            case 3:
                std::cout<<"\n**** The Details are ****"<<std::endl;
                for(int i=0;i<num;i++)
                {
                    obj[i].display();
                }
                break;
            case 4:
                searchflight(obj,5);
                break;
            case 5:
                exit(1);
                break;
            default:
                std::cout<<"Invalid Choice ! Please Try again"<<std::endl;
                break;       
        }

    }
    delete[]obj;
}


int main()
{
    createobject();

}