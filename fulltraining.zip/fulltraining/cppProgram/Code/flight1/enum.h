#ifndef ENUM_H
#define ENUM_H

#include<iostream>

enum Flightclass
{
    ECONOMY,
    PREMIUMECONOMY,
    BUSINESS,
    FIRSTCLASS,
    NA
};


#endif // ENUM_H
