#ifndef ENGINE_H
#define ENGINE_H

#include <iostream>
#include "enginetype.h"

class Engine
{
    std::string engineNumber;
    EngineType engineType;
    int engineHorsepower;
    int engineTorque;

public:
    Engine();

    std::string getEngineNumber() const { return engineNumber; }
    void setEngineNumber(const std::string &engineNumber_) { engineNumber = engineNumber_; }

    EngineType getEngineType() const { return engineType; }
    void setEngineType(const EngineType &engineType_) { engineType = engineType_; }

    int getEngineTorque() const { return engineTorque; }
    void setEngineTorque(int engineTorque_) { engineTorque = engineTorque_; }
};

#endif // ENGINE_H
