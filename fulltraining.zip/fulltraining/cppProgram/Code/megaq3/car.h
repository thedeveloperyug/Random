#ifndef CAR_H
#define CAR_H

#include <iostream>
#include "engine.h"
#include "cartype.h"

class Car
{
    std::string carId;
    std::string carBrand;
    CarType carType;
    Engine* carEngine;
    float carPrice;

public:
    Car();

    std::string getCarId() const { return carId; }
    void setCarId(const std::string &carId_) { carId = carId_; }

    std::string getCarBrand() const { return carBrand; }
    void setCarBrand(const std::string &carBrand_) { carBrand = carBrand_; }

    CarType getCarType() const { return carType; }
    void setCarType(const CarType &carType_) { carType = carType_; }

    Engine* getCarEngine() const { return carEngine; }
    void setCarEngine(Engine* carEngine_) { carEngine = carEngine_; }

    float getCarPrice() const { return carPrice; }
    void setCarPrice(float carPrice_) { carPrice = carPrice_; }
    
};

#endif // CAR_H
