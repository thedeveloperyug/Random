#ifndef ENGINETYPE_H
#define ENGINETYPE_H

#include<iostream>

enum EngineType
{
    ICT,
    HYBRID
};

#endif // ENGINETYPE_H
