#ifndef CARTYPE_H
#define CARTYPE_H

#include<iostream>

enum CarType
{
    SEDAN, SUV, SPORTS, HATCHBACK
};

#endif // CARTYPE_H
