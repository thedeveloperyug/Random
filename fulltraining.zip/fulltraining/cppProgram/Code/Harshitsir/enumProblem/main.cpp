#include<iostream>
#include "car.h"

enum CarCategory TakeInputGiveEnum()
{
    int choice=0;
    std::cout<<"Enter 1 for SUV, 2 for SEDAN, 3 for SPORTS, 4 for HATCHBACK "<<std::endl;
    
    switch (choice)
    {
    case 1:
       return CarCategory::SUV;
    case 2:
       return CarCategory::SEDAN;   
    case 3:
       return CarCategory::SPORTS;
    case 4:
       return CarCategory::HATCHBACK;   
    default:
       return CarCategory::HATCHBACK;
    }


}

void CreateObjects(Car** arr,int N)
{
    std::string name;
    int count;
    enum CarCategory category;
    float price;
    for(int i=0;i<N;i++)
    {
        std::cout<<"Enter name: ";
        std::cin>>name;
        std::cout<<"Enter count of seats: ";
        std::cin>>count;
        std::cout<<"Enter price(float): ";
        std::cin>>price;
        category=TakeInputGiveEnum();
        arr[i] = new Car(name,count,category,price);
    }
}

int main()
{
    Car* arr[3];
    CreateObjects(arr,3);

    

}