#ifndef CAR_H
#define CAR_H

#include <iostream>
#include "enum.h"

class Car
{
private:
    std::string carName;
    int carSeatCount;
    enum CarCategory carCategory;
    float carPrice;

public:
    Car(std::string name,int count,enum CarCategory category,float price);

    std::string getCarName() const { return carName; }
    void setCarName(const std::string &carName_) { carName = carName_; }

    int getCarSeatCount() const { return carSeatCount; }
    void setCarSeatCount(int carSeatCount_) { carSeatCount = carSeatCount_; }

    enum CarCategory getCarCategory() const { return carCategory; }
    void setCarCategory(const enum CarCategory &carCategory_) { carCategory = carCategory_; }

    float getCarPrice() const { return carPrice; }
    void setCarPrice(float carPrice_) { carPrice = carPrice_; }

    ~Car();
};

#endif // CAR_H
