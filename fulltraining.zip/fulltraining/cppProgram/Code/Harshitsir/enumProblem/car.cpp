#include<iostream>
#include "car.h"

Car::Car(std::string name,int count,enum CarCategory category,float price)
     :carName(name), carSeatCount(count), carCategory(category), carPrice(price)
{

}

Car::~Car()
{
    std::cout<< " Car with name: "<<this->carName<<" is destroyed\n";
}

