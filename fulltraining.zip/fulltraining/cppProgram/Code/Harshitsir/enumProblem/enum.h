#ifndef ENUM_H
#define ENUM_H

#include<iostream>

enum CarCategory
{
    SUV=1,
    SEDAN=2,
    SPORTS=3,
    HATCHBACK=4
};

#endif // ENUM_H
