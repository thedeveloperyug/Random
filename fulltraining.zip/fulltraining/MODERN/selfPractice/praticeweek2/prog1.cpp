#include<iostream>
#include<functional>


using Ftype = std::function<int (int) >;

void operation(int x,Ftype fn,Ftype fn2,Ftype fn3)
{
    std::cout<<"square= "<<fn(x)<<std::endl;
    std::cout<<"cube= "<<fn2(x)<<std::endl;
     std::cout<<"sum= "<<fn3(x)<<std::endl;
}

int main()
{
    int n = 6;

    operation(n,[](int x){return x * x ;},
    [](int x){return x*x*x;},
    [](int x){return x+x;});
}