#include<iostream>
#include<functional>
#include<vector>
#include<list>


using Ftype = std::function<int (int) >;
using ContainerFun = std::vector<Ftype>;



void operation(int n,ContainerFun& data)
{
    for(Ftype& x: data)
    {
        std::cout<<x(n)<<" ";
    }
}

int main()
{
    int n = 6;

    ContainerFun data; 

    data.push_back([](auto x){return x * x;});
    data.push_back([](auto x){return x * x * x;});
    data.push_back([](auto x){return x + x;});

    operation(n,data);
}