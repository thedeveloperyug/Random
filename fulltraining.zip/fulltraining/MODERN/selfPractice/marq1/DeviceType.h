#ifndef DEVICETYPE_H
#define DEVICETYPE_H

enum class DeviceType
{
    MOBILE,
    WORKSTATION,
    ACCESORY
};

#endif // DEVICETYPE_H
