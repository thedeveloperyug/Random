#include<iostream>
#include "Device.h"
#include "DeviceType.h"
#include "Functionalities.h"
#include<vector>
#include<memory>

using Container = std::vector<Pointer>;

int main()
{
    Container data;

    CreateObject(data);

    ShowResults(data);

    DiscountedPrice(data[2]);

    auto f1 = [](Pointer instance){
        std::cout<<"_sar_value: "<<instance->sarValue()<<std::endl;
        std::cout<<"_price of the Device: "<<instance->price()<<std::endl;
    };

    f1(data[1]);

    auto f2 = [](Pointer instance){
        if(instance->type() == DeviceType::MOBILE)
           std::cout<<"Id is: "<<instance->id()<<std::endl;
        else if(instance->type() == DeviceType::WORKSTATION)
           std::cout<<"Name is: "<<instance->name()<<std::endl;
        else
            std::cout<<"Sar_Value: "<<instance->sarValue();
    };

    f2(data[3]);
}