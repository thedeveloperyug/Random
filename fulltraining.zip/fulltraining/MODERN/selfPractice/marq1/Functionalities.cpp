#include "Functionalities.h"

void CreateObject(Container &data)
{
    data.push_back(std::make_shared<Device>("D101","Samsung",10000.0f,3.5,DeviceType::ACCESORY));
    data.push_back(std::make_shared<Device>("D102","Nokia",11000.0f,3.5,DeviceType::MOBILE));
    data.push_back(std::make_shared<Device>("D103","Radmi",12000.0f,3.5,DeviceType::ACCESORY));
    data.push_back(std::make_shared<Device>("D104","Realme",20000.0f,3.5,DeviceType::WORKSTATION));
    data.push_back(std::make_shared<Device>("D105","Onida",30000.0f,3.5,DeviceType::WORKSTATION));

}

void ShowResults(Container &data)
{
    for(auto it: data)
    {
        std::cout<<*it<<" "<<std::endl;
    }
}

void DiscountedPrice(Pointer intstance)
{
    float price = 0.0f;
    
    if(intstance->type() == DeviceType::ACCESORY)
    {
        price = intstance->price() * 0.02f;
    }
    else
    {
        price = intstance->price() * 0.01f;
    }
    std::cout<<"\nDiscounted Price for Single is: "<<price;
}
