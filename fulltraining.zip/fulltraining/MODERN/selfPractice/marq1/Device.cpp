#include "Device.h"

Device::Device(std::string id, std::string name, float price, float sar_value,DeviceType type)
: _id(id),_name(name),_price(price),_sar_value(sar_value),_type(type)
{
}

std::string DisplayEnum(DeviceType type)
{
    if(type == DeviceType::ACCESORY)
       return "ACCESORY";
    else if(type == DeviceType::MOBILE)
       return "MOBILE";
    else
       return "WORKSTATION";
}

std::ostream &operator<<(std::ostream &os, const Device &rhs) {
    os << "_id: " << rhs._id
       << " _name: " << rhs._name
       << " _price: " << rhs._price
       << " _sar_value: " << rhs._sar_value
       << " _type: " << DisplayEnum(rhs._type);
    return os;
}




