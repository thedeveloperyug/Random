#include<iostream>
#include "Device.h"
#include "DeviceType.h"
#include<memory>
#include<vector>
#include<functional>

using Pointer = std::shared_ptr<Device>;
using Container = std::vector<Pointer>;

void CreateObject(Container& data);    ///Creating the 5 instances objeect..

void ShowResults(Container& data);    //Function for Showibng the result

void DiscountedPrice(Pointer intstance);  // function for finding the discount price using type.

