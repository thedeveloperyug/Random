#ifndef SEGMENT_H
#define SEGMENT_H

enum class Segment{
    PREMIUM,
    BUDGET,
    SPORTS
};

#endif // SEGMENT_H
