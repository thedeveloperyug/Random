#include "Insurance.h"
std::ostream &operator<<(std::ostream &os, const Insurance &rhs) {
    os << "_type: " << InsuranceTypeValue(rhs._type)
       << " _premium: " << rhs._premium
       << " _idvAmount: " << rhs._idvAmount;
    return os;
}
std::string InsuranceTypeValue(InsuranceType tp)
{
if(tp==InsuranceType::ALL_INCLUSIVE){
    return "ALL_INCLUSIVE";
}else if(tp==InsuranceType::ZERO_DEBT){
    return "ZERO_DEBT";
}else{
    return "REGULAR";
}
}
Insurance::Insurance(InsuranceType type, float premium, int idvAmount)
    : _type(type), _premium(premium), _idvAmount(idvAmount)
{

}
