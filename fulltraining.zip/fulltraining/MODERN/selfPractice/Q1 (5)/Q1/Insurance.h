#ifndef INSURANCE_H
#define INSURANCE_H

#include<iostream>
#include"InsuranceType.h"

class Insurance
{
private:
   InsuranceType _type;
   float _premium;
   int _idvAmount;

public:
    Insurance(InsuranceType type,
   float premium,
   int idvAmount) ;
   Insurance()=delete;
   Insurance(const Insurance&)=delete;
   Insurance(Insurance&&)=delete;
   Insurance& operator=(Insurance&)=delete;
   Insurance& operator=(Insurance&&)=delete;
    ~Insurance()=default;

    float premium() const { return _premium; }

    void setPremium(float premium) { _premium = premium; }

    int idvAmount() const { return _idvAmount; }

    InsuranceType type() const { return _type; }

    friend std::ostream &operator<<(std::ostream &os, const Insurance &rhs);
    
};
std::string InsuranceTypeValue(InsuranceType tp);

#endif // INSURANCE_H
