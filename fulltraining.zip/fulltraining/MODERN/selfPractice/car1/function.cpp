#include "function.h"

void CreateObject(Container &data)
{
    data.emplace_back("c102","swift",CarType::SEDAN,750000.0f,35);
    data.emplace_back("c103","Dezire",CarType::HATCHBACK,900000.0f,40);
    data.emplace_back("c104","Alto",CarType::SEDAN,400000.0f,30);
    data.emplace_back("c105","Fortuner",CarType::SUV,150000.0f,60);
    data.emplace_back("c106","Baganr",CarType::HATCHBACK,550000.0f,45);

}

float AverageOfVehicle(Container &data)
{
    float sum = 0;

    for(Car c : data)
    {
        sum += c.price();
    }
    return sum / data.size();
}


void ModelNameHighestPrice(Container &data)
{
    float hPrice = data.front().price();
    std::list<std::string> modelName;
    //find the highest price of vehicle and store it in a list
    for(Car c : data)
    {
        if (c.price() > hPrice)
        {
            hPrice = c.price();
            modelName.clear();
            modelName.push_back(c.model());
        }
        else if (c.price() == hPrice)
        {
            modelName.push_back(c.model());
        }

    }
    std::cout<<"\nHighest Price is: ";
    for(std::string name : modelName)
    {
        std::cout<<name<<"\n"<<std::endl;
    }
}

Container CarsAboveThershold(Container &data, float thershold)
{
    Container result;
    for(Car c : data)
    {
        if(c.price() > thershold)
        {
            result.push_back(c);
        }
    }
    return result;
}

