#ifndef FUNCTION_H
#define FUNCTION_H

#include "car.h"
#include <list>

using Container = std::list<Car>;   //Container replace list of Car class.

void CreateObject(Container& data);  //Function for creating the object by passing the container and data which is object.

float AverageOfVehicle(Container& data);  //Function for finding and return the average of all vehicle.

void ModelNameHighestPrice(Container& data);  //Fucntion for finding the Highest Price and Display that model.

Container CarsAboveThershold(Container& data,float thershold);  //Function for finding return the all cars above the thershold price.



#endif // FUNCTION_H
