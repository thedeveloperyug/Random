#include "car.h"
#include "function.h"
#include <list>

using Container = std::list<Car>; 


int main()
{
    Container data;
    CreateObject(data);

    //Call function to find the average price..
    std::cout<<"\nAverage Price is: "<<AverageOfVehicle(data) <<std::endl;

    //call function for showing highest model name;
    ModelNameHighestPrice(data);

    //calling the function for finding and printing the printing the cars above thershold price.
    Container result1 = CarsAboveThershold(data,600000.0f);

    for(Car c : result1)
    {
        std::cout<<c<<" "<<std::endl;
    }

}