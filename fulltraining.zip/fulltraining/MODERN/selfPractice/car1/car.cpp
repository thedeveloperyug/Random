#include "car.h"

std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << "_id: " << rhs._id
       << " _model: " << rhs._model
       << " _type: " << DisplayEnum(rhs._type)
       << " _price: " << rhs._price
       << " _fuelCapacity: " << rhs._fuelCapacity;
    return os;
}

std::string DisplayEnum(CarType type)
{
    if(type == CarType::HATCHBACK)
        return "HATCHBACK";
    else if(type == CarType::SEDAN)
        return "SEDAN";
    else
        return "SUV";
}

Car::Car(std::string id, std::string model, CarType type, float price, int fuelCapacity)
 : _id(id), _model(model),_type(type),_price(price),_fuelCapacity(fuelCapacity)
{
}
