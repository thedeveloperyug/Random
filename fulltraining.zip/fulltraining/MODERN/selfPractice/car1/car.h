#ifndef CAR_H
#define CAR_H

#include <iostream>
#include "cartype.h"

class Car
{
    std::string _id;
    std::string _model;
    CarType _type;
    float _price;
    int _fuelCapacity;

public:

    Car() = delete;  //Disable Default Constructor.

    Car (const Car&) = default;  // Shellow copy constructor Deafult.

    Car& operator=(const Car&) = delete;  //a function which returns a Car& const which is "operator=" by passing the lvalue.

    Car (Car&&) = delete;  // Disable Move Constructor.

    Car& operator=(Car&&) = delete;  //a function which returns the a Car& const which returns "operator=" by passing the lvalue as parameter.

    ~Car() {}   //Destructor Called.

    Car(std::string id,std::string model,CarType type,float price,int fuelCapacity);

    std::string id() const { return _id; }

    std::string model() const { return _model; }

    CarType type() const { return _type; }

    float price() const { return _price; }

    int fuelCapacity() const { return _fuelCapacity; }

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);  // output stream ..


};

std::string DisplayEnum(CarType type);  // Function for display the enum value..

#endif // CAR_H
