#include "Functionalities.h"
#include <iostream>

int main()
{
    Container data;
    CreateObjects(data);
    Container result = ReturnContainerFirstNinstances(data, 1);
    for (auto &a : result)
    {
        std::cout << *a << "\n";
    }

    int *arr;
    int *temp = ArrayOf3Integers(data, arr);
    for (int i = 0; i < 3; i++)
    {
        std::cout << temp[i] << "\n";
    }
    float tax = FindProductTaxAmount(data);
    std::cout << "Product Tax Amount:" << tax << "\n";
    UniqueContainer unique = UniqueProductBrands(data);
    for (auto &a : unique)
    {
        std::cout << *a << "\n";
    }
    AdressContainer Address = AddressContainerByBrand(data, "SAMSUNG");
    for (auto &a : Address)
    {
        std::cout << a.get() << "\n";
    }
}