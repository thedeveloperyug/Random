
#include <iostream>
#include "Product.h"
#include <list>
#include <memory>
#include <functional>
#include <set>
#include "Functionalities.h"

using Pointer = std::shared_ptr<Product>;
using Container = std::list<Pointer>;

/*
    A FUNCTION TO CREATE AN OBJECTS
*/

std::function<void(Container &data)> CreateObjects = [](Container &data)
{
    data.emplace_back(
        std::make_shared<Product>(
            "1P",
            ProductType::APPLIANCE,
            1000.0f,
            "SAMSUNG",
            ProductOrigin::DOMESTIC,
            20.0f));
    data.emplace_back(
        std::make_shared<Product>(
            "2P",
            ProductType::FMCG,
            1292.0f,
            "REDMI",
            ProductOrigin::IMPORTED,
            10.0f));
    data.emplace_back(
        std::make_shared<Product>(
            "3P",
            ProductType::PERFUME,
            2920.0f,
            "AXE",
            ProductOrigin::IMPORTED,
            22.0f));
};

/*
    A FUNCTION TO RETURN THE AVERAGE PRODUCT_PRICE VALUE FOR ALL PRODUCT WHOSE
    PRODUCT TYPE IS PROVIDED AS AN ARGUMENT
*/

std::function<float(Container &data, ProductType type)> FindAverageByProductType = [](Container &data, ProductType type)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY");
    }
    float sum = 0.0f;
    int n = 0;
    for (auto &a : data)
    {
        if (a->getProductType() == type)
        {
            sum += a->getProductPrice();
            n++;
        }
    }
    return sum / n;
};

/*
    A FUNCTION TO RETURN THE PRODUCTTAX AMOUNT OF THE PRODUCT WHTH THE MINIMUM PRODUCT PRICE
*/

std::function<float(Container &data)> FindProductTaxAmount = [](Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY");
    }
    float min = data.front()->getProductPrice();
    float result;
    for (auto &a : data)
    {
        if (a->getProductPrice() < min)
        {
            min = a->getProductPrice();
            result = a->getProductTaxAmount();
        }
    }
    return result;
};

/*
    A FUNCTION TO RETURN CONTAINER OF FIRST N INSTANCES
    OF PRODUCT CLASS FORM CONTAINER OF PRODUCT OBJECTS
    WHERE N IS GIVEN AS AN INPUT PARAMETER TO THE FUNCTION
*/

std::function<Container(Container &data, int N)> ReturnContainerFirstNinstances = [](Container &data, int N)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY");
    }
    if (N == 0)
    {
        throw std::runtime_error("N Cant Be Zero");
    }
    Container result;
    Container ::iterator it;
    it = data.begin();
    for (int i = 0; i < N; i++)
    {
        result.emplace_back(*it);
        it++;
    }
    return result;
};

/*
    A FUNCTION TO IDENTIFY AND RETURN A CONTAINER OF UNIQUE PRODUCTBRANDS FROM THE CONTAINER
    OF PRODUCT INSTANCES
*/

std::function<UniqueContainer(Container &data)> UniqueProductBrands = [](Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY");
    }
    UniqueContainer result;
    for (auto &a : data)
    {
        result.insert(a);
    }
    return result;
};

/*
    A FUNCTION THAT RETURNS AN ARRAY OF 3 INTEGERS WHERE THE THREE POSITIONS OF THE ARRYA
    INDICATES
        1 COUNT OF FMCG productType instances
        2 count of DOMESTIC productType instances
        3 count of product instances whose productPrice is above 50
*/

std::function<int *(Container &data, int *arr)> ArrayOf3Integers = [](Container &data, int *arr)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY");
    }
    int countFMCG, countDOMESTIC, countPrice;
    countFMCG = countDOMESTIC = countPrice = 0;
    for (auto &a : data)
    {
        if (a->getProductType() == ProductType::FMCG)
            countFMCG++;
        if (a->getProductOrigin() == ProductOrigin::DOMESTIC)
            countDOMESTIC++;
        if (a->getProductPrice() > 50.0f)
        {
            countPrice++;
        }
    }
    arr = new int[3]{countFMCG, countDOMESTIC, countPrice};
    return arr;
};

/*
    A FUNCTION THAT RETURNS A CONTAINER OF ADDRESSS FOR PRODUCT INSTANCES WHOSE
    PRODUCT BRAND MATCHES  THE NAME GIVEN AS INPUT STRING TO THE FUNCTION
*/
std::function<AdressContainer(Container &data, std::string brand)> AddressContainerByBrand = [](Container &data, std::string brand)
{
    if (data.empty())
    {
        std::runtime_error("EMPTY");
    }
    AdressContainer result;
    for (auto &a : data)
    {
        if (brand == a->getProductBrand())
        {
            result.emplace_back(std::ref(a));
        }
    }
    return result;
};
