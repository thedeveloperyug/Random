#ifndef PRODUCTTYPE_H
#define PRODUCTTYPE_H

#include <iostream>

enum class ProductType
{
    FMCG,
    PERFUME,
    APPLIANCE
};

#endif // PRODUCTTYPE_H
