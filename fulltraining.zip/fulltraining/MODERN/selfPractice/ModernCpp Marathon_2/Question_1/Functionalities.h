
#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include "Product.h"
#include <list>
#include <memory>
#include <functional>
#include <set>

using Pointer = std::shared_ptr<Product>;
using Container = std::list<Pointer>;
using AdressContainer = std::list<std::reference_wrapper<Pointer>>;
using UniqueContainer = std::set<Pointer>;

/*
    A FUNCTION TO CREATE AN OBJECTS
*/

extern std::function<void(Container &data)> CreateObjects;

/*
    A FUNCTION TO RETURN THE AVERAGE PRODUCT_PRICE VALUE FOR ALL PRODUCT WHOSE
    PRODUCT TYPE IS PROVIDED AS AN ARGUMENT
*/

extern std::function<float(Container &data, ProductType type)> FindAverageByProductType;

/*
    A FUNCTION TO RETURN THE PRODUCTTAX AMOUNT OF THE PRODUCT WHTH THE MINIMUM PRODUCT PRICE
*/

extern std::function<float(Container &data)> FindProductTaxAmount;

/*
    A FUNCTION TO RETURN CONTAINER OF FIRST N INSTANCES
    OF PRODUCT CLASS FORM CONTAINER OF PRODUCT OBJECTS
    WHERE N IS GIVEN AS AN INPUT PARAMETER TO THE FUNCTION
*/

extern std::function<Container(Container &data, int N)> ReturnContainerFirstNinstances;

/*
    A FUNCTION TO IDENTIFY AND RETURN A CONTAINER OF UNIQUE PRODUCTBRANDS FROM THE CONTAINER
    OF PRODUCT INSTANCES
*/

extern std::function<UniqueContainer(Container &data)> UniqueProductBrands;

/*
    A FUNCTION THAT RETURNS AN ARRAY OF 3 INTEGERS WHERE THE THREE POSITIONS OF THE ARRYA
    INDICATES
        1 COUNT OF FMCG productType instances
        2 count of DOMESTIC productType instances
        3 count of product instances whose productPrice is above 50
*/

extern std::function<int *(Container &data, int *arr)> ArrayOf3Integers;

/*
    A FUNCTION THAT RETURNS A CONTAINER OF ADDRESSS FOR PRODUCT INSTANCES WHOSE
    PRODUCT BRAND MATCHES  THE NAME GIVEN AS INPUT STRING TO THE FUNCTION
*/

extern std::function<AdressContainer(Container &data, std::string brand)> AddressContainerByBrand;

#endif // FUNCTIONALITIES_H
