#include "Product.h"
/*
    A FUNCTION TO DISPLAY PRODUCT TYPE
*/
std::string DisplayProductType(ProductType type)
{
    if (type == ProductType::APPLIANCE)
        return "APPLICANCE";
    else if (type == ProductType::FMCG)
        return "FMCG";
    else
    {
        return "PERFUME";
    }
}

/*
    A FUCNTION TO RETURN PRODUCT ORIGIN
*/
std::string DisplayProductorigin(ProductOrigin type)
{
    if (type == ProductOrigin::DOMESTIC)
        return "DOMESTIC";
    else
    {
        return "IMPORTED";
    }
}

/*
    A DESTRUCTOR FOR CLASS PRODUCT
*/
Product::~Product()
{
    std::cout << "PRODUCT DESTROYED\n";
}

/*
    PARAMETRIZED COSNTRUCTOR FOR CLASS PRODUCT
*/
Product::Product(std::string id, ProductType productType_, float price, std::string brand,
                 ProductOrigin productOrigin_, float tax)
    : productId(id), productType(productType_), productPrice(price), productBrand(brand),
      productOrigin(productOrigin_)
{
    float res = price * 0.05f;
    if (res == tax)
    {
        this->productTaxAmount = tax;
    }
}

std::ostream &operator<<(std::ostream &os, const Product &rhs)
{
    os << "productId: " << rhs.productId
       << " productType: " << DisplayProductType(rhs.productType)
       << " productPrice: " << rhs.productPrice
       << " productBrand: " << rhs.productBrand
       << " productOrigin: " << DisplayProductorigin(rhs.productOrigin)
       << " productTaxAmount: " << rhs.productTaxAmount;
    return os;
}
