#ifndef PRODUCTORIGIN_H
#define PRODUCTORIGIN_H

#include <iostream>
enum class ProductOrigin
{
    DOMESTIC,
    IMPORTED
};

#endif // PRODUCTORIGIN_H
