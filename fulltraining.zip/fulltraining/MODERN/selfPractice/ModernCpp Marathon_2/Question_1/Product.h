#ifndef PRODUCT_H
#define PRODUCT_H

#include <iostream>
#include "ProductType.h"
#include "ProductOrigin.h"

class Product
{
private:
    /* data */
    std::string productId;
    ProductType productType;
    float productPrice;
    std::string productBrand;
    ProductOrigin productOrigin;
    float productTaxAmount;

public:
    // DEFAULT CONSTRUCTOR DISABLE
    Product(/* args */) = delete;
    // COPY CONSTRUCTOR DISABLED
    Product(const Product &obj) = delete;
    // MOVE CONSTRUCTOR DISABLED
    Product(Product &&obj) = delete;
    // DESTRUCTOR
    ~Product();
    // PARAMETRIZED CONSTRUCTOR
    Product(std::string id, ProductType productType_, float price, std::string brand, ProductOrigin productOrigin_, float tax);

    float getProductTaxAmount() const { return productTaxAmount; }
    void setProductTaxAmount(float productTaxAmount_) { productTaxAmount = productTaxAmount_; }

    ProductOrigin getProductOrigin() const { return productOrigin; }
    void setProductOrigin(const ProductOrigin &productOrigin_) { productOrigin = productOrigin_; }

    std::string getProductBrand() const { return productBrand; }
    void setProductBrand(const std::string &productBrand_) { productBrand = productBrand_; }

    float getProductPrice() const { return productPrice; }
    void setProductPrice(float productPrice_) { productPrice = productPrice_; }

    ProductType getProductType() const { return productType; }
    void setProductType(const ProductType &productType_) { productType = productType_; }

    std::string getProductId() const { return productId; }
    void setProductId(const std::string &productId_) { productId = productId_; }

    friend std::ostream &operator<<(std::ostream &os, const Product &rhs);
};

/*
    A FUNCTION TO DISPLAY PRODUCT TYPE
*/
std::string DisplayProductType(ProductType type);

/*
    A FUCTION TO DISPLAY PRODUCT ORIGIN
*/
std::string DisplayProductorigin(ProductOrigin type);
#endif // PRODUCT_H
