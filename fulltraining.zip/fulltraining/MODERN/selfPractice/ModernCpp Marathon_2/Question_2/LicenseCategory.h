#ifndef LICENSECATEGORY_H
#define LICENSECATEGORY_H

#include <iostream>
enum class LicenseCategory{
    COMMERCIAL,
    PERSONAL,
    SPECIAL_PURPOSE
};

#endif // LICENSECATEGORY_H
