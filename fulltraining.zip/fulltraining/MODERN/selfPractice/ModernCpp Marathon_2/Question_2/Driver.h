#ifndef DIVER_H
#define DIVER_H

#include <iostream>
#include "DriverCategory.h"
#include "License.h"
#include <memory>

using Reference = std::reference_wrapper<std::shared_ptr<License>>;

class Driver
{
private:
    /* data */
    std::string driverName;
    DriverCategory driverCategory;
    int driverBirthYear;
    Reference driverLicense;

public:

    Driver(/* args */) = delete;  // Default constuctor disabled
    Driver(const Driver& obj) = delete;  // copy constructor disabled
    Driver(Driver&& obj) = delete;  // move constructor disabled

    //Parametrized constructor
    Driver(std::string Dname, DriverCategory driverCategory_, int birthYear, Reference driverLicense_);
    virtual ~Driver();

    std::string getDriverName() const { return driverName; }
    void setDriverName(const std::string &driverName_) { driverName = driverName_; }

    DriverCategory getDriverCategory() const { return driverCategory; }
    void setDriverCategory(const DriverCategory &driverCategory_) { driverCategory = driverCategory_; }

    int getDriverBirthYear() const { return driverBirthYear; }
    void setDriverBirthYear(int driverBirthYear_) { driverBirthYear = driverBirthYear_; }

    Reference getDriverLicense() const { return driverLicense; }
    void setDriverLicense(const Reference &driverLicense_) { driverLicense = driverLicense_; }

    friend std::ostream &operator<<(std::ostream &os, const Driver &rhs);
    

};
/*
    A function to display driver category
*/

std::string DisplayDriverCategory(DriverCategory type);

#endif // DIVER_H
