#include "Functionalities.h"
#include <iostream>
#include "Driver.h"
#include "License.h"
#include <list>
#include <memory>
#include <functional>

auto l1 = std::make_shared<License>("L1", 5, LicenseCategory::COMMERCIAL, "PCMC", "MAHARASHTRA");
auto l2 = std::make_shared<License>("L2", 6, LicenseCategory::SPECIAL_PURPOSE, "PUNE", "GUJRAT");
auto l3 = std::make_shared<License>("L3", 7, LicenseCategory::PERSONAL, "NANDED", "WEST BENGAL");
auto l4 = std::make_shared<License>("L4", 8, LicenseCategory::COMMERCIAL, "MOSHI", "DELHI");

/*
    A function to create object
*/

std::function<void(Container &data)> CreateObjects = [](Container &data)
{
    data.emplace_back(
        std::make_shared<Driver>(
            "akshay",
            DriverCategory::PRIVATE,
            2001,
            std::ref(l1)));
    data.emplace_back(
        std::make_shared<Driver>(
            "Omkar",
            DriverCategory::COMMERCIAL,
            2002,
            std::ref(l2)));
    data.emplace_back(
        std::make_shared<Driver>(
            "Aslam",
            DriverCategory::PRIVATE,
            2004,
            std::ref(l3)));
    data.emplace_back(
        std::make_shared<Driver>(
            "Kuldeep",
            DriverCategory::COMMERCIAL,
            1990,
            std::ref(l4)));
};

/*
    A function to find and return the first N license Instances from a container
    of driver instances which are referred to by driver instances for which birth year is 1960 or less
*/

std::function<LicenseContainer(Container &data, int N)> LicenseInstanceByBirthYear = [](Container &data, int N)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY");
    }
    if (N > data.size())
    {
        throw std::runtime_error("N CANT BE GREATER THAN SIZE OF CONTAINER");
    }
    Container ::iterator it;
    LicenseContainer result;
    it = data.begin();

    for (int i = 0; i < N; i++)
    {
        if (it->get()->getDriverBirthYear() <= 1960)
        {
            result.emplace_back((it->get()->getDriverLicense()));
        }
        it++;
    }
    return result;
};

/*
    A function to find and return the first N driver instances from a container of driver
    instances whose licenseCategory is either commercial or personal
*/

std::function<Container(Container &data, int N)> DriverInstancesByLicenseCategory = [](Container &data, int N)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY");
    }
    if (N > data.size())
    {
        throw std::runtime_error("N CANT BE GREATER THAN SIZE OF CONTAINER");
    }
    Container result;
    Container ::iterator it;
    it = data.begin();
    for (int i = 0; i < N; i++)
    {

        if (it->get()->getDriverLicense().get()->getLicenseCatgory() == LicenseCategory::COMMERCIAL || it->get()->getDriverLicense().get()->getLicenseCatgory() == LicenseCategory::PERSONAL)
        {
            result.emplace_back(*it);
        }
    }
    return result;
};

/*
    A function to find and return all driver instances forma a driver container
    whose license isntances licenseIssuingRTO matches the value passed as an argument
*/

std::function<Container(Container &data, std::string RTO)> DriverInstancesByIssuingRTO = [](Container &data, std::string RTO)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY");
    }
    Container result;
    for (auto &a : data)
    {
        if (a->getDriverLicense().get()->getLicenseIssuingRTO() == RTO)
        {
            result.emplace_back(a);
        }
    }
    return result;
};

/*
    A function to find and return all driver instances from a container
    of driver instances whose license instance licenseIssuingSTATE matches the value passed
    as an argument
*/

std::function<LicenseContainer(Container &data, std::string state)> IssuingStateLicenseInstance =
    [](Container &data, std::string state)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY");
    }
    LicenseContainer result;
    for (auto &a : data)
    {
        if (a->getDriverLicense().get()->getLicenseIssuingState() == state)
        {
            result.emplace_back(a->getDriverLicense());
        }
    }
    return result;
};

/*
    A functio which return all license instances which satisfy the below condition
    1 license validity year is above 8;
    license category is commercial
*/

std::function<LicenseContainer(Container &data)> LicenseInstanceByYearAndCategory =
    [](Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("EMPTY");
    }
    LicenseContainer result;
    for (auto &a : data)
    {

        if (a->getDriverLicense().get()->getLicenseValidityYear() > 8 &&
            a->getDriverLicense().get()->getLicenseCatgory() == LicenseCategory::COMMERCIAL)
        {
            result.emplace_back(a->getDriverLicense());
        }
    }
    return result;
};
