#ifndef DRIVERCATEGORY_H
#define DRIVERCATEGORY_H

#include <iostream>
enum class DriverCategory{
    COMMERCIAL,
    PRIVATE
};

#endif // DRIVERCATEGORY_H
