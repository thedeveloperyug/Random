#include "License.h"
#include <iostream>


/*
    PARAMETRIZED CONSTRUCTOR FOR CALSS LICENSE
*/
License::License(std::string lnumber, int lyear, LicenseCategory licenseCategory_, std::string RTO, std::string State)
:   licenseNumber(lnumber),licenseCatgory(licenseCategory_),licenseIssuingRTO(RTO),licenseIssuingState(State)
{
    if(lyear > 0 && lyear <15){
        this->licenseValidityYear = lyear;
    }
}


/*
    DESTRUCTOR FOR CLASS LICENSE
*/
License::~License()
{
    std::cout<<"LICENSE DESTROYED\n";
}

/*
    A FUNCTION WHICH RETURNS LICENSE CATEGORY
*/

std::string DisplayLicenseCategory(LicenseCategory type)
{
    if(type == LicenseCategory::COMMERCIAL) {return "COMMERCIAL";}
    else if(type == LicenseCategory::PERSONAL) {return "PERSONAL";}
    else{
        return "SPECIAL_PRUPOSE";
    }
}

/*
    OVERLOADED << OPERATOR TO PRINT ALL DETAILS
*/
std::ostream &operator<<(std::ostream &os, const License &rhs) {
    os << "licenseNumber: " << rhs.licenseNumber
       << " licenseValidityYear: " << rhs.licenseValidityYear
       << " licenseCatgory: " << DisplayLicenseCategory(rhs.licenseCatgory)
       << " licenseIssuingRTO: " << rhs.licenseIssuingRTO
       << " licenseIssuingState: " << rhs.licenseIssuingState;
    return os;
}