#include "Driver.h"


/*
    A function which rethrn driver category
*/
std::string DisplayDriverCategory(DriverCategory type)
{
    if(type == DriverCategory::COMMERCIAL) {return "COMMERCIAL";}
    else{
        return "PRIVATE";
    }
}


/*
    Parametrized constructor for class driver
*/
Driver::Driver(std::string Dname, DriverCategory driverCategory_, int birthYear, Reference driverLicense_)
:driverName(Dname) , driverCategory(driverCategory_), driverLicense(driverLicense_)
{
    if(birthYear > 1947 && birthYear <= 2023){
        this->driverBirthYear = birthYear;
    }

}

/*
    A destructor for class Driver
*/
Driver::~Driver()
{
    std::cout<<"DRIVER DESTROYED\n";
}


/*
    overloaded operator << to print all the details of the class Driver
*/
std::ostream &operator<<(std::ostream &os, const Driver &rhs) {
    os << "driverName: " << rhs.driverName
       << " driverCategory: " << DisplayDriverCategory(rhs.driverCategory)
       << " driverBirthYear: " << rhs.driverBirthYear
       << " driverLicense: " << rhs.driverLicense.get();
    return os;
}
