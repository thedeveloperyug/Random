#ifndef LICENSE_H
#define LICENSE_H

#include <iostream>
#include "LicenseCategory.h"

class License
{
private:
    /* data */
    std::string licenseNumber;
    int licenseValidityYear;
    LicenseCategory licenseCatgory;
    std::string licenseIssuingRTO;
    std::string licenseIssuingState;

public:
    License(/* args */) = delete;         // DEFAULT CONSTRUCTOR DISABLED
    License(const License& obj) = default;   //COPY CONSTRUCTOR DISABLED
    License(const License&& obj) = delete;  // MOVE CONSTRUCTOR DISABLED

    // PARAMETRIZED CONSTRUCTORA
    License(std::string lnumber, int lyaer, LicenseCategory licenseCategory_,std::string RTO, std::string State);
    ~License() ;

    std::string getLicenseNumber() const { return licenseNumber; }
    void setLicenseNumber(const std::string &licenseNumber_) { licenseNumber = licenseNumber_; }

    int getLicenseValidityYear() const { return licenseValidityYear; }
    void setLicenseValidityYear(int licenseValidityYear_) { licenseValidityYear = licenseValidityYear_; }

    LicenseCategory getLicenseCatgory() const { return licenseCatgory; }
    void setLicenseCatgory(const LicenseCategory &licenseCatgory_) { licenseCatgory = licenseCatgory_; }

    std::string getLicenseIssuingRTO() const { return licenseIssuingRTO; }
    void setLicenseIssuingRTO(const std::string &licenseIssuingRTO_) { licenseIssuingRTO = licenseIssuingRTO_; }

    std::string getLicenseIssuingState() const { return licenseIssuingState; }
    void setLicenseIssuingState(const std::string &licenseIssuingState_) { licenseIssuingState = licenseIssuingState_; }

    friend std::ostream &operator<<(std::ostream &os, const License &rhs);
    
};

/*
    A FUNCTION WHICH RETURNS LICENSE CATEGORY 
*/
std::string DisplayLicenseCategory(LicenseCategory type);

#endif // LICENSE_H
