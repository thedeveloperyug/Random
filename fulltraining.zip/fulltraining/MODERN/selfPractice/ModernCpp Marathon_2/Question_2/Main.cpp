#include <iostream>
#include "Functionalities.h"

int main()
{
    Container data;
    CreateObjects(data);
    LicenseContainer one = LicenseInstanceByBirthYear(data, 2);
    for (auto &a : one)
    {
        std::cout << a.get() << "\n";
    }
    Container two = DriverInstancesByLicenseCategory(data, 2);
    for (auto &a : two)
    {
        std::cout << *a << "\n";
    }
    Container three = DriverInstancesByIssuingRTO(data, "PCMC");
    for (auto &a : three)
    {
        std::cout << *a << "\n";
    }
}