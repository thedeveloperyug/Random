#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include "Driver.h"
#include "License.h"
#include <list>
#include <memory>
#include <functional>

using Pointer = std::shared_ptr<Driver>;
using Container = std::list<Pointer>;
using LicenseContainer = std::list<std::reference_wrapper<std::shared_ptr<License>>>;

/*
    A function to create object
*/

extern std::function<void(Container& data)> CreateObjects ;

/*
    A function to find and return the first N license Instances from a container
    of driver instances which are referred to by driver instances for which birth year is 1960 or less
*/

extern std::function<LicenseContainer(Container& data,int N)> LicenseInstanceByBirthYear;

/*
    A function to find and return the first N driver instances from a container of driver
    instances whose licenseCategory is either commercial or personal
*/

extern std::function<Container(Container& data,int N)>DriverInstancesByLicenseCategory;

/*
    A function to find and return all driver instances forma a driver container 
    whose license isntances licenseIssuingRTO matches the value passed as an argument
*/

extern std::function<Container(Container& data, std::string RTO)> DriverInstancesByIssuingRTO;

/*
    A function to find and return all driver instances from a container
    of driver instances whose license instance licenseIssuingSTATE matches the value passed
    as an argument
*/

extern std::function<LicenseContainer(Container& data,std::string state)> IssuingStateLicenseInstance;

/*
    A functio which return all license instances which satisfy the below condition
    1 license validity year is above 8;
    license category is commercial
*/

extern std::function<LicenseContainer(Container& data)> LicenseInstanceByYearAndCategory;


#endif // FUNCTIONALITIES_H
