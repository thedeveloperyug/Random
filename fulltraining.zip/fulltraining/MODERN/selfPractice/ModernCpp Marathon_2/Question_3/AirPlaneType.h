#ifndef AIRPLANETYPE_H
#define AIRPLANETYPE_H

#include <iostream>

enum class AirPlaneType
{
    NEO,
    JUMBO,
    CRUISELINEER
};

#endif // AIRPLANETYPE_H
