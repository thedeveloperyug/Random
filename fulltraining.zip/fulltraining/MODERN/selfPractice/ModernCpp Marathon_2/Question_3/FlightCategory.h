#ifndef FLIGHTCATEGORY_H
#define FLIGHTCATEGORY_H

#include <iostream>
enum class FlightTicketCategory
{
    ECONOMY,
    PREMIUM,
    BUSINESS
};
#endif // FLIGHTCATEGORY_H
