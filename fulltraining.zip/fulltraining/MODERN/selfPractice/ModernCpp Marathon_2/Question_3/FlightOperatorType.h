#ifndef FLIGHTOPERATORTYPE_H
#define FLIGHTOPERATORTYPE_H

#include <iostream>

enum class FlightOperatorType
{
    DOMESTIC,
    INTERNATIONAL
};

#endif // FLIGHTOPERATORTYPE_H
