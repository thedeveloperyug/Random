#ifndef CUSTOMER_H
#define CUSTOMER_H

#include<iostream>
#include "CustomerType.h"
#include<variant>
#include<vector>

using TransectionContainer = std::vector<float>;

class Customer
{
private:
    std::variant<int,std::string> _customerId;
    std::string _customerName;
    CustomerType _customerType;
    TransectionContainer _customerTransactionAmounts;
    float _customerStoreCredits;
public:
    Customer() = default;

    
    ~Customer() {}
};

#endif // CUSTOMER_H
