#include<iostream>
#include "Customer.h"
#include "Functionalities.h"
#include "CustomerType.h"
using CustomerContainer=std::vector<Customer>;


int main(){
    CustomerContainer data;
    CreateCustomers(data);

    std::cout<<"Highest amount id :"<<HighestTransactionAmount(data);

    CustomerContainer result=ListOfCustomersOfPraticularType(data,CustomerType::Premium);

    std::cout<<"<----------------------------------->"<<std::endl;
    for(Customer c:result){
        std::cout<<c<<std::endl;
    }
    std::cout<<"<------------------------------------>"<<std::endl;
    
    CustomerContainer r=CreditscoreBetween(data,80,200);

    std::cout<<"<----------------------------------->"<<std::endl;
    for(Customer c:r){
        std::cout<<c<<std::endl;
    }
    std::cout<<"<------------------------------------>"<<std::endl;

    std::cout<<"Credits :"<<SumOFHighAndLowCredits(data);

    std::cout<<"Average :"<<AverageOfCreditOfParticularType(data,CustomerType::vip);

    DeleteCustomers(data);
}