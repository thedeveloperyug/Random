#ifndef CUSTOMER_H
#define CUSTOMER_H

#include<iostream>
#include "CustomerType.h"
#include<vector>

using TransactionAmount=std::vector<double>;


class Customer
{
private:
    int customerId;
    std::string customerName;
    CustomerType customerType;
    TransactionAmount transactionAmount;
    int customerCreditScore;
public:
    Customer()=default;
    Customer(const Customer&)=default;
    Customer(Customer&&)=delete;
    Customer& operator=(const Customer&)=default;
    Customer& operator=(Customer&&)=delete;
    ~Customer()=default;

    int operator+(const Customer &c);
   

    Customer(int customerId,std::string customerName,CustomerType customerType,TransactionAmount transactionAmount,int customerCreditScore);

    explicit Customer(int customerId);

    int getCustomerId() const { return customerId; }
    void setCustomerId(int customerId_) { customerId = customerId_; }

    std::string getCustomerName() const { return customerName; }
    void setCustomerName(const std::string &customerName_) { customerName = customerName_; }

    CustomerType getCustomerType() const { return customerType; }
    void setCustomerType(const CustomerType &customerType_) { customerType = customerType_; }

    TransactionAmount getTransactionAmount() const { return transactionAmount; }
    void setTransactionAmount(const TransactionAmount &transactionAmount_) { transactionAmount = transactionAmount_; }

    int getCustomerCreditScore() const { return customerCreditScore; }
    void setCustomerCreditScore(int customerCreditScore_) { customerCreditScore = customerCreditScore_; }

    friend std::ostream &operator<<(std::ostream &os, const Customer &rhs);

};

void DisplayVector(const TransactionAmount tm);
std::string EnumCustomerType(const CustomerType c);
#endif // CUSTOMER_H
