#include "Customer.h"

int Customer::operator+(const Customer &c)
{
    return customerCreditScore+c.customerCreditScore;
}

Customer::Customer(int customerId, std::string customerName, CustomerType customerType, TransactionAmount transactionAmount, int customerCreditScore)
    : customerId(customerId), customerName(customerName), customerType(customerType), transactionAmount(transactionAmount), customerCreditScore(customerCreditScore) {}

Customer::Customer(int customerId)
:customerId(customerId) {}

std::ostream &operator<<(std::ostream &os, const Customer &rhs) {
    os << "customerId: " << rhs.customerId
       << " customerName: " << rhs.customerName
       << " customerType: " << EnumCustomerType(rhs.customerType)
       << " transactionAmount: \n";
        DisplayVector(rhs.transactionAmount);
    os   << " customerCreditScore: " << rhs.customerCreditScore;
    return os;
}
void DisplayVector(const TransactionAmount tm)
{
    for(double d:tm){
        std::cout<<d<<std::endl;
    }
}
std::string EnumCustomerType(const CustomerType c)
{
    if(c==CustomerType::Premium){
        return "PREMIUM";
    }else if(c==CustomerType::regular){
        return "Regular";
    }else{
        return "VIP";
    }
}
