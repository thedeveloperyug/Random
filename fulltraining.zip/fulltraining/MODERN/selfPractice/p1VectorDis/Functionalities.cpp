#include "Functionalities.h"
#include<limits.h>

void CreateCustomers(CustomerContainer &data)
{
    Customer c1(101,"Naveen",CustomerType::Premium,{1,2,3,4,5},89);
    Customer c2(102,"Ravi",CustomerType::regular,{1,2,3,4,5},112);
    Customer c3(103,"Shivam",CustomerType::vip,{1,2,3,4,5},34);
    Customer c4(104,"Sankuri",CustomerType::Premium,{1,2,3,4,5},209);

    data.push_back(c1);
    data.push_back(c2);
    data.push_back(c3);
    data.push_back(c4);
}

void DeleteCustomers(CustomerContainer &data)
{
    std::cout<<"***************"<<std::endl;
}

int HighestTransactionAmount(CustomerContainer &data)
{
    int id=0;
    double amount=0,sum;
    for(Customer c:data){
        sum=0;
        for(double d:c.getTransactionAmount()){
            sum+=d;
        }
        if(amount<sum){
            id=c.getCustomerId();
            amount = sum;
        }
    }
    return id;
    
}

CustomerContainer ListOfCustomersOfPraticularType(CustomerContainer &data, CustomerType ct)
{
    CustomerContainer result;
    for(Customer c:data){
        if(ct==c.getCustomerType()){
            result.push_back(c);
        }
    }
    return result;
}

CustomerContainer CreditscoreBetween(CustomerContainer &data, int high, int low)
{
    CustomerContainer result;
    for(Customer c:data){
        if(c.getCustomerCreditScore()>=low&&c.getCustomerCreditScore()<=high){
            result.push_back(c);
        }
    }
    return result;
}

int SumOFHighAndLowCredits(CustomerContainer &data)
{
    int low=INT_MAX,high=0;
    for(Customer c:data){
        if(low>c.getCustomerCreditScore()){
            low=c.getCustomerCreditScore();
        }
        if(high<c.getCustomerCreditScore()){
            high=c.getCustomerCreditScore();
        }
    }
    return low+high;
}

double AverageOfCreditOfParticularType(CustomerContainer &data, CustomerType ct)
{
    double avg=0;
    int count=0;
    for(Customer c:data){
        if (ct == c.getCustomerType()) {
            count++;
            avg+=c.getCustomerCreditScore();
        }
    }

    return avg/count;
}
