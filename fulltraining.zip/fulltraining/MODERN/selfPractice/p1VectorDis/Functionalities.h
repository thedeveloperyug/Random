#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include "Customer.h"
#include<vector>

using CustomerContainer=std::vector<Customer>;


void CreateCustomers(CustomerContainer&data);

void DeleteCustomers(CustomerContainer&data);


int HighestTransactionAmount(CustomerContainer& data);

CustomerContainer ListOfCustomersOfPraticularType(CustomerContainer&data,CustomerType ct);

CustomerContainer CreditscoreBetween(CustomerContainer&data,int high,int low);

int SumOFHighAndLowCredits(CustomerContainer&data);

double AverageOfCreditOfParticularType(CustomerContainer&data,CustomerType ct);

#endif // FUNCTIONALITIES_H
