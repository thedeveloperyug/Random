#ifndef CUSTOMERTYPE_H
#define CUSTOMERTYPE_H

enum class CustomerType{
    Premium,
    regular,
    vip
};

#endif // CUSTOMERTYPE_H
