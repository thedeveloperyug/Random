#include<iostream>
#include "Car.h"
#include "Bike.h"
#include "Type.h"
#include<memory>
#include<variant>
#include<optional>
#include<list>
#include "Functionalities.h"


using BikePointer = std::shared_ptr<Bike>;
using CarPointer = std::shared_ptr<Car>;

using VType = std::variant< BikePointer, CarPointer >;

using Container = std::list<VType>;

int main()
{
    Container data;

    CreateObject(data);  

    try
    {
        std::cout << "\nAverage Price is: "<<AveragePrice(data)<<std::endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        std::cout<<"Brand Price: "<<ReturnBrandMaxPrice(data)<<std::endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    std::optional<std::list<Type>> result;

    try
    {
        result=FindVehicleType(data,800000.0f);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    if(result.has_value()) {
        for(auto i:result.value())
        {
            std::cout<<DisplayEnum(i)<<std::endl;   //Why Printed byDefault Value ?
        }
    }
    
    else{
        std::cout<<"\nNo vehicle found above threshold"<<std::endl;
        }

    
    try
    {
        std::cout<<"All Type is Same or Not: "<<CheckVehicleTypeSame(data)<<std::endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
     
}