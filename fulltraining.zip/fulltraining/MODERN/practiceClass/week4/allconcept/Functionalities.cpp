#include "Functionalities.h"

void CreateObject(Container& data)
{
    data.push_back(
        std::make_shared<Bike>(50000.0f,"Honda",Type::SPORTS,2)  //we should directly make object by taking any class
    );

    data.push_back(
        std::make_shared<Car>(800000.0f,"BMW",Type::SPORTS,4)
    );

    data.push_back(
        std::make_shared<Car>(1000000.0f,"Renault",Type::SPORTS,6)
    );

    data.push_back(
        std::make_shared<Bike>(100000.0f,"Yamaha",Type::COMMUTE,1)
    );
}

float AveragePrice(Container& data)
{
    if(data.empty()) {
        throw std::runtime_error("No objects received");
    }

    float total = std::accumulate(data.begin(),data.end(),0.0f,
    [](float ans, VType obj ) {

        std::visit([&](auto&& val){
            ans += val->getPrice();        //VISIT for variant
        },obj);

        return ans;

      }
    );

    return total/data.size();
}



std::string ReturnBrandMaxPrice(Container &data)
{
    if(data.empty()) {
        throw std::runtime_error ("No objects received.");
    }
    
    auto itr = std::max_element(data.begin(),data.end(),

    [](VType& obj1,VType& obj2) {

        float a=0.0f,b=0.0f;

        std::visit([&](auto&& val1,auto&& val2) {
            a=val1->getPrice(); b=val2->getPrice();
        },obj1,obj2);                                  //std::visit([&](auto&& val) {a=val->getPrice()});
                                                            //std::visit([&](auto&& val) {b=val->getPrice()});
          //Comparator body

          return a<b;        //check and return the maximum object in the container
      }

    );

    std::string ans;

    std::visit( [&] (auto&& val) {
        ans = val->getBrand();
    },*itr);

    return ans;
}

std::optional<std::list<Type>> FindVehicleType(Container &data, float threshold)
{
    if(data.empty()) {
        throw std::runtime_error("Empty input");
    }

    // if(threshold > data.size())
    // {
    //     throw std::runtime_error("Input Invalid");
    // }

    std::list<Type> result(data.size());

    auto count = result.begin();
    for(auto i:data)
    {
        std::visit([&](auto&& val){
            if(val->getPrice() < threshold)
            {
                result.push_back(val->getVehicleType());
                count++;
            }
        },i);
        
    }

    result.resize(std::distance(result.begin(),count));

    if(result.empty()) {
        return std::nullopt;
    }
    return  result ;
    
}

bool CheckVehicleTypeSame(Container &data)
{
    if(data.empty()) {
        throw std::runtime_error("Data Empty");
    }
    
    bool flag = true;

    auto Vtype = std::visit([&](auto&& v){
        return v->getVehicleType();
    },data.front());

    for(auto i:data)
    {
        if(flag == false)
        {
            break;
        }
        std::visit([&](auto&& val){
            if(val->getVehicleType() == Vtype)
            {
                flag = true;
            }
            else{
                flag = false;
                
            }
        },i);

    }
    
    return flag;
}
