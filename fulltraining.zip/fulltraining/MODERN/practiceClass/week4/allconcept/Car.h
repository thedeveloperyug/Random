#ifndef CAR_H
#define CAR_H

#include <iostream>
#include "Type.h"

class Car
{
private:
    float carPrice;
    std::string carBrand;
    Type carVehicleType;
    int carSeatCount;

public:
    Car() = delete;

    Car(const Car &) = delete;

    Car &operator=(Car &) = delete;

    Car(Car &&) = delete;

    Car &operator=(Car &&) = delete;

    ~Car() = default;

    Car(float price, std::string brand, Type cType, int count);

    float getPrice() const { return carPrice; }

    std::string getBrand() const { return carBrand; }

    Type getVehicleType() const { return carVehicleType; }

    int getSeatCount() const { return carSeatCount; }

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
};

#endif // CAR_H
