#ifndef TYPE_H
#define TYPE_H

#include<iostream>

enum class Type
{
    UTILITY,
    SPORTS,
    PASSENGER,
    COMMUTE
};

inline std::string DisplayEnum(Type val)
{
    if(val == Type::COMMUTE)
      return "COMMUTE";

    else if(val == Type::PASSENGER)
      return "PASSENGER";

    else if(val == Type::SPORTS)
      return "SPORTS";

    else
      return "UTILITY";  
}

#endif // TYPE_H
