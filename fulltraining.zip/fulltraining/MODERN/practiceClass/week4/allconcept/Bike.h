#ifndef BIKE_H
#define BIKE_H

#include<iostream>
#include "Type.h"

class Bike
{
private:
    float bikePrice;
    std::string bikeBrand;
    Type bikeVehicleType;
    int bikeSeatCount;
public:
    Bike() = delete;

    Bike(const Bike &) = delete;

    Bike &operator=(Bike &) = delete;

    Bike(Bike &&) = delete;

    Bike &operator=(Bike &&) = delete;

    ~Bike() = default;

    Bike(float bPrice,std::string bBrand,Type bType,int bSeatCount);

    float getPrice() const { return bikePrice; }

    std::string getBrand() const { return bikeBrand; }

    Type getVehicleType() const { return bikeVehicleType; }

    int getSeatCount() const { return bikeSeatCount; }

    friend std::ostream &operator<<(std::ostream &os, const Bike &rhs);
    
};

#endif // BIKE_H
