#include "Bike.h"

std::ostream &operator<<(std::ostream &os, const Bike &rhs) {
    os << "bikePrice: " << rhs.bikePrice
       << " bikeBrand: " << rhs.bikeBrand
       << " bikeVehicleType: " <<DisplayEnum(rhs.bikeVehicleType)
       << " bikeSeatCount: " << rhs.bikeSeatCount;
    return os;
}

Bike::Bike(float bPrice, std::string bBrand, Type bVehicleType, int bSeatCount)
: bikePrice(bPrice),bikeBrand(bBrand),bikeVehicleType(bVehicleType),bikeSeatCount(bSeatCount)
{
    if(bSeatCount <1 || bSeatCount >2)
    {
        throw std::invalid_argument("Invalid number of seats");
    }
}
