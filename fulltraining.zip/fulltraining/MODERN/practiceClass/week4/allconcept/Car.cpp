#include "Car.h"

std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << "carPrice: " << rhs.carPrice
       << " carBrand: " << rhs.carBrand
       << " carVehicleType: " <<DisplayEnum(rhs.carVehicleType)
       << " carSeatCount: " << rhs.carSeatCount;
    return os;
}

Car::Car(float price, std::string brand, Type cType, int count)
: carPrice(price),carBrand(brand),carVehicleType(cType)
{
    if(count<2 || count > 7) {
        throw std::invalid_argument("Invalid number of seats");
    }

    carSeatCount=count;
}
