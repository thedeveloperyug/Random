#include<iostream>
#include "Car.h"
#include "Bike.h"
#include "Type.h"
#include<memory>
#include<variant>
#include<optional>
#include<list>
#include<numeric>
#include<algorithm>


using BikePointer = std::shared_ptr<Bike>;
using CarPointer = std::shared_ptr<Car>;

using VType = std::variant< BikePointer, CarPointer >;

using Container = std::list<VType>;


void CreateObject(Container& data);  //Function for Creating the Object..

float AveragePrice(Container& data);  //Function for finding the Average..

std::string ReturnBrandMaxPrice(Container& data);

std::optional< std::list<Type> > FindVehicleType(Container& data, float threshold);

bool CheckVehicleTypeSame(Container& data);

