#include<iostream>
#include<algorithm>

#include<vector>

int main()
{
    std::vector<int> data {1,2,3,4,5};
    std::vector<int> result {0,0,0,0,0};

    std::transform(
        data.begin(),
        data.end(),
        result.begin(),   //destination starting
        [](int number) {return number * number;}
    );

    for(auto i: result)
    {
        std::cout<<i<<" ";
    }

    std::for_each(
    data.begin(),
    data.end(),
    
    [](int number) { std::cout<< number * number;}
    );
}
