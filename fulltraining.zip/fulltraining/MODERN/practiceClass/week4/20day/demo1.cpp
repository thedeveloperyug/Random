#include<iostream>
#include<unordered_map>
#include "Employee.h"
#include<algorithm>
#include<numeric>

#include <memory>

using Pointer = std::shared_ptr<Employee>;

int main()
{
    //Single key attached to a single object   ---> //Key = int ,  Value = Pointer or it could be anything
/*  Inserting the value at innitializing the object */
    std::unordered_map< int, Pointer >  data {

        {101,std::make_shared<Employee>(101,90000.0f,"Shivam")},
        {102,std::make_shared<Employee>(102,89000.0f,"Rohan")},
        {102,std::make_shared<Employee>(102,19000.0f,"Riya")},      //Duplicate elements will not be added to the row
        
    };     
      
      data.emplace(
        103,
        std::make_shared<Employee>(103,289990.0f,"Kaya")
      );

      std::cout<<"data chaeck: "<<*data[102]<<std::endl;

//,,,,,,,output does not show of duplicate key
    for(auto [k,v] : data)
    {
        std::cout<<"Key is: "<<k<<std::endl;
        std::cout<<"Value is: "<<v<<std::endl;
        std::cout<<"Value is: "<<*v<<std::endl<<std::endl<<std::endl;

    }

    //check total number of rows (buckets) of hash table (currently)

    std::cout<<"Total Buckets: "<<data.bucket_count();

    //check which row (bucket) a particular key belong to
    std::cout<<"\nSlot(row/bucket) for 102 key: "<<data.bucket(102)<<"\n";

    //check total number of elements in the unordered_map

    std::cout<<"Total elements in unordered_map: "<<data.size()<<std::endl;

    /*
           count intances with salary over 90000.0f

    */

   std::cout
      << "\nNumber of items with above 90000.0f: "

      << std::count_if(
          data.begin(),
          data.end(),
         [](auto& obj1) {
         return obj1.second->salary() > 90000.0f;
       }
  );

   //total salary

   std::cout<<"\nTotal salary for all objects: "

   << std::accumulate(
    data.begin(),
    data.end(),
    0.0f,
    [](float ans, auto& obj)
    {
      return ans +obj.second->salary();
    }

  );

   std::cout<<"\nCheck all employees with above 80000.0f"
   <<" Salary: 0 means false, 1 means true: "
   << std::all_of(
    data.begin(),
    data.end(),
    [](const auto& obj) {
      return obj.second->salary() > 80000.0f;
    }

  );

   std::cout<<"\nMaximum Salary: ";
   auto itr = std::max_element(
    data.begin(),
    data.end(),
    [](auto& obj1, auto& obj2) {
      return obj1.second->salary() < obj2.second->salary();
    }
  );
  std::cout<<*itr->second<<std::endl;
   
}