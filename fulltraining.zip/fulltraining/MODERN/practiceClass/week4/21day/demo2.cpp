#include<iostream>
#include<algorithm>
#include<vector>
#include "Employee.h"
#include<functional>


template<typename T, typename f>
void demo(std::vector<T> first, std::vector<T> second, std::function<f> fn)
{
    
}

int main()
{
    std::vector<int> data1 {1,2,3,4,5};
    std::vector<int> data2 {1,2,3,4,5};
    std::vector<Employee*> data3 {
        new Employee(101,678999.0f,"Shivam"),
        new Employee(102,708999.0f,"Rohan"),
        new Employee(102,768999.0f,"Riya")
    };

    //find the first of on primitive non user-defined data
    auto itr = std::find_first_of(
        data1.begin(),
        data1.end(),
        data2.begin(),
        data2.end()
    );

    if(itr == data1.end())
    {
        std::cout<<"Nothing Common found"<<std::endl;
    }

    else{
        std::cout<<"Data found"
        <<" at the position: "<<std::distance(data1.begin(),itr)
        <<" and the common item:  "<<*itr<<std::endl;
    }
}