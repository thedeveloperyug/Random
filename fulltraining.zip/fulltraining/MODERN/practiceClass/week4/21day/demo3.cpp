#include<iostream>
#include<algorithm>
#include<vector>
#include "Employee.h"
#include<functional>

//vector <5> [  v1,v2,v3,v4,v5, ]

int f() {
    static int i=0;
    
    return i += 2;
}


int main()
{
    
    std::vector<int> data(10);
    std::generate (data.begin(), data.end(),&f );      //[ 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 ]

    std::for_each(
        data.begin(),
        data.end(),
        [](int val) { std::cout<< "VALUE: "<<val<<"\n";}
    );


}