#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include<iostream>

class Employee
{
private:
    int _id;
    float _salary;
    std::string _name;
public:
    Employee() = delete;
    Employee(const Employee&) = delete;
    Employee(Employee&&) = delete;
    Employee& operator=(const Employee&) = delete;
    Employee& operator=(Employee&&) = delete;
    Employee(int id,float salary,std::string name)
       : _id(id),_salary(salary),_name(name) {}

    float CalculateTax() {
        return _salary * 0.01f;
    }

    ~Employee() = default;

    float salary() const { return _salary; }

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);

    
};

inline std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "_id: " << rhs._id
       << " _salary: " << rhs._salary
       << " _name: " << rhs._name;
    return os;
}

#endif // EMPLOYEE_H