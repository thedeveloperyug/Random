#include<iostream>
#include "Sensor.h"
#include "SensorType.h"
#include<memory>
#include<list>
#include "Functionalities.h"
#include<optional>

using Pointer = std::shared_ptr<Sensor>;
using Container = std::list<Pointer>;

int main()
{
    Container data;

    try
    {
        CreateObject(data);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    try
    {
        std::cout<<"\nCheck Reading of all Sensors are above 25: "<<CheckReading(data)<<std::endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        std::cout<<"Count of type TEMPREATURE: "<<CountByType(data,SensorType::TEMPREATURE)<<std::endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        std::optional<Container> result = SensorContainer(data);

        if(result.has_value())
        {
            for(auto i : result.value())
            {
                std::cout<<*i<<std::endl;
            }
        }

        else
        {
            std::cout<<"Data is Empty"<<std::endl;
        }
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    
    
}