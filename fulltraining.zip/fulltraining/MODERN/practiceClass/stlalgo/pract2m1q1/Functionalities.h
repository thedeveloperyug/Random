#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include "Sensor.h"
#include "SensorType.h"
#include<memory>
#include<list>
#include<numeric>
#include<algorithm>
#include<optional>

using Pointer = std::shared_ptr<Sensor>;
using Container = std::list<Pointer>;

//Function for creating the object
void CreateObject(Container& data);

//Function for find and return true and false if reading is over 25 
bool CheckReading(Container& data);

//Function to match the type and count as passed as argument
int CountByType(Container& data,SensorType type);


//Functional to return the Container which Satisfy the condition
std::optional<Container> SensorContainer(Container& data);

#endif // FUNCTIONALITIES_H
