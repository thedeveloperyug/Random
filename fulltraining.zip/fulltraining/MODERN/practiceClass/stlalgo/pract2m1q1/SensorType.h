#ifndef SENSORTYPE_H
#define SENSORTYPE_H

enum class SensorType
{
    TYRE_PRESSURE,
    TEMPREATURE,
    CABIN_PRESSURE
};

#endif // SENSORTYPE_H
