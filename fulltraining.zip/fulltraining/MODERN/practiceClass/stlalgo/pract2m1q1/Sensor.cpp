#include "Sensor.h"

Sensor::Sensor(int id, std::string name, SensorType type, int reading)
: _id(id),_name(name),_type(type),_reading(reading)
{
    if((reading < 0 && reading > 20) && reading%10!=0 )
    {
        throw std::runtime_error("Invalid reading value");
    }
}
std::ostream &operator<<(std::ostream &os, const Sensor &rhs) {
    os << "_id: " << rhs._id
       << " _name: " <<DisplayEnum(rhs._type)
       << " _reading: " << rhs._reading;
    return os;
}

std::string DisplayEnum(SensorType type)
{
    if(type == SensorType::CABIN_PRESSURE)
        return "CABIN_PRESSURE";
    else if(type == SensorType::TEMPREATURE)
        return "TEMPREATURE";
    else
        return "TYRE_PRESURE";
}
