#include "Functionalities.h"


void CreateObject(Container &data)
{
    data.push_back(std::make_shared<Sensor>(101,"Digital",SensorType::CABIN_PRESSURE,5));
    data.push_back(std::make_shared<Sensor>(102,"Chip",SensorType::TYRE_PRESSURE,9));
    data.push_back(std::make_shared<Sensor>(103,"Silicon",SensorType::TEMPREATURE,15));
    data.push_back(std::make_shared<Sensor>(104,"Vaily",SensorType::TEMPREATURE,19));
    data.push_back(std::make_shared<Sensor>(105,"Embeed",SensorType::TYRE_PRESSURE,12));

}

bool CheckReading(Container &data)
{
    if(data.empty())
    {
        throw std::runtime_error("data empty");
    }
    auto flag = std::all_of(
        data.begin(),
        data.end(),
        [](const Pointer& p) {
            return p->reading() > 25;
        }
    );

    return flag;
}

int CountByType(Container &data,SensorType type)
{
    auto count = std::count_if(
        data.begin(),
        data.end(),
        [&](const Pointer& p) {
            return p->type() == type;
        }
    );

    return count;
}

std::optional<Container> SensorContainer(Container &data)
{
    Container result(data.size());

    auto itr = std::copy_if(
        data.begin(),
        data.end(),
        result.begin(),
        [](const Pointer& p) {
            return p->reading() > 15 && p->type() == SensorType::TYRE_PRESSURE;
        }
    );

    result.resize(std::distance(result.begin(),itr));

    if(result.empty())
    {
        return std::nullopt;
    }

    return result;
}
