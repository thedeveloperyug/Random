#include "TouristVehicle.h"

TouristVehicle::TouristVehicle(std::string _number, TouristVehicleType _type, int _seat_count, float _per_hour_booking_charges, PermitPointer _permit)
: _number(_number),_type(_type),_seat_count(_seat_count),_per_hour_booking_charges(_per_hour_booking_charges),_permit(_permit)
{
}

std::ostream &operator<<(std::ostream &os, const TouristVehicle &rhs) {
    os << "_number: " << rhs._number
       << " _type: " <<DisplayTouristType(rhs._type)
       << " _seat_count: " << rhs._seat_count
       << " _per_hour_booking_charges: " << rhs._per_hour_booking_charges
       << " _permit: " << *rhs._permit.get();
    return os;
}

std::string DisplayTouristType(TouristVehicleType type)
{
    if(type == TouristVehicleType::BIKE)
    {
        return "BIKE";
    }
    else if(type == TouristVehicleType::BUS)
    {
        return "BUS";
    }
    else
    {
        return "CAB";
    }
}
