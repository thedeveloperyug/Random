#ifndef PERMITTYPE_H
#define PERMITTYPE_H

enum class PermitType
{
    LEASE,
    OWNED
};

#endif // PERMITTYPE_H
