#include "Bill.h"

Bill::Bill(float billAmount, float billTaxAmount, Rinvoice billAssociateInvoice)
: billAmount(billAmount),billTaxAmount(billTaxAmount),billAssociateInvoice(billAssociateInvoice)
{
    if(billTaxAmount >= billAmount)
    {
        throw std::runtime_error("Tax Amount is Invalid");
    }
}
std::ostream &operator<<(std::ostream &os, const Bill &rhs) {
    os << "billAmount: " << rhs.billAmount
       << " billTaxAmount: " << rhs.billTaxAmount
       << " billAssociateInvoice: " << *(rhs.billAssociateInvoice.get());
    return os;
}
