#include "Functionalities.h"
#include<numeric>
#include<algorithm>

void CreateObject(ContainerBill &billdata, ContainerInvoice &invoicedata)
{
    invoicedata.push_back(std::make_shared<Invoice>("In101",InvoiceType::E_BILL,2));
    invoicedata.push_back(std::make_shared<Invoice>("In102",InvoiceType::PAPER_SLIP,3));
    invoicedata.push_back(std::make_shared<Invoice>("In103",InvoiceType::E_BILL,4));
    invoicedata.push_back(std::make_shared<Invoice>("In104",InvoiceType::SMS_GENERATED,5));

    billdata.push_back(std::make_shared<Bill>(500.0f,50.0f,std::ref(invoicedata[0])));
    billdata.push_back(std::make_shared<Bill>(1000.0f,100.0f,std::ref(invoicedata[1])));
    billdata.push_back(std::make_shared<Bill>(700.0f,80.0f,std::ref(invoicedata[2])));
    billdata.push_back(std::make_shared<Bill>(800.0f,60.0f,std::ref(invoicedata[3])));
}

std::string InvoiceNumberMaxBill(ContainerBill &billdata)
{
    if(billdata.empty())
    {
        throw std::runtime_error("data is empty");
    }
    auto itr = std::max_element(
        billdata.begin(),
        billdata.end(),
        [](const PointerBill& b1,const PointerBill& b2) {
            return b1->getBillAmount() < b2->getBillAmount();
        }
    );

    return itr->get()->getBillAssociateInvoice().get()->getInvoiceNumber();
}

float BillAmountWithInvoiceNumber(ContainerBill &billdata, std::string inumber)
{
    if(billdata.empty())
    {
        throw std::runtime_error("data is empty");
    }

    auto itr = std::find_if(
        billdata.begin(),
        billdata.end(),
        [&](const PointerBill& b) {
            return b->getBillAssociateInvoice().get()->getInvoiceNumber() == inumber;
        }
    );

    return itr->get()->getBillAmount();
}

std::optional<ContainerBill> BillInvoiceAmountAboveThershold(ContainerBill &billdata, float thershold)
{
    if(billdata.empty())
    {
        throw std::runtime_error("data is empty");
    }
    ContainerBill result(billdata.size());

    auto itr = std::copy_if(
        billdata.begin(),
        billdata.end(),
        result.begin(),
        [&](const PointerBill& b) {
            return b->getBillAmount() > thershold;
        }
    );

    result.resize(std::distance(result.begin(),itr));

    if(result.empty())
    {
        return std::nullopt;
    }

    return result;
}

void InvoiceNumberPrint(ContainerBill &billdata)
{
    if(billdata.empty())
    {
        throw std::runtime_error("data is empty");
    }
    
    auto high = std::max_element(
        billdata.begin(),
        billdata.end(),
        [](const PointerBill& b1,const PointerBill& b2) {
            return b1->getBillAmount() < b2->getBillAmount();
        }
    );

    auto low = std::min_element(
        billdata.begin(),
        billdata.end(),
        [](const PointerBill& b1,const PointerBill& b2) {
            return b1->getBillAmount() < b2->getBillAmount();
        }
    );

    std::cout<<"\nInvoice number with max Bill amount: "<<high->get()->getBillAssociateInvoice().get()->getInvoiceNumber()<<std::endl;
    std::cout<<"\nInvoice number with min Bill amount: "<<low->get()->getBillAssociateInvoice().get()->getInvoiceNumber()<<std::endl;

}
