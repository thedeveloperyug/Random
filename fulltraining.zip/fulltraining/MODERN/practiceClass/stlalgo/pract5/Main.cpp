#include<iostream>
#include "Invoice.h"
#include "Bill.h"
#include<vector>
#include<memory>
#include<list>
#include "Functionalities.h"
#include<optional>

using PointerBill = std::shared_ptr<Bill>;
using ContainerBill = std::vector<PointerBill>;
using ContainerInvoice = std::vector<PointerInvoice>;

int main()
{
    ContainerBill billdata;
    ContainerInvoice invoicedata;

    CreateObject(billdata,invoicedata);

    try
    {
        std::cout<<"Invoice number whose Bill amount is highest: "<<InvoiceNumberMaxBill(billdata)<<std::endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        std::cout<<"\nBill Amount: "<<BillAmountWithInvoiceNumber(billdata,"In103")<<std::endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        std::optional<ContainerBill> result = BillInvoiceAmountAboveThershold(billdata,700.0f);

        if(result.has_value())
        {
            for(auto i: result.value())
            {
                std::cout<<*i->getBillAssociateInvoice().get()<<std::endl;
            }
        }
        else
        {
            std::cout<<"\nContainer is empty"<<std::endl;
        }
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        InvoiceNumberPrint(billdata);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    
    
    
}