#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include "Invoice.h"
#include "Bill.h"
#include<vector>
#include<memory>
#include<list>
#include<numeric>
#include<algorithm>
#include<optional>

using PointerBill = std::shared_ptr<Bill>;
using ContainerBill = std::vector<PointerBill>;
using ContainerInvoice = std::vector<PointerInvoice>;

void CreateObject(ContainerBill& billdata,ContainerInvoice& invoicedata);

std::string InvoiceNumberMaxBill(ContainerBill& billdata);

float BillAmountWithInvoiceNumber(ContainerBill& billdata,std::string inumber);

std::optional<ContainerBill> BillInvoiceAmountAboveThershold(ContainerBill& billdata,float thershold);

void InvoiceNumberPrint(ContainerBill& billdata);

#endif // FUNCTIONALITIES_H
