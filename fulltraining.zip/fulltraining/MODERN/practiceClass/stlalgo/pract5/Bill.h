#ifndef BILL_H
#define BILL_H

#include<iostream>
#include "Invoice.h"
#include<memory>

using PointerInvoice = std::shared_ptr<Invoice>;
using Rinvoice = std::reference_wrapper<PointerInvoice>;

class Bill
{
private:
    float billAmount;
    float billTaxAmount;
    Rinvoice billAssociateInvoice;
public:
    Bill() = delete;
    Bill(Bill&) = delete;
    Bill(Bill&&) = delete;
    Bill& operator=(const Bill&) = default;
    Bill& operator=(Bill &&) noexcept=default ;
    ~Bill() = default;

    Bill(float billAmount,float billTaxAmount,Rinvoice billAssociateInvoice);

    float getBillAmount() const { return billAmount; }

    float getBillTaxAmount() const { return billTaxAmount; }

    Rinvoice getBillAssociateInvoice() const { return billAssociateInvoice; }

    friend std::ostream &operator<<(std::ostream &os, const Bill &rhs); 
};

#endif // BILL_H
