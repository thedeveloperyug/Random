#ifndef INVOICE_H
#define INVOICE_H

#include<iostream>
#include "InvoiceType.h"

class Invoice
{
private:
    std::string invoiceNumber;
    InvoiceType invoiceType;
    int  invoiceItems;
public:
    Invoice() = delete;
    Invoice(Invoice&) = delete;
    Invoice(Invoice&&) = delete;
    Invoice& operator=(const Invoice&) = default;
    Invoice& operator=(Invoice &&) noexcept=default ;
    ~Invoice() = default;

    Invoice(std::string invoiceNumber,InvoiceType invoiceType,int  invoiceItems);

    std::string getInvoiceNumber() const { return invoiceNumber; }

    InvoiceType getInvoiceType() const { return invoiceType; }

    int getInvoiceItems() const { return invoiceItems; }

    friend std::ostream &operator<<(std::ostream &os, const Invoice &rhs);
    
};

std::string DisplayInvoiceType(InvoiceType type);

#endif // INVOICE_H
