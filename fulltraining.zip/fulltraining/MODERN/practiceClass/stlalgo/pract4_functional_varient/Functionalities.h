#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include <iostream>
#include "Automobile.h"
#include "Engine.h"
#include "AutomobileType.h"
#include "EngineType.h"
#include<memory>
#include<vector>
#include<array>
#include<functional>

using EngineContainer = std::vector<std::shared_ptr<Engine>>;
using PointerAutomobile = std::shared_ptr<Automobile>;
using AutomobileContainer = std::vector<PointerAutomobile>;

void CreateObject(AutomobileContainer& Adata, EngineContainer& Edata);

#endif // FUNCTIONALITIES_H
