#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType
{
    ICE,
    HYBRID,
    ELECTRIC
};

#endif // ENGINETYPE_H
