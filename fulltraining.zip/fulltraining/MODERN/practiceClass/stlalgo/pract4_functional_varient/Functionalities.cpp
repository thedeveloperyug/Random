#include "Functionalities.h"

void CreateObject(AutomobileContainer &Adata, EngineContainer &Edata)
{
    Edata.push_back(std::make_shared<Engine>(EngineType::ELECTRIC,100,30.0f));
    Edata.push_back(std::make_shared<Engine>(EngineType::HYBRID,200,30.0f));
    Edata.push_back(std::make_shared<Engine>(EngineType::ICE,300,30.0f));
    Edata.push_back(std::make_shared<Engine>(EngineType::ELECTRIC,250,30.0f));
    Edata.push_back(std::make_shared<Engine>(EngineType::ICE,120,30.0f));

    auto itr=Edata.begin();

    Adata.push_back(std::make_shared<Automobile>(101,std::vector<float>{2.0f,5.5f,3.0f,4.0f},AutomobileType::COMMUTE,std::ref(*itr++)));
    Adata.push_back(std::make_shared<Automobile>(201,std::array<float,4>{2.0f,3.5f,4.0f,5.0f},AutomobileType::SPECIAL,std::ref(Edata[1])));
    Adata.push_back(std::make_shared<Automobile>(301,std::vector<float>{2.0f,3.5f,4.0f,5.0f},AutomobileType::TRANSPORT,std::ref(Edata[2])));
    Adata.push_back(std::make_shared<Automobile>(401,std::array<float,4>{2.0f,3.5f,4.0f,5.0f},AutomobileType::COMMUTE,std::ref(Edata[3])));
    Adata.push_back(std::make_shared<Automobile>(501,std::vector<float>{2.0f,3.5f,4.0f,5.0f},AutomobileType::SPECIAL,std::ref(Edata[4])));
}



void HigherOrder(AutomobileContainer& data,std::function<void(AutomobileContainer&)> fn);