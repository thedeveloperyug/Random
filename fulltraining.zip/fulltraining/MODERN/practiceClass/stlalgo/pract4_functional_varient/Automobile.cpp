#include "Automobile.h"

Automobile::Automobile(std::variant<std::string, int> id, std::variant<std::vector<float>, std::array<float, 4>> tyre_pressure_reading, AutomobileType type, RType engine)
: _id(id),_tyre_pressure_reading(tyre_pressure_reading),_type(type),_engine(engine)
{
}
std::ostream &operator<<(std::ostream &os, const Automobile &rhs) {
    os << "_id: ";
    std::visit([&](auto&& a){ os << a;},rhs._id);
    os << " _tyre_pressure_reading: ";
    std::visit([&](auto&& a){
        for(auto i: a )
        {
            os <<i<<" ";
        }
    },rhs._tyre_pressure_reading);
    os   << " _type: " <<DisplayAutomobile(rhs._type)
       << " _engine: " << *rhs._engine.get();
    return os;
}

std::string DisplayAutomobile(AutomobileType type)
{
    if(type == AutomobileType::COMMUTE)
    {
        return "COMMUTE";
    }
    else if(type == AutomobileType::SPECIAL)
    {
        return "SPECIAL";
    }
    else
    {
        return "TRANSPORT";
    }
}
