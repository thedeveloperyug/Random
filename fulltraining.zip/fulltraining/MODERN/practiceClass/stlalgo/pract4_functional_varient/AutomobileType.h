#ifndef AUTOMOBILETYPE_H
#define AUTOMOBILETYPE_H

enum class AutomobileType
{
    TRANSPORT,
    COMMUTE,
    SPECIAL
};

#endif // AUTOMOBILETYPE_H
