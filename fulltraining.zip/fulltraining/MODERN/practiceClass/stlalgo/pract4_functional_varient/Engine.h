#ifndef ENGINE_H
#define ENGINE_H

#include<iostream>
#include "EngineType.h"

class Engine
{
private:
    EngineType _type;
    int _horsepower;
    float _fuel_capacity;
public:
    Engine() = delete;
    Engine(const Engine&) = delete;
    Engine& operator=(Engine&) = delete;
    Engine(Engine&&) = delete;
    Engine& operator=(Engine&&) = delete;
    ~Engine() = default;

    EngineType type() const { return _type; }

    int horsepower() const { return _horsepower; }

    float fuelCapacity() const { return _fuel_capacity; }
    
    Engine(EngineType type,int horsepower,float fuel_capacity);

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);

};

std::string DisplayEngineType(EngineType type);

#endif // ENGINE_H
