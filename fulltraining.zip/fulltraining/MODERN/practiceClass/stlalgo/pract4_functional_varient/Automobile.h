#ifndef AUTOMOBILE_H
#define AUTOMOBILE_H

#include<iostream>
#include "AutomobileType.h"
#include "Engine.h"
#include<variant>
#include<vector>
#include<array>
#include<memory>

using PointerEngine = std::shared_ptr<Engine>;
using RType = std::reference_wrapper<PointerEngine>;


class Automobile
{
private:
    std::variant<std::string, int> _id;
    std::variant<std::vector<float>, std::array<float,4>> _tyre_pressure_reading;
    AutomobileType _type;
    RType _engine;
public:
    Automobile() = delete;
    Automobile(const Automobile&) = delete;
    Automobile& operator=(Automobile&) = delete;
    Automobile(Automobile&&) = delete;
    Automobile& operator=(Automobile&&) = delete;
    ~Automobile() = default;

    Automobile(std::variant<std::string, int> id,std::variant<std::vector<float>, std::array<float,4>> tyre_pressure_reading,AutomobileType type,RType engine);

    std::variant<std::string, int> id() const { return _id; }

    std::variant<std::vector<float>, std::array<float,4>> tyrePressureReading() const { return _tyre_pressure_reading; }

    AutomobileType type() const { return _type; }

    RType engine() const { return _engine; }

    friend std::ostream &operator<<(std::ostream &os, const Automobile &rhs);
    
};

std::string DisplayAutomobile(AutomobileType type);

#endif // AUTOMOBILE_H
