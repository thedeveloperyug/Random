#include <iostream>
#include "Automobile.h"
#include "Engine.h"
#include "AutomobileType.h"
#include "EngineType.h"
#include<memory>
#include<vector>
#include<functional>
#include "Functionalities.h"
#include<variant>
#include<numeric>
#include<algorithm>

using namespace std::placeholders;

using EngineContainer = std::vector<std::shared_ptr<Engine>>;
using PointerAutomobile = std::shared_ptr<Automobile>;
using AutomobileContainer = std::vector<PointerAutomobile>;

using funContainer = std::reference_wrapper<std::function<void(AutomobileContainer&,int)>>;

int main()
{
    AutomobileContainer Adata;
    EngineContainer Edata;

    CreateObject(Adata,Edata);

    auto f1 = [](AutomobileContainer& data,std::variant<std::string,int> id) {
        auto itr = std::find_if(
            data.begin(),
            data.end(),
            [&](const PointerAutomobile& a) {
               
               return a->id()==id;
            }
        );
    if (itr == data.end()){
        std::cout << "Not found\n";
    }
    else{
        std::cout<<"Type is: "<<DisplayAutomobile(itr->get()->type())<<std::endl;
    }
        
};

    auto partial_f1 = std::bind(f1,_1,201);

    partial_f1(Adata);

    auto f2 = [](AutomobileContainer& data,int th) {
        AutomobileContainer res(data.size());

        auto itr = std::copy_if(
            data.begin(),
            data.end(),
            res.begin(),
            [&](const PointerAutomobile& a) {
                return a->engine().get()->horsepower() > th;
            }
        );

        res.resize(std::distance(res.begin(),itr));

        for(auto i: res)
        {
            std::cout<<*i<<std::endl;
        }
    };

    auto partial_f2 = std::bind(f2,_1,150);

    partial_f2(Adata);
}