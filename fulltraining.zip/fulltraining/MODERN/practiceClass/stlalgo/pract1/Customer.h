#ifndef CUSTOMER_H
#define CUSTOMER_H

#include<iostream>
#include "CustomerType.h"
#include "Account.h"
#include<list>
#include<vector>
#include<memory>

using Pointer = std::shared_ptr<Account>;

class Customer
{
private:
    int customerId;
    std::string customerName;
    CustomerType customerType;
    std::vector<float> customerTransactionAmounts;
    float customerStoreCreadits;
    Pointer customerAccount;
public:
    Customer() =delete;
    Customer(const Customer&) = delete;
    Customer(Customer&&) = delete;
    Customer& operator=(Customer&) = delete;
    Customer& operator=(Customer&&) = delete;
    ~Customer() = default;

    Customer& operator+(Customer) ;

    Customer(int customerId,std::string customerName,CustomerType customerType,std::vector<float> customerTransactionAmounts,float customerStoreCreadits,Pointer customerAccount);

    int getCustomerId() const { return customerId; }
    void setCustomerId(int customerId_) { customerId = customerId_; }

    std::string getCustomerName() const { return customerName; }
    void setCustomerName(const std::string &customerName_) { customerName = customerName_; }

    CustomerType getCustomerType() const { return customerType; }
    void setCustomerType(const CustomerType &customerType_) { customerType = customerType_; }

    

    float getCustomerStoreCreadits() const { return customerStoreCreadits; }
    void setCustomerStoreCreadits(float customerStoreCreadits_) { customerStoreCreadits = customerStoreCreadits_; }

    Pointer getCustomerAccount() const { return customerAccount; }
    void setCustomerAccount(const Pointer &customerAccount_) { customerAccount = customerAccount_; }

    std::vector<float> getCustomerTransactionAmounts() const { return customerTransactionAmounts; }
    void setCustomerTransactionAmounts(const std::vector<float> &customerTransactionAmounts_) { customerTransactionAmounts = customerTransactionAmounts_; }

    friend std::ostream &operator<<(std::ostream &os, const Customer &rhs);

};

std::string DisplayCustomerType(CustomerType type);

#endif // CUSTOMER_H
