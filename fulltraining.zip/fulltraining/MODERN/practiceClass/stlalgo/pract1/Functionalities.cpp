#include "Functionalities.h"
#include<numeric>

void CreateObject(Container &data)
{
    data.push_back(std::make_shared<Customer>(101,"Rahul",CustomerType::PREMIUM,std::vector<float> {10.0f,20.0f,30.0f,40.0f,50.0f},100.0f,std::make_shared<Account>("ac101",5000.0f)));
    data.push_back(std::make_shared<Customer>(102,"Rohan",CustomerType::VIP,std::vector<float> {12.0f,23.0f,34.0f,45.0f,56.0f},500.0f,std::make_shared<Account>("ac102",15000.0f)));
    data.push_back(std::make_shared<Customer>(103,"David",CustomerType::REGULAR,std::vector<float> {5.0f,10.0f,40.0f,25.0f,55.0f},1000.0f,std::make_shared<Account>("ac103",10000.0f)));
    data.push_back(std::make_shared<Customer>(104,"Sohail",CustomerType::VIP,std::vector<float> {5.0f,10.0f,40.0f,25.0f,55.0f},1500.0f,std::make_shared<Account>("ac103",10000.0f)));
    data.push_back(std::make_shared<Customer>(105,"Ravi",CustomerType::VIP,std::vector<float> {5.0f,10.0f,40.0f,25.0f,55.0f},1000.0f,std::make_shared<Account>("ac103",10000.0f)));

    
}

int CustomerIdHighestTransection(Container &data)
{
    if(data.empty())
    {
        throw std::runtime_error("data is empty");
    }

    auto itr = std::max_element(
        data.begin(),
        data.end(),
        [](const PointerCustomer& c1,const PointerCustomer& c2)
        {
            auto itr1=c1->getCustomerTransactionAmounts().begin();
            auto itr2=c1->getCustomerTransactionAmounts().end();
            float tr1 = std::accumulate(                           //Problem of Sequence Point..
                itr1,                               
                itr2,0.0f,
                [&](float sum,auto trans){  
                    return sum + trans;
                });

            itr1=c2->getCustomerTransactionAmounts().begin();
            itr2=c2->getCustomerTransactionAmounts().end();
            float tr2 = std::accumulate(
                itr1,
                itr2,0.0f,
                [&](float sum, float trans){
                    return sum+trans;
                });
    
            return tr1 < tr2;
        }
       
    );
    return itr->get()->getCustomerId();
}

std::optional<Container> CustomerOfType(Container &data,CustomerType type)
{
    if(data.empty())
    {
        throw std::runtime_error("data is empty");
    }
    Container result(data.size());

    auto itr = std::copy_if(
        data.begin(),
        data.end(),
        result.begin(),
        [&](PointerCustomer& val){
            return val->getCustomerType() == type;
            
        }
    );

    result.resize(std::distance(result.begin(),itr));

    if(result.empty())
    {
        return std::nullopt;
    }

    return result;

}

std::optional<Container> CustomerOfCraditAndBalance(Container &data)
{
    if(data.empty())
    {
        throw std::runtime_error("data is empty");
    }
    Container result(data.size());

    auto itr = std::copy_if(
        data.begin(),
        data.end(),
        result.begin(),
        [&](PointerCustomer& val) {
            return ((val->getCustomerStoreCreadits() > 100.0f && val->getCustomerStoreCreadits() < 200.0f) && val->getCustomerAccount().get()->balance() > 5000.0f);
            
        }
    );

    result.resize(std::distance(result.begin(),itr));

    if(result.empty())
    {
        return std::nullopt;
    }

    return result;
}

void CombinedOfHighAndLowCredit(Container &data)
{
    if(data.empty())
    {
        throw std::runtime_error("data is empty");
    }
    auto high = std::max_element(
        data.begin(),
        data.end(),
        [](PointerCustomer& c1, PointerCustomer c2) {
            return c1->getCustomerStoreCreadits() < c2->getCustomerStoreCreadits();
        }
    );

    auto low = std::min_element(
        data.begin(),
        data.end(),
        [](PointerCustomer& c1, PointerCustomer& c2) {
            return c1->getCustomerStoreCreadits() < c2->getCustomerStoreCreadits();
        }
    );

    std::cout<<"\n\nMAx is: "<<**high<<std::endl;
    std::cout<<"\nMin is: "<<**low<<std::endl;

    auto combined = high->get()->getCustomerStoreCreadits() + low->get()->getCustomerStoreCreadits();

    std::cout<<"\nCombined Credit store is: "<<combined<<std::endl;
   
}


float AverageOfCreditStore(Container &data, CustomerType type)
{
    if(data.empty())
    {
        throw std::runtime_error("data is empty");
    }
    int count=0;
    auto sum = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [&](float total=0.0f, PointerCustomer& c) {
            if(c->getCustomerType() == type) {
                count++;
                return total + c->getCustomerStoreCreadits();
                
            }
            else
                return total;
        }
    );

    std::cout<<"\nSum is: "<<sum<<std::endl;
    std::cout<<"Count is: "<<count<<std::endl;
    std::cout<<"Average is: ";

    return sum/count;
}


bool AllCustomersOfSameType(Container &data, CustomerType type)
{
    if(data.empty())
    {
        throw std::runtime_error("data empty");
    }

    auto flag = std::all_of(
        data.begin(),
        data.end(),
        [&](PointerCustomer& val) {
            return val->getCustomerType() == type;
        }
    );

    return flag;
}


int CountCustomerTypeBal(Container &data)
{
    auto count = std::count_if(
        data.begin(),
        data.end(),
        [](const PointerCustomer& p) {
            return p->getCustomerType()==CustomerType::REGULAR && p->getCustomerAccount().get()->balance() > 1000;
        }
    );

    return count;
}
