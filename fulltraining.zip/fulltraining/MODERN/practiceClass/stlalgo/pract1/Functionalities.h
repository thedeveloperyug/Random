#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include "Account.h"
#include "CustomerType.h"
#include "Customer.h"
#include<vector>
#include<memory>
#include<list>
#include<numeric>
#include<algorithm>
#include<optional>


using PointerCustomer = std::shared_ptr<Customer>;
using Container = std::vector<PointerCustomer>;

/*
    Function to create the object
*/
void CreateObject(Container& data);  


/*
    Function for find the highest and return id of Customer Transection amount which is in the list
*/
int CustomerIdHighestTransection(Container& data);


/*
    Function to return a Container of Customer whose Type Matches with argument
*/
std::optional<Container> CustomerOfType(Container& data,CustomerType type);


/*
    Function to return a Container of Customer whose Customer Cradit Score between 100 and 200 Account balance is over 5000
*/
std::optional<Container> CustomerOfCraditAndBalance(Container& data);


/*
    void Function to find the Customer Instance and print the combined customer_store_credit whose credit store is highest and lowest
*/
void CombinedOfHighAndLowCredit(Container& data);


/*
    Function to find the average of Customer_credit_store whose type matches with the argument
*/
float AverageOfCreditStore(Container& data,CustomerType type);


/*
    Function to return the container of all customer if type matches with argument pass 
*/
bool AllCustomersOfSameType(Container& data ,CustomerType type );


/*
    Function to find the count of customer instances whose type matched with the REGULAR and customer account balance over 1000
*/
int CountCustomerTypeBal(Container& data);


#endif // FUNCTIONALITIES_H
