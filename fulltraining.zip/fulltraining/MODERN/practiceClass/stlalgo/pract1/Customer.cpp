#include "Customer.h"

Customer::Customer(int customerId, std::string customerName, CustomerType customerType, std::vector<float> customerTransactionAmounts, float customerStoreCreadits,Pointer customerAccount)
: customerId(customerId),customerName(customerName),customerType(customerType),customerTransactionAmounts(customerTransactionAmounts),customerStoreCreadits(customerStoreCreadits),customerAccount(customerAccount)
{
}

std::ostream &operator<<(std::ostream &os, const Customer &rhs) {
    os << "customerId: " << rhs.customerId
       << " customerName: " << rhs.customerName
       << " customerType: " <<DisplayCustomerType(rhs.customerType)
       << " customerTransactionAmounts: "; 
       for(auto& i : rhs.customerTransactionAmounts)
       {
          os << i<<" ";
       }
       os << " customerStoreCreadits: " << rhs.customerStoreCreadits
       << " customerAccount: " << *(rhs.customerAccount.get());
    return os;
}

std::string DisplayCustomerType(CustomerType type)
{
    if(type == CustomerType::PREMIUM)
    {
        return "PRIMIUM";
    }
    else if(type == CustomerType::REGULAR)
    {
        return "REGULAR";
    }
    else
    {
        return "VIP";
    }
    
}
