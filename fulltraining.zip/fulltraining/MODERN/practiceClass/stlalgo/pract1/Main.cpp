#include<iostream>
#include "Account.h"
#include "CustomerType.h"
#include "Customer.h"
#include<vector>
#include<memory>
#include<list>
#include "Functionalities.h"
#include<numeric>
#include<optional>

using PointerCustomer = std::shared_ptr<Customer>;
using Container = std::vector<PointerCustomer>;

int main()
{
    Container data;
    CreateObject(data);

    try
    {
        std::cout<<"\nId Whose Transection Maximum: "<<CustomerIdHighestTransection(data)<<std::endl;

    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    
    try
    {
        std::optional<Container> result = CustomerOfType(data,CustomerType::PREMIUM);

        std::cout<<"\nCustomer of Type:- "<<std::endl;

        if(result.has_value())
        {
            for(auto& i: result.value())
            {
                std::cout<<*i<<std::endl;
            }
        }
        else
        {
            std::cout<<"\nData is Empty!"<<std::endl;
        }
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    try
    {
       std::optional<Container> result2 = CustomerOfCraditAndBalance(data);

        if(result2.has_value())
        {
            for(auto& i: result2.value())
            {
                std::cout<<*i<<std::endl;
            }
        }
        else
        {
            std::cout<<"Data is Empty"<<std::endl;
        }
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        CombinedOfHighAndLowCredit(data);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    try
    {
        std::cout<<"\nAverage of Credit_Store: "<<AverageOfCreditStore(data,CustomerType::VIP)<<std::endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        std::cout<<"\nAll have same Type: "<<AllCustomersOfSameType(data,CustomerType::REGULAR)<<std::endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        std::cout<<"\nNo. of Customers have Type is REGULAR and balance over 1000: "<<CountCustomerTypeBal(data)<<std::endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }    

    
}