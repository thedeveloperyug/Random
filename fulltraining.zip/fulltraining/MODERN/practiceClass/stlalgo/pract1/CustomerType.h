#ifndef CUSTOMERTYPE_H
#define CUSTOMERTYPE_H

enum class CustomerType
{
    REGULAR,
    PREMIUM,
    VIP
};

#endif // CUSTOMERTYPE_H
