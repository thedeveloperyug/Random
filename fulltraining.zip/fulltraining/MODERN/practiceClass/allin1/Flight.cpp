#include "Flight.h"

Flight::Flight(std::string id, FlightType type, std::string startingLocation, std::string destinationLocation, float fare)
 : _id(id), _type(type), _startingLocation(startingLocation), _destinationLocation(destinationLocation), _fare(fare)
{
}

std::ostream &operator<<(std::ostream &os, const Flight &rhs) {
    os << "_id: " << rhs._id
       << " _type: " << DisplayEnum(rhs._type)
       << " _startingLocation: " << rhs._startingLocation
       << " _destinationLocation: " << rhs._destinationLocation
       << " _fare: " << rhs._fare;
    return os;
}

std::string DisplayEnum(FlightType value)
{
    if(value == FlightType::COMMERCIAL)
         return "COMMERCIAL";
    else if(value == FlightType::PRIVATE)
         return "PRIVATE";
    else
         return "SPECIAL";
}
