#include "functionlities.h"
#include "FlightType.h"

void CreateObjects(Container &data)
{
    data.push_back(
        std::make_shared<Flight>("FL101",FlightType::COMMERCIAL,"Mumbai","Delhi",2400.0f)

    );

    data.push_back(
        std::make_shared<Flight>("FL102",FlightType::COMMERCIAL,"Mumbai","Delhi",2400.0f)

    );

    data.push_back(
        std::make_shared<Flight>("FL103",FlightType::PRIVATE,"Mumbai","kolkata",2500.0f)

    );

    data.push_back(
        std::make_shared<Flight>("FL104",FlightType::COMMERCIAL,"channai","patna",3000.0f)

    );

    data.push_back(
        std::make_shared<Flight>("FL105",FlightType::SPECIAL,"Bhopal","jalandhar",2000.0f)

    );

}

float AverageFare(Container &data)
{
    if(data.empty()) {
        throw std::runtime_error("NO DATA FOUND\n");
    }

    float total = 0.0f;
    for(std::shared_ptr<Flight>& flight  :data)
    {
        total += flight->fare();
    }

    return total / data.size();
}

std::string FindIdMinFare(Container &data)
{
     if(data.empty()) {
        throw std::runtime_error("NO DATA FOUND\n");
    }

    std::string id= data.front()->id();
    float minFare = data.front()->fare();
    
    for (std::shared_ptr<Flight>& flight : data)
    {
        float fare = flight->fare();
        if(fare < minFare) {
            minFare = fare;
            id = flight->id();
        }

    }
    
    return id;

}

Container FindNInstance(Container &data, int N)
{
     if(data.empty()) {
        throw std::runtime_error("NO DATA FOUND\n");
    }

    if(N < 0 || N > data.size()) {
        throw std::runtime_error("N is Invalid!");
    }
    
    Container result;
    int count = N;

    while (count > 0)
    {
        result.push_back(data[N-count]);
        count--;
    }

    return result;
    
}
