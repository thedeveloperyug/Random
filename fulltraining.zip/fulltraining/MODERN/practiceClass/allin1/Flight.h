#ifndef FLIGHT_H
#define FLIGHT_H

#include<iostream>
#include "FlightType.h"

class Flight
{
private:
    std::string _id;
    FlightType _type;
    std::string _startingLocation;
    std::string _destinationLocation;
    float _fare;

public:
    Flight() = delete;

    Flight(const Flight&) = delete;

    Flight& operator=(Flight&) = default;

    Flight( Flight&&) = delete;

    Flight& operator=(Flight&&) = delete;

    ~Flight() = default;

    Flight(std::string id,FlightType type,std::string startingLocation,std::string destinationLocation,float fare);

    std::string id() const { return _id; }

    FlightType type() const { return _type; }

    std::string startingLocation() const { return _startingLocation; }

    std::string destinationLocation() const { return _destinationLocation; }

    float fare() const { return _fare; }

    friend std::ostream &operator<<(std::ostream &os, const Flight &rhs);

};

std::string DisplayEnum(FlightType value);

#endif // FLIGHT_H
