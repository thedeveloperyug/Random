#ifndef FLIGHTTYPE_H
#define FLIGHTTYPE_H

enum class FlightType
{
    COMMERCIAL,
    SPECIAL,
    PRIVATE
};

#endif // FLIGHTTYPE_H
