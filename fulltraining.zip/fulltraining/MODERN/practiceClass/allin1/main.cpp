#include "Flight.h"
#include<iostream>
#include"FlightType.h"
#include<memory>
#include<vector>
#include "functionlities.h"

using Container = std::vector<std::shared_ptr<Flight>>;

int main()
{
    Container data;
    CreateObjects(data);   //Calling function for creating the Object.

    std::cout<<"Average Fare: "<<AverageFare(data)<<std::endl;  //Returning the Averaeg Fare

    std::cout<<"Id For minimum Fare: "<<FindIdMinFare(data)<<std::endl;  // Returning the Id whose Minimum Fare.

    
    Container r = FindNInstance(data,3);  

    for(std::shared_ptr<Flight> f : r)
    {
        std::cout<< *f << std::endl;
    }

    return 0;



}