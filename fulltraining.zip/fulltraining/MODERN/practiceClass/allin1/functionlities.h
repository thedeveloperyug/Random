#ifndef FUNCTIONLITIES_H
#define FUNCTIONLITIES_H

#include "Flight.h"
#include<vector>
#include<memory>

using Container = std::vector<std::shared_ptr<Flight>>;


//Creating the object..

void CreateObjects(Container &data);

//Function for finding the average

float AverageFare(Container &data);

//finding the min fare

std::string FindIdMinFare(Container &data);

//finding the N instances

Container FindNInstance(Container &data, int N);

#endif // FUNCTIONLITIES_H
