#include<iostream>
#include<algorithm>
#include<vector>
#include<numeric>


    /*
        NOTE:  1.accmulate -> aggregation where binary operation happend
               2.find_if -> if the instance matches
               3.count_if -> count if matches
               4.copy_N -> N instances without condition
               5.copy_if -> Copy all instances matching condtion 
               6.any_of -> return bool (check only condition)
               7.all_of -> " "
               8.none_of -> " "
    */
int main()
{
    std::vector<int> data {1,2,3,4,5};

    std::vector<int> results(data.size());   //Data size and results size have to same

    auto itr = std::copy_if(                // Value in itr the copy_if has copy the position of last element
        data.begin(),data.end(),results.begin(),
        [](int num){return num % 2 ==0; }
    );

    results.resize( std::distance(results.begin(),itr) );

//do any of my input elements satisfy the condition in the lambda  ---->Return bool only
    std::cout<<std::any_of(
        data.begin(),
        data.end(),
        [](int  number){ return number % 10 == 0; }
    )<<std::endl;

//wheather all of elements are satisfy the condition in the lamda or not  ---->Return bool only
    std::cout<<std::all_of(
        data.begin(),
        data.end(),
        [](int  number){ return number % 10 == 0; }
    )<<std::endl;

//wheather none of elements are satisfy the condition in the lamda or not  ---->Return bool only
    std::cout<<std::none_of(
        data.begin(),
        data.end(),
        [](int  number){ return number % 10 == 0; }
    )<<std::endl;

    // auto itr = std::max_element(data.begin(),data.end());
    // std::cout<<**itr;



for Vector:-    std::sort(data.begin(),data.end(),[](PointerClass& val1,PointerClass& val2) {   //on Primitive data types no require of Lambda function
        val1->salary() < val2->salary();
    });


for List:-    
?--//sort upto N in list  
//std::next and std::advance
}


/********************************************************************************/
Thershold......

using Container = std::vector<int>;
using opt = std::optional<Container>;

opt Magic(std::vector<int>& data, int threshold ) {    /* Copy Abve Thershold */
    
    if(data.empty()) {
        throw std::runtime_error("Data is empty. Plaease apna dekh lo!");
    }    // case : user ki galti!


    Container result(data.size());  //has no size, no beginn no end


    auto itr = std::copy_if(data.begin(),   //input starting
                 data.end(),     //input end
                 result.begin(), //output start
                 [&](int val) {return val > threshold;}
        );        //predicate lamda : return true or false

        result.resize(std::distance(result.begin(), itr));

        if(result.empty()) {
            return std::nullopt;
        }  //Code chala but nothing is above thershlod!

        return result;   // Case : code badhiya chala.

}
int main()
{
     opt ans = Magic(data,3);  //code badhiya chalega!

    if (ans.has_value()) {
        for(int v : ans.value()) {
            std::cout<<v << "\n ";
        }
        std::cout<<std::endl;
    }

    else {
        std::cout<< "Okay I understand nothing is above thershold";
    }
}



/****************************************************************************/


float product = std::accumulate(data.begin(), data.end(), 1.0f,
    [](float ans,float value) { return ans * value;});


float combied_salary = std::accumulate(
        regData.begin(),
        regData.end(),
        0.0f,
        [](float ans, Pointer& emp) {return ans + emp->salary();}
    );

std::cout<< "Average of regData salary " <<combied_salary / regData.size();


auto position_itr = std::max_element(
        smartData.begin(),
        smartData.end(),
        [](Pointer& e1,Pointer& e2) {return e1->salary() < e2->salary();}
    );

    std::cout<<"smart Max salary "<<**position_itr<<"\n";



    /**************************************************************************/
    /**************************************************************************/
//Find the maximum position..

    auto itr = std::max_element(
        data.begin(),
        data.end(),
        [](const PointerCustomer& c1,const PointerCustomer& c2)
        {
            auto itr1=c1->getCustomerTransactionAmounts().begin();
            auto itr2=c1->getCustomerTransactionAmounts().end();
            float tr1 = std::accumulate(                           //Problem of Sequence Point..
                itr1,                               
                itr2,0.0f,
                [&](float sum,auto trans){  
                    return sum + trans;
                });

            itr1=c2->getCustomerTransactionAmounts().begin();
            itr2=c2->getCustomerTransactionAmounts().end();
            float tr2 = std::accumulate(
                itr1,
                itr2,0.0f,
                [&](float sum, float trans){
                    return sum+trans;
                });
    
            return tr1 < tr2;

            /***************************************************************************/

//copy the elements by condition..

    Container result(data.size());

    auto itr = std::copy_if(
        data.begin(),
        data.end(),
        result.begin(),
        [&](PointerCustomer& val){
            return val->getCustomerType() == type;
            
        }
    );

    result.resize(std::distance(result.begin(),itr));

    /*****************************************************************************************/

//Average ...

    int count=0;
    auto sum = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [&](float total=0.0f, PointerCustomer& c) {
            if(c->getCustomerType() == type) {
                count++;
                return total + c->getCustomerStoreCreadits();
                
            }
            else
                return total;
        }
    );

    return sum/count;

    /********************************************************************************************/

//give bool
    auto flag = std::all_of(
        data.begin(),
        data.end(),
        [&](PointerCustomer& val) {
            return val->getCustomerType() == type;
        }
    );

    /********************************************************************************************/


//for count 
    auto count = std::count_if(
        data.begin(),
        data.end(),
        [](const PointerCustomer& p) {
            return p->getCustomerType()==CustomerType::REGULAR && p->getCustomerAccount().get()->balance() > 1000;
        }
    );

    return count;

    /*******************************************************************************************/

//Copy the upto N
    Container result(data.size());

    auto itr = std::copy_n(data.begin(),N,result.begin());
  
    result.resize(std::distance(result.begin(),itr));

    return result;

    /********************************************************************************************/

//Find the position 
    auto itr = std::find_if(
        billdata.begin(),
        billdata.end(),
        [&](const PointerBill& b) {
            return b->getBillAssociateInvoice().get()->getInvoiceNumber() == inumber;
        }
    );
    return itr->get()->getBillAmount();

    /**************************************************************************/
//visit in algo
    float total = std::accumulate(data.begin(),data.end(),0.0f,
    [](float ans, VType obj ) {

        std::visit([&](auto&& val){
            ans += val->getPrice();        //VISIT for variant
        },obj);

        return ans;

      }
    );

    /****************************************************************************/
//For visit max element position
    auto itr = std::max_element(data.begin(),data.end(),

    [](VType& obj1,VType& obj2) {

        float a=0.0f,b=0.0f;

        std::visit([&](auto&& val1,auto&& val2) {
            a=val1->getPrice(); b=val2->getPrice();
        },obj1,obj2);                                  //std::visit([&](auto&& val) {a=val->getPrice()});
                                                            //std::visit([&](auto&& val) {b=val->getPrice()});
          //Comparator body

          return a<b;        //check and return the maximum object in the container
      }

    );
    std::string ans;

    std::visit( [&] (auto&& val) {
        ans = val->getBrand();
    },*itr);

    return ans;

  /**************************************************************************/

    std::list<Type> result(data.size());
    auto count = result.begin();
    for(auto i:data)
    {
        std::visit([&](auto&& val){
            if(val->getPrice() < threshold)
            {
                result.push_back(val->getVehicleType());
                count++;
            }
        },i);     
    }
    result.resize(std::distance(result.begin(),count));