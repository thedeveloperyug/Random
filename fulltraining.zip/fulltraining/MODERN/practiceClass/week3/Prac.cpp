#include<iostream>
#include<optional>

int main()
{
    std::optional<int> op = std::nullopt;
    std::optional<int> op2 = op;

    std::cout<<op2.value();
    return 0;
}