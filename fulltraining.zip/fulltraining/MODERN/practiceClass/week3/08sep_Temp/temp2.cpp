#include<iostream>

/*
   Display
        It should accept a Container
        of primitive data types or pointer
        to primitive data types and print all the items
*/

#include<vector>

template<typename T>
void Display(std::vector<T> data) {
    for(T value: data) {
        std::cout<<value;
    }
    std::cout<<std::endl;
}

template<typename T>
void Display(std::vector<T*> data) {
    for(T* value: data) {
        std::cout<<*value;
    }
    std::cout<<std::endl;
}

int main()
{
    
}
