#include<iostream>

template<typename T>
T addition(T n1, T n2) {
    return (n1 + n2); // return statement is used to give the value of a variable.
}

int main()
{
    addition<int>(10,10);
    addition<std::string>("Shiavm","Kumar");
}