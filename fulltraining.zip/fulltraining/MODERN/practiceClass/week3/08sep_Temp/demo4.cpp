#include<iostream>

//variadic templates: templates that take variable number of arguments
//... is called parameter pack

template<typename T>
T addition (T arg) {
    return arg;
}

template<typename X,typename... T>
X addition(X val, T...args) {
    return val + addition(args...)
}


int main()
{
    std::cout<<addition<int>(10);
    std::cout<<addition<int>(10,20,30,40);
   // std::cout<<addition<std::string>();

}



