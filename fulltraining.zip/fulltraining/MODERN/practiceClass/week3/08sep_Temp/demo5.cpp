#include<iostream>

//variadic templates: templates that take variable number of arguments
//... is called parameter pack

// template<typename... T>
// auto addition(T...args) {
//     return (val + args...)
// }

template<typename... T>
auto substaction(T...args) {
    return (args - ...);   //... decided direction of association
                           //since code is args + ..., operation would be right associative
}

int main()
{
    // ((40-30)-20)-10)
    std::cout<<substaction<int>(10,20,30,40,50)<<"\n";
}



