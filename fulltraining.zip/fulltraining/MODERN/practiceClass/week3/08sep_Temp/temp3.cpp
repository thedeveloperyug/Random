#include<iostream>

#include<vector>

#include<list>

#include<array>

#include<stack>


template<typename T>
//Display takes data of type T, loops over data and prints its element

void Display(T data)
{
    for(auto val : data) {
        std::cout<<val<<" ";
    }
    std::cout<<"\n";
}

template<>
void Display (std::stack<int> data) {
    std::stack<int> copy_data(data);
    int size = copy_data.size();

    for(int i=0;i<size;i++) {
        std::cout<<copy_data.top()<<"\n";

        copy_data.pop();
    }
    std::cout<<std::endl;
}

int main()
{
    std::vector<int> v1 {1,2,3,4,5};
    std::list<int> l1 {1,2,3,4,5};
    // std::stack<int> s1 {1,2,3,4,5};  --> cannot work against principal of stack

    std::stack<int> s1 ;
    for(int i=0;i<5;i++) {
        s1.push(i+1);
    }

    std::array<int,5> a1 {1,2,3,4,5};

    Display<std::stack<int>>(s1);
    Display<std::vector<int>>(v1);
    Display<std::list<int>>(l1);
    Display<std::array<int,5>>(a1);
}