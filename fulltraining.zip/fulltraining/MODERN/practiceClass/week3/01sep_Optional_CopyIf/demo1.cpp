#include<iostream>
#include<vector>
#include<optional>
#include<algorithm>

using Container = std::vector<int>;
using opt = std::optional<Container>;

opt Magic(std::vector<int>& data, int threshold ) {
    
    if(data.empty()) {
        throw std::runtime_error("Data is empty. Plaease apna dekh lo!");
    }    // case : user ki galti!


    Container result(data.size());  //has no size, no beginn no end


    auto itr = std::copy_if(data.begin(),   //input starting
                 data.end(),     //input end
                 result.begin(), //output start
                 [&](int val) {return val > threshold;}
        );        //predicate lamda : return true or false

        result.resize(std::distance(result.begin(), itr));

        if(result.empty()) {
            return std::nullopt;
        }  //Code chala but nothing is above thershlod!

        return result;   // Case : code badhiya chala.

}


int main()
{
    // std::vector<int> ans = Magic();
    // if(ans.empty()) {
    //     std::cout<<"NO data found!\n";
    // }

    Container data {1,2,3,4,5};

    opt ans = Magic(data,3);  //code badhiya chalega!

    if (ans.has_value()) {
        for(int v : ans.value()) {
            std::cout<<v << "\n ";
        }
        std::cout<<std::endl;
    }

    else {
        std::cout<< "Okay I understand nothing is above thershold";
    }
}


//Case1 : When function works correctly but not a single value for returning the use -

//   using opt = std::optional<Container>;
      
     
     


