/*
    - login

    -Customer details

    -progress of software update

    example- when software is on uptdate situation while we have to check the customer details
    or any other work when updating the software. Then, there we need asynchoronous programing.
*/

#include<iostream>
#include<future>
#include<thread>

int factorial(std::future<int>& data) {

    auto f1 = [](int number) {
        std::this_thread::sleep_for(std::chrono::seconds(5));
        std::cout<<"Square of given number "<<number<<" is: "<<number*number<<std::endl;
    };

    f1(10);

    int value = data.get();   // get when N is nessecary without N we cannot go foreward.

    if(value < 0) {
        throw std::runtime_error("Cannot factorial for a negative number");

    }

    else if(value == 0 || value == 1) {
        return 1;
    }

    else {
        int result =1;
        for(int i=2;i<=value;i++){
            result *= i;
        }
        return result;
    }
}


int main()
{
    int N;
    std::promise<int> pr;  //step 1: make a promise 

    std::future<int> data = pr.get_future();  //step 2: set up a channel between promise and future
    

    std::future<int> result = std::async(std::launch::async,factorial, std::ref(data));  //throw  the future accross the channel attached to operation.

    std::cout<<"Send the number for factorial\n";
    std::cin>>N;

    pr.set_value(N);  //After: wait tamasha dekho fir.

    std::cout<<"If Answer is ready, it should be "<<result.get()<<std::endl;


    // <1> auto f1 = [](int number) {std::this_thread::sleep_for(std::chrono::seconds(5));
    // std::cout<<"Square of given number"<<number<<" is: "<<number * number <<"\n";};

    // f1(10);

}

