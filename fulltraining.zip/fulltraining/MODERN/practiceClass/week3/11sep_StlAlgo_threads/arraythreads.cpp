#include<iostream>

#include<array>
#include<thread>


int main()
{
    std::array<int,5> data {1,2,3,4,5};
    std::array<int,5> results {0,0,0,0,0};
    std::thread arr[5]; //  It will give defalut thread from thread class

    auto f1 = [&](int number,int i) { results[i] = number * number;};

    for(int i=0;i<5;i++) {
        arr[i] = std::move (std::thread(f1,data[i],i));  //this line is connecting to data,lambda,threads all.
    }
    for(int i=0;i<5;i++)
    {
        arr[i].join();
    }
    for(int i=0;i<5;i++)
    {
        std::cout<<results[i]<<"\n";
    }
}

// Note: If you return any value from thread it will discard.