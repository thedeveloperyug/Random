#include<iostream>
#include<algorithm>
#include<vector>
#include<numeric>

int main()
{
    std::vector<int> data {1,2,3,4,5};

    std::vector<int> results(data.size());   //Data size and results size have to same

    auto itr = std::copy_if(                // Value in itr the copy_if has copy the position of last element
        data.begin(),data.end(),results.begin(),
        [](int num){return num % 2 ==0; }
    );

    results.resize( std::distance(results.begin(),itr) );

//do any of my input elements satisfy the condition in the lambda
    std::cout<<std::any_of(
        data.begin(),
        data.end(),
        [](int  number){ return number % 10 == 0; }
    )<<std::endl;

//wheather all of elements are satisfy the condition in the lamda or not
    std::cout<<std::all_of(
        data.begin(),
        data.end(),
        [](int  number){ return number % 10 == 0; }
    )<<std::endl;

//wheather none of elements are satisfy the condition in the lamda or not
    std::cout<<std::none_of(
        data.begin(),
        data.end(),
        [](int  number){ return number % 10 == 0; }
    )<<std::endl;

    // auto itr = std::max_element(data.begin(),data.end());

    // std::cout<<**itr;
}