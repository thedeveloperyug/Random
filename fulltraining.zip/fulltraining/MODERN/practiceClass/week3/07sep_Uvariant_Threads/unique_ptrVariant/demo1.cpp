#include<iostream>
#include<vector>
#include<memory>
#include<variant>


class Book
{
private:
    std::variant<int,std::string> book_id;
    std::string book_name;
    float book_price;
public:
    Book()=delete;
    Book(const Book&)=delete;
    Book(Book&&)=delete;
    Book& operator=(const Book&)=delete;
    Book& operator=(Book&&)=delete;
    ~Book()=default;

    Book(std::variant<int,std::string> book_id,std::string book_name,float book_price);

    std::variant<int,std::string> bookId() const { return book_id; }
    void setBookId(const std::variant<int,std::string> &bookId) { book_id = bookId; }

    std::string bookName() const { return book_name; }
    void setBookName(const std::string &bookName) { book_name = bookName; }

    float bookPrice() const { return book_price; }
    void setBookPrice(float bookPrice) { book_price = bookPrice; }

    friend std::ostream &operator<<(std::ostream &os, const Book &rhs);

        
};


Book::Book(std::variant<int, std::string> book_id, std::string book_name, float book_price)
:book_id(book_id),book_name(book_name),book_price(book_price) {}

inline std::ostream &operator<<(std::ostream &os, const Book &rhs) {
    os << "book_id: " ;
    std::visit([&](auto&&a){os<<a;},rhs.book_id);
    os << " book_name: " << rhs.book_name
       << " book_price: " << rhs.book_price;
    return os;
}
using BookPointer=std::unique_ptr<Book>;
using RefBook=std::reference_wrapper<BookPointer>;

class Library
{
private:
    std::string library_name;
    std::string library_id;
    // RefBook book; // which means a libray have only one book
    std::vector<RefBook> books;//which means a libray can have many books(0 or many books)
    
public:
    Library()=delete;
    Library(const Library&)=delete;
    Library(Library&&)=delete;
    Library& operator=(const Library&)=delete;
    Library& operator=(Library&&)=delete;
    ~Library()=default;

    Library(std::string library_name,std::string library_id,std::vector<RefBook> books);

    friend std::ostream &operator<<(std::ostream &os, const Library &rhs);
};

inline std::ostream &operator<<(std::ostream &os, const Library &rhs) {
    os << "library_name: " << rhs.library_name
       << " library_id: " << rhs.library_id
       << " books: " ;
       for(auto &i:rhs.books){
            os<<*(i.get())<<std::endl;
       }
    return os;
}

void CreatLibray(std::vector<std::unique_ptr<Library>> &l,std::vector<BookPointer>& book){
    
    book.push_back(std::make_unique<Book>());
    book.emplace_back(std::make_unique<Book>());
    
    // l.push_back(std::make_unique<Library>("Aksay","a101",()))
}



int main(){
    std::vector<BookPointer> books;
    std::vector<std::unique_ptr<Library>> L; //which means array of library (now there is no librarys in L)
    CreatLibray(L,books);
    //now l is unique pointer now (now Library also craeted in heap)
}
























/*
    Scenario 1:
     threre is a library which contains no books.
        a)if we have M books but we didnt kept books in libraray
        b)if we dont have any books
    Scenario 2:
        there is a libray which contains M books and we have N books present(N>=M)
    



*/























