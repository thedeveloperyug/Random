#ifndef INSURANCETYPE_H
#define INSURANCETYPE_H

enum class InsuranceType
{
    ZERO_DEBT,
    REGULAR
};

#endif // INSURANCETYPE_H
