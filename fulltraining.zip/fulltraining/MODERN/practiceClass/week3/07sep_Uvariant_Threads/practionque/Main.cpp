#include<list>
#include "Car.h"
#include<memory>
#include<functional>
#include "Vehicle.h"
#include "InsuranceType.h"
#include "Insurance.h"
#include<iostream>
#include<thread>
#include "Functionalities.h"


using CarPointer = std::unique_ptr<Car>;
using CarContainer = std::list<CarPointer>;

using InsurancePointer = std::unique_ptr<Insurance>;
using InsuranceContainer = std::list<InsurancePointer>;

using Constainer = std::list<Car*>;

int main()
{
    CarContainer carData;
    InsuranceContainer insData;
    // std::thread t1(CreateObjects,std::ref(insData),std::ref(carData));
    // t1.join();  //main block

    std::thread arr[2];

    arr[0] = std::thread (
        CreateObjects,
        std::ref(insData),
        std::ref(carData),
        "I201",
        5000.0f,
        InsuranceType::REGULAR,
        "v101",
        11900,
        VehicleType::PRIVATE, 
        CarType::SEDAN,
        980000.0f,
        "Red"
        );

    arr[0].join();

    // std::thread t2(CarsAboveInsuranceThresHold,std::ref(carData),1000.0f);
    // t2.join();

}