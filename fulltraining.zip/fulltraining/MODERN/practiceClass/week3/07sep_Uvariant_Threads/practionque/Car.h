#ifndef CAR_H
#define CAR_H

#include<iostream>
#include "CarType.h"
#include "Vehicle.h"


class Car : public Vehicle
{
private:
    CarType _carType;
    float _carPrice;
    std::string _carColour;
public:
    Car() = delete;

    Car(const Car&) = delete;

    Car& operator=(const Car&) = delete;

    Car(Car&&) = delete;

    Car& operator=(Car&&) = delete;

    ~Car() = default;    

    Car(std::variant<int, std::string> vehicleId,int vehicleRegistration,VehicleType vehicleType,InsRef vehicleInsurancePlan,CarType carType,float carPrice,std::string carColour);

    CarType carType() const { return _carType; }

    float carPrice() const { return _carPrice; }

    std::string carColour() const { return _carColour; }

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
    
};

std::string DisplayCarType(CarType type);

#endif // CAR_H
