#include "Functionalities.h"

std::mutex mt;

// void CreateObjects(InsuranceContainer &insData, CarContainer &carData)
// {                              //perfect forwarding
//     std::unique_ptr<Insurance> i1 = std::make_unique<Insurance>(
//         "Ins101",
//         100000.0f,
//         InsuranceType::ZERO_DEBT
//     );

//     std::unique_ptr<Insurance> i2 = std::make_unique<Insurance>(
//         "Ins101",
//         100000.0f,
//         InsuranceType::ZERO_DEBT
//     );

//     insData.push_back( std::move(i1));    //Push_back  pushing the data intpo Container by taking lvalue  reference and Rvalue reference f0r rvalue reference we need to use move function.
//     //Note: it's loooks like move forwarding but in forwarding we have to foreward to next but here not foreward anywhere.

//     insData.emplace_back(
//         std::make_unique<Insurance>(
//         "Ins101",
//         100000.0f,
//         InsuranceType::ZERO_DEBT
//        )
//     );


//     insData.push_back(std::make_unique<Insurance>("a101",34000,InsuranceType::ZERO_DEBT));
// }


void CreateObjects(InsuranceContainer &insData, CarContainer &carData,std::string insuranceId,float insuranceAmount,InsuranceType insuranceType, std::variant<int, std::string> vehicleId, int vehicleRegistration, VehicleType vehicleType, CarType carType, float carPrice, std::string carColour)
{
    std::unique_ptr<Insurance> i1 = std::make_unique<Insurance>(
        insuranceId,
        insuranceAmount,
        insuranceType
    );

    mt.lock();

    insData.push_back(std::move(i1));


    std::unique_ptr<Car> unique_c1(
        std::make_unique<Car>(   
        vehicleId,
        vehicleRegistration,
        vehicleType,
        std::ref(insData.back()),
        carType,
        carPrice,
        carColour
        )
    );

//

    carData.push_back(std::move(unique_c1));

    mt.unlock();

    
}
