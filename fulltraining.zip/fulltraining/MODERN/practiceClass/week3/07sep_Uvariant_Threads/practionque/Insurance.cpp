#include "Insurance.h"


std::ostream &operator<<(std::ostream &os, const Insurance &rhs) {
    os << "_insuranceId: " << rhs._insuranceId
       << " _insuranceAmount: " << rhs._insuranceAmount
       << " _insuranceType: " <<DisplayInsuranceType(rhs._insuranceType);
    return os;
}

std::string DisplayInsuranceType(InsuranceType type)
{
    if(type == InsuranceType::REGULAR)
       return "REGULAR";
    else
       return "ZERO_DEBT";
}

Insurance::Insurance(std::string insuranceId, float insuranceAmount, InsuranceType insuranceType)
: _insuranceId(insuranceId), _insuranceAmount(insuranceAmount),_insuranceType(insuranceType)
{
}
