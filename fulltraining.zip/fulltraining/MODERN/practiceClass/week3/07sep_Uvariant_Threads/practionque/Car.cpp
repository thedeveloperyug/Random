#include "Car.h"


std::ostream &operator<<(std::ostream &os, const Car &rhs) {
    os << "_carType: " <<DisplayCarType(rhs._carType)
       << " _carPrice: " << rhs._carPrice
       << " _carColour: " << rhs._carColour;
    return os;
}

std::string DisplayCarType(CarType type)
{
   if(type == CarType::HATCHBACK)
      return "HATCHBACK";
   else if(type == CarType::SEDAN)
      return "SEDAN";
   else 
      return "SUV";
}

Car::Car(std::variant<int, std::string> vehicleId, int vehicleRegistration, VehicleType vehicleType, InsRef vehicleInsurancePlan, CarType carType, float carPrice, std::string carColour)
:Vehicle(vehicleId,vehicleRegistration,vehicleType,vehicleInsurancePlan),_carType(carType),_carPrice(carPrice),_carColour(carColour)
{
}


