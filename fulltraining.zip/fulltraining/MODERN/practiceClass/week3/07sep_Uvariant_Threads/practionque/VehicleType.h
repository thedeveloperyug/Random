#ifndef VEHICLETYPE_H
#define VEHICLETYPE_H

enum class VehicleType
{
    PRIVATE,
    COMMERCIAL,
    SPECIAL_PURPOSE
};

#endif // VEHICLETYPE_H
