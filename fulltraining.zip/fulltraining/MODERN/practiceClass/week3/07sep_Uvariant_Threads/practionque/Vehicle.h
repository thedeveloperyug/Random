#ifndef VEHICLE_H
#define VEHICLE_H

#include<iostream>
#include "Insurance.h"
#include<variant>
#include "VehicleType.h"
#include<memory>

using InsPointer = std::unique_ptr<Insurance>;
using InsRef = std::reference_wrapper<InsPointer>;    //shared_ptr ?

class Vehicle
{
private:
    std::variant<int, std::string> _vehicleId;   
    int _vehicleRegistration;
    VehicleType _vehicleType;
    InsRef _vehicleInsurancePlan;    //Reference wrapper of class Vehicle
public:
    Vehicle() = delete;

    Vehicle(const Vehicle&) = delete;

    Vehicle& operator=(const Vehicle&) = delete;

    Vehicle(Vehicle&&) = delete;

    Vehicle& operator=(Vehicle&&) = delete;

    ~Vehicle() = default;

    Vehicle(std::variant<int, std::string> vehicleId,int vehicleRegistration,VehicleType vehicleType,InsRef vehicleInsurancePlan);

    std::variant<int, std::string> vehicleId() const { return _vehicleId; }

    int vehicleRegistration() const { return _vehicleRegistration; }

    VehicleType vehicleType() const { return _vehicleType; }

    InsRef vehicleInsurancePlan() const { return _vehicleInsurancePlan; }

    friend std::ostream &operator<<(std::ostream &os, const Vehicle &rhs);

};

std::string DisplayVehicleType(VehicleType type);  //  Display for Vehicle type

#endif // VEHICLE_H
