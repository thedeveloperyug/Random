#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
#include<list>
#include "Car.h"
#include<memory>
#include<functional>
#include "Vehicle.h"
#include "InsuranceType.h"
#include "Insurance.h"
#include<mutex>



using CarPointer = std::unique_ptr<Car>;
using CarContainer = std::list<CarPointer>;

using InsurancePointer = std::unique_ptr<Insurance>;
using InsuranceContainer = std::list<InsurancePointer>;

using RawConstainer = std::list<Car*>;

/* 
   A function to Create Insurance Object and Car onjects
*/

// void createObjects(InsuranceContainer& insData,CarContainer& carData);

void CreateObjects(InsuranceContainer& insData,CarContainer& carData,
std::string insuranceId,float insuranceAmount,InsuranceType insuranceType,
std::variant<int, std::string> vehicleId, int vehicleRegistration,
 VehicleType vehicleType, CarType carType,float carPrice,std::string carColour
 );

/*
    A function to create
*/


// std::optional<RawConstainer>CarsAboveInsuranceThresHold(CarContainer& carData,float thershold)
// {
//     RawConstainer result;
//     if(carData.empty())
//     {
//         throw std::runtime_error("NO data");
//     }
//     for(CarPointer & c: carData)
//     {
//         if(c->vehicleInsurancePlan().get()->insuranceAmount() > thershold)
//         {
//             result.push_back(c.get());
//         }
//     }   
//     if(result.empty())
//     {
//         return std::nullopt;
//     }
//     return result;
// }

#endif // FUNCTIONALITIES_H
