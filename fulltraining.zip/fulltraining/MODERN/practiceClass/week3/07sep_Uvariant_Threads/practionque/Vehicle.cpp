#include "Vehicle.h"



std::ostream &operator<<(std::ostream &os, const Vehicle &rhs) {
    os << "_vechicleId: ";
    std::visit([&](auto&& val){os << val;}, rhs._vehicleId);    //visit is a void function
    os   << " _vehicleRegistration: " << rhs._vehicleRegistration
       << " _vehicleType: " <<DisplayVehicleType(rhs._vehicleType)
       << " _vehicleInsurancePlan: " << *(rhs._vehicleInsurancePlan.get());
    return os;
}

std::string DisplayVehicleType(VehicleType type)
{
    if(type == VehicleType::COMMERCIAL)
       return "COMMERCIAL";
    else if(type == VehicleType::PRIVATE)
       return "PRIVATE";
    else
       return "SPECIAL_PURPOSE";

}

Vehicle::Vehicle(std::variant<int, std::string> vehicleId, int vehicleRegistration, VehicleType vehicleType, InsRef vehicleInsurancePlan)
: _vehicleId(vehicleId),_vehicleRegistration(vehicleRegistration),_vehicleType(vehicleType),_vehicleInsurancePlan(vehicleInsurancePlan)
{
}
