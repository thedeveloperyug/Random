#ifndef INSURANCE_H
#define INSURANCE_H

#include<iostream>
#include "InsuranceType.h"

class Insurance
{
private:
    std::string _insuranceId;
    float _insuranceAmount;
    InsuranceType _insuranceType;
public:
    Insurance() = delete;

    Insurance(const Insurance&) = delete;

    Insurance& operator=(const Insurance&) = delete;

    Insurance(Insurance&&) = delete;

    Insurance& operator=(Insurance&&) = delete;

    ~Insurance() = default;

    Insurance(std::string insuranceId,float insuranceAmount,InsuranceType insuranceType);

    std::string insuranceId() const { return _insuranceId; }

    float insuranceAmount() const { return _insuranceAmount; }

    InsuranceType insuranceType() const { return _insuranceType; }

    friend std::ostream &operator<<(std::ostream &os, const Insurance &rhs);

    
};

std::string DisplayInsuranceType(InsuranceType type);   //Function for Display Enum

#endif // INSURANCE_H
