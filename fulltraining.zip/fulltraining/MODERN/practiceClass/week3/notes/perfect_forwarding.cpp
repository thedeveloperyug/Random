#include<iostream>

/*
    foreward references [for perfect forwarding ]
*/

template<typename T>
void func(T&& t)
{
    std::forward(t);   //in perfect forewarding Lvalue & Rvalue will go inside as it is, it won't be change.
}

/*
   Data* ptr = new Data(100,200);

   templete<typename A, templete B, typename

   auto s1 = std::make_shared<Employee> (
    101,
    "Shivam",
    std::vector<int> {10, 20, 30, 40},
    ptr
   );

*/
#include<memory>
#include<functional>

