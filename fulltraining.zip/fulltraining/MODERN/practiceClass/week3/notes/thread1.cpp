#include<iostream>
#include<thread>


void square(int number)
{
    std::this_thread::sleep_for(std::chrono::seconds(5));
    std::cout<<number * number<<"\n";
}

void cube(int number)
{
    std::this_thread::sleep_for(std::chrono::seconds(5));
    std::cout<< number * number * number<<std::endl;
}

int main()
{
    std::thread t1(&square, 10);
    std::thread t2(&cube, 15);

    /*
       
    */

    t1.join();
    t2.join();
}


// g++ -lptthread Demo1.cpp -0 app
// time ./a.out