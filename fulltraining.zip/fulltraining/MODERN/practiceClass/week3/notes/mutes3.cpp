#include<iostream>
#include<thread>
#include<mutex>


std::mutex mt;


int amount = 1000;

void withdraw()
{
    for(int i=0;i<100;i++){
        std::this_thread::sleep_for(std::chrono::microseconds(10));
        std::lock_guard<std::mutex> lk(mt);     //This type of lock work scope by scope
        amount = amount - 10;
        
    }
}

void deposite()
{
    for(int i=0;i<100;i++){
        std::this_thread::sleep_for(std::chrono::microseconds(10));
        std::lock_guard<std::mutex> lk(mt);
        amount = amount + 10;
        
    }
}

int main()
{
    std::thread t1(&deposite);   //We are mapping a function to thread object //means declaration only not calling
    std::thread t2(&withdraw);

    t1.join();
    t2.join();

    std::cout<<"Final amount: "<<amount<<std::endl;
}

