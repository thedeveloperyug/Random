#include <iostream>

class Employee
{
private:
    const int data;

public:
    Employee(int val)
        : data(val) {}
    ~Employee() {}

    int getData() const { return data ; }
};

// if Object may be const then any of the data member in the object cannot be change.

int main()
{
    Employee  e1(10);
    std::cout<<"calling: "<<e1.getData();


}