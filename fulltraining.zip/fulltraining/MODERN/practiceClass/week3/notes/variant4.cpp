#include<iostream>
#include<variant>
#include<memory>

/*
   In this Concept learn do not inheritance for runtime polymerphism use visitor coding pattern 
   in which we take a single object for many class.
*/
struct Employee
{
    //CalculateTax
    void CalculateTax() {
        std::cout<<"Employee pays 15% tax\n";
    }
};

struct BusinessOwner
{
    //Calculate
    void CalculateTax() {
        std::cout<<"Business Owner 25% tax\n";
    }
};

using EmpPointer = std::unique_ptr<Employee>;
using BussPointer = std::unique_ptr<BusinessOwner>;

int main()
{
    //Visitor Paturn coding putting two or more class in a single Object

/*   std::variant<Employee,BusinessOwner> v1;
    
    v1 = BusinessOwner();

    //access varient and call calculateTax;
    std::visit([](auto&& val) { val.CalculateTax();}, v1);

    v1=Employee();

    //access varient and call calculateTax;
    std::visit([](auto&& val) { val.CalculateTax();}, v1);

*/

   std::variant<EmpPointer,BussPointer> v1;

   v1 = std::make_unique<Employee>();
   std::visit( [](auto&& val){ val->CalculateTax();}, v1);

   v1 = std::make_unique<BusinessOwner>();
  std::visit( [](auto&& val){ val->CalculateTax();}, v1);

}

/*
     Varient <  Employee |  BusinessOwner  >
                 v1           UNUSED


     std::Varient <Employee, BusinessOwner>  v1 = Employee();
*/
