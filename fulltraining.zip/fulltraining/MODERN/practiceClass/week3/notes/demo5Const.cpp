/*
     use of const Keyboard

     Rule:

     A) cosnt keyboard applied to whatevee\r os on its
     imidiate left. If there If there si nothing to the left of
     const, apply const to the TOKEN on the immidiate right.

     B) * is also a token

*/

#include<iostream>

int main()
{
    int n1 = 10;
    int n2 = 99;

//ptr is a pointer to a CONSTANT INTEGER
    const int *ptr = &n1;  // means pointer is not const it own so, we change the pointing adderess where it was pointing but 
                           //we cannot change the integer value by pointer


//////////////////////////////////////////
    int const *ptr2 = &n1;  //Same

    //case 3:
    int * const ptr3 = &n1;   //ptr 3 is a constant pointer can not point another variable
                              // but change the data using pointer.

    //case 4: conbined

//ptr4  is a CONSTANT pointer to a CONSTANT integer
    const int* const ptr4 = &n1;   //ptr4 cannot change anything either integer value or pointing to another variable.
    
}