#include<iostream>
#include<array>
#include<unordered_map>


using Container = std::array<int, 3>;

Container magic() {
    // return Container {11,77,99};
    return {11,77,99};
}


int main()
{
    Container ans = magic();
    for(auto val : ans) {
        std::cout<< val<<" ";
    }

    int a = ans[0];
    int b = ans[1];
    int c = ans[2];

    ///////-- Structure binding--////

    auto [x,y,z] = magic();

    // auto& [x,y,z] = magic();    --> by reference

    std::cout<<"\nX value is : "<<x<<"\n";

    std::unordered_map<int, std::string> m1 {
        {1,"Shivam"},
        {2,"Rohan"},
        {3,"Ajay"}
    };

    std::cout<< m1[2];

    for(auto itr=m1.begin(); itr!=m1.end(); ++itr) {
        std::cout<<"Label is: "<<itr->first<<std::endl;
        std::cout<<"Data is: "<<itr->second<<std::endl;
    }

    for(auto [label,data] : m1) {
        std::cout<<"Label is: "<<label<<std::endl;
        std::cout<<"Data is: "<<data<<std::endl;
    }

}