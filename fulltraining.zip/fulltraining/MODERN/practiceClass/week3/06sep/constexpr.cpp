#include<iostream>

constexpr int magic(int n,int m)
{
    return n+m; 
}

int main()
{
    int ans = magic(3,5);

    std::cout<<ans<<std::endl;

    return 0;
}