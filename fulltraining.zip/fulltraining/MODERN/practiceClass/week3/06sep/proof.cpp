#include<iostream>

class Employee
{
private:
    int _eid;
public:
    Employee() = delete;

    Employee(const Employee& obj) {
        std::cout<<"Copy happens here"<<std::endl;
    }

    Employee(int eid) :_eid(eid) {}

    ~Employee() {
        std::cout<<"Object Destroyed"<<std::endl;
    }
};

Employee magic(int id) {
    std::cout<<"Inside Magic NOw\n";
    Employee e1(id);
    return e1;   //Usually This is where copy takes place
}

int main()
{
    Employee ans = magic(100);
}

