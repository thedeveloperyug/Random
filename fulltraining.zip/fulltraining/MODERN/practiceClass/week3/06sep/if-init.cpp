#include<iostream>
#include<vector>
#include <algorithm>
#include<numeric>


int main()
{
    std::vector<int> data {1,2,3,4,5} ; //end;

    // auto itr = std::find(
    //     data.begin(),
    //     data.end(),
    //     4                 //Note: When compiler gives end()  value means data not found value should be atleat before end.
    // );

    if(auto itr = std::find(data.begin(),data.end(),3);  itr == data.end()) {        //we can inistialize inside in loop condition only so that we need not to be take care for veriable useless i.e "itr" because it's scope is to main.
                                                                                     //note: initialize first than check the condition.
        std::cout<< "if found";
    }

    else {
        std::cout<<"Else Condition";
        std::cout<< std::accumulate(data.begin(), data.end(),0);
    }
}