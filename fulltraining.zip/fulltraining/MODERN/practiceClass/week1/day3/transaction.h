#ifndef TRANSACTION_H
#define TRANSACTION_H

#include<iostream>
#include "transactiontype.h"

class Transaction
{
private:
    std::string transationId;
    float transationAmount;
    TransationType transationType;

public:
    Transaction() = delete;
    Transaction(const Transaction&)=delete;
    Transaction& operator=(Transaction&)=delete;
    Transaction(Transaction&&) = delete;
    Transaction& operator=(Transaction&&) = delete;
    ~Transaction() = default;
    Transaction(std::string id,float amount,TransationType type);

    std::string getTransationId() const { return transationId; }

    float getTransationAmount() const { return transationAmount; }

    TransationType getTransationType() const { return transationType; }

    friend std::ostream &operator<<(std::ostream &os, const Transaction &rhs);

};

//Global Function..

std::string DisplayEnum(TransationType type);




#endif // TRANSACTION_H
