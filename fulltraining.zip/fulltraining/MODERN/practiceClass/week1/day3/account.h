#ifndef ACCOUNT_H
#define ACCOUNT_H

#include <vector>
#include <iostream> 
#include "transaction.h"
#include<list>
#include<memory>

using Transactions = std::vector<Transaction*>;   // using Transactions= std::vector<Transaction*>;

class Account
{
private:
    std::string accountId;
    Transactions accountTransations;
    float accountBalance;

public:
    Account() = delete;
    Account(const Account&) = delete;
    Account& operator=(Account&) = delete;
    Account(const Account&&) = delete;
    Account& operator=(Account&&) = delete;
    ~Account() = default;

    Account(std::string id, Transactions transationsSet, float balance);

    std::string getAccountId() const { return accountId; }

    Transactions getAccountTransations() const { return accountTransations; }

    float getAccountBalance() const { return accountBalance; }

    friend std::ostream &operator<<(std::ostream &os, const Account &rhs);
};




#endif // ACCOUNT_H
