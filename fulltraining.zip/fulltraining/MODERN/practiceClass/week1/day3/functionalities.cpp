#include "functionalities.h"
#include "account.h"
#include "transaction.h"
#include "transactiontype.h"
#include<memory>
#include<iostream>

/*
    Account
*/

void CreateAccounts(Container &data)
{
    Account *ac1 = new Account(
        "ac101",
        {
            new Transaction("tr104", 100.0f, TransationType::CASH),
            new Transaction("tr205", 100.0f, TransationType::UPI),
            new Transaction("tr106", 789.0f, TransationType::CARD)
        },
        10000.0f);

    Account *ac2 = new Account(
        "ac102",
        Transactions{
            new Transaction("tr307", 1000.0f, TransationType::UPI),
            new Transaction("tr308", 100.0f, TransationType::UPI),
            new Transaction("tr309", 200.0f, TransationType::CARD)
        },
        40000.0f);
         data.push_back(ac1);
         data.push_back(ac2);

    // std::unique_ptr<Account> ac1 = std::make_unique<Account>(
    //     "ac101",
    //     {
    //         std::make_unique<Transaction>("tr104", 100.0f, TransationType::CASH),
    //         std::make_unique<Transaction>("tr205", 100.0f, TransationType::UPI),
    //         std::make_unique<Transaction>("tr106", 789.0f, TransationType::CARD)
    //     },
    //     10000.0f);

    // std::unique_ptr<Account> ac2 = std::make_unique<Account>(
    //     "ac102",
    //     Transactions{
    //         std::make_unique<Transaction>("tr307", 1000.0f, TransationType::UPI),
    //         std::make_unique<Transaction>("tr308", 100.0f, TransationType::UPI),
    //         std::make_unique<Transaction>("tr309", 200.0f, TransationType::CARD)
    //     },
    //     40000.0f);

    //     data.push_back(std::make_unique<Account>(ac1));
    //     data.push_back(ac2);

    
}

void DeleteAccounts(Container &data)
{
    for (Account *ac : data)
    {
        for (Transaction *tr : ac->getAccountTransations())
        {
            delete tr;
        }

        delete ac;
    }

    // for(std::unique_ptr<Account>& ac : data){
    //     for(std::unique_ptr<Transaction>& tr : ac->getAccountTransations()){
    //         // we need not to write delete smart pointer will take care of it.
    //     }
    // }
}

Container AccountsAboveThreshold(Container &data, float threshold)
{
    if(data.empty()) {
        throw std::runtime_error("Data empty");
    }

    float total = 0.0f;
    Container result;

    for(Account* ac : data) {
        total = 0.0f;

        for(Transaction* tr : ac->getAccountTransations()){
            total += tr->getTransationAmount();
        }
        if(total > threshold)
        {
            result.push_back(ac);
        }
    }
    return result;

    
}

float TotalTransactionsAmounts(Container &data)
{
    if(data.empty()) {
        throw std::runtime_error("Data empty");
    }
    // using Transactions= std::vector<Transaction*>;
    float total = 0.0f;

    for (Account *ac : data)
    {
        for (Transaction *tr : ac->getAccountTransations())
        {
            total = total + tr->getTransationAmount();
        }
    }

    return total;
}

std::string FindMaxAccountBalanceId(Container &data)
{
     if(data.empty()) {
        throw std::runtime_error("Data empty");
    }
    float hBalance = 0.0f;
    std::string id = " ";

    for (Account *ac : data)
    {
        if (ac->getAccountBalance() > 0 && ac->getAccountBalance() > hBalance)
        {
            hBalance = ac->getAccountBalance();
            id = ac->getAccountId();
        }
    }

    return id;
}


std::string NthTransationId(Container &data, int N,std::string accountId)
{
     if(data.empty()) {
        throw std::runtime_error("Data empty");
    }
    if(N <= 0 || N > 3)
    {
        throw std::runtime_error("Invalid N");
    }

    for(Account* ac : data )
    {
        if(ac->getAccountId() == accountId){
            return ac->getAccountTransations()[N]->getTransationId();
        }
    }

    throw std::runtime_error("Account with matching ID not found ");

}

float AverageTransationAmount(Container &data, std::string accountId)
{
     if(data.empty()) {
        throw std::runtime_error("Data empty");
    }
    float total = 0.0f;
    int count =0;

    for(Account* ac : data) {
        if(ac->getAccountId() == accountId) {
            for(Transaction* trans: ac -> getAccountTransations()){
                count++;
                total += trans->getTransationAmount();
        
            }
        }
    }

    return total / count;
}

float BalanceInterestAmount(Container &data)   // Problem
{
    float total = 0.0f;

    if(data.empty()) {
        throw std::runtime_error("Data empty");
    }
    
    for(Account* ac : data ){

        if(ac->getAccountBalance() > 10000.0f)
        {
            total += ac->getAccountBalance() * 0.04;
        }

    }

    return total;
}

bool IsAcountValid(Account *ac)
{
    bool flag = true;
    /*
       flag will be updated based on transation amount being over 500.
       if any transaction is less than 500, than our account is invalid.
    */

    for(Transaction* tr : ac->getAccountTransations()) {
        flag = tr->getTransationAmount() > 500;
        if(!flag){
            return false;
        }
    }

    /*
        check for account 
    */
    return ac->getAccountBalance() > 100000.0f
       &&
    ac->getAccountTransations().size() >=3
       &&
    flag;
}
