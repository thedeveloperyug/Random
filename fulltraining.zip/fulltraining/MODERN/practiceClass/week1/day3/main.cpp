#include<iostream>
#include "account.h"
#include "transaction.h"
#include "functionalities.h"
#include<list>
#include<memory>

using Container = std::list<Account*>;

int main()
{
    Container data;
    CreateAccounts(data);

    Container r= AccountsAboveThreshold(data,1.0f);

    for(Account* a:r){
        std::cout<<*a<<std::endl;
    }


    return 0;
}