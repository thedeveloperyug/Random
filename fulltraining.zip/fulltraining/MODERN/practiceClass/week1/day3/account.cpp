#include "account.h"

Account::Account(std::string id, Transactions transationsSet, float balance)
  : accountId(id), accountTransations(transationsSet),accountBalance(balance)
{
}


std::ostream &operator<<(std::ostream &os, const Account &rhs) {
    os << "accountId: " << rhs.accountId
       << " accountTransations: ";
       for (Transaction* tr : rhs.getAccountTransations()){
           os <<*tr << "\n";
       } 
       os << " accountBalance: " << rhs.accountBalance;

    return os;
}


