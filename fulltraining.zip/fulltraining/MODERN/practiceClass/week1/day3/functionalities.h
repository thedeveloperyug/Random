#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "account.h"
#include<list>
#include<vector>
#include "transactiontype.h"
#include<memory>

using Container = std::list<Account*>;    //In Smart pointer we didn't write *..
using TransationContainer = std::vector<Transaction*>;    //using TransationContainer = std::vector<Transaction*>;

/*
   function to create account objects
*/
void CreateAccounts(Container& data);


/*
  function to delete accoutn objetcs
*/
void DeleteAccounts(Container& data);


/*
   function to find count of accounts whose transation type(for at least one transation)
   matches with input type
*/
int CountOfTransationsOfGivenType(TransationContainer& data, TransationType type);

/*
  function to find accounts above threshold
*/
Container AccountsAboveThreshold(Container& data,float threshold);

/*
   function to find total transation amounts (total for all objects)
*/
float TotalTransactionsAmounts( Container &data );

/*
   function to find accountId of the account with maximum accountBalance
   {
       assuming all accounts have different balance amounts,
       balance cannot be negative,
       type of transation part has been ignored!
   }
//    all accounts have diiferent balance amounts)
*/
std::string FindMaxAccountBalanceId(Container& data);

/*
   function to find ID of nth transation of an amount
   (0< n <= 3)
*/
std::string NthTransationId(Container& id,int N);

/*
  function to find average transation amount for all transation of ONE GIVEN ACCOUNT
*/
float AverageTransationAmount(Container& data, std::string accountId);

/*
  function to find cummulative account intrest (using all instance of account) as per given condition
*/
float BalanceInterestAmount(Container& data);

/*
  function to check if account is valid as per Goverment
*/

bool IsAcountValid(Account* ac);



#endif // FUNCTIONALITIES_H
