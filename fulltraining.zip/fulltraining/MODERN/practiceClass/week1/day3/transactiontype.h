#ifndef TRANSACTIONTYPE_H
#define TRANSACTIONTYPE_H

enum class TransationType
{
    CARD,
    CASH,
    UPI
    
};

#endif // TRANSACTIONTYPE_H
