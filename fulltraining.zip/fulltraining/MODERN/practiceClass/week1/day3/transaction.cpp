#include "transaction.h"

Transaction::Transaction(std::string id, float amount, TransationType type)
  : transationId(id),transationAmount(amount), transationType(type)
{
}

std::ostream &operator<<(std::ostream &os, const Transaction &rhs) {
    os << "transationId: " << rhs.transationId
       << " transationAmount: " << rhs.transationAmount
       << " transationType: " << DisplayEnum(rhs.transationType);
    return os;
}

std::string DisplayEnum(TransationType type)
{
    if(type == TransationType::CARD)
        return "CARD";
    
    else if(type == TransationType::CASH)
        return "CASH";

    else
        return "UPI";
    
}
