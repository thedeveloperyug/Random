#include "functionalities.h"
#include "car.h"
#include "cartype.h"
#include<list>
#include<numeric>
#include<algorithm>

//->Moral of Story**** If you are using Emplace back you will get object back not the pointer back;


void createObjetcs(Container &data)
{
   data.emplace_back("c101","dezire",CarType::SEDAN,950000.0f,42);
   //emplace_back reqires arguments which pass in constructor
   data.emplace_back("c102","WagonR",CarType::SEDAN,550000.0f,52);
   data.emplace_back("c103","Celerio",CarType::SEDAN,450000.0f,38);
   data.emplace_back("c104","Ertiga",CarType::SEDAN,1050000.0f,28);
   data.emplace_back("c105","Baleno",CarType::SEDAN,850000.0f,40);

//    data.push_back("c101","dezire",CarType::SEDAN,950000.0f,42); can be use in pointers case
}

/*
    Function calculates total price of all cars and returns the average by 
    dividing total by size of input list
*/

float AveragePrice(Container &data)
{
    // float total = 0.0f;

    // for(Car c : data)
    // {
    //     total=total + c.price();
    // }

    // return total / data.size();

    float total = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [](float total,Car& c1) { return total + c1.price();}
    );

    return total / data.size();
}


/*
    create 2 varialble, one for tracking price, second to store model strings
    if price of current vehicle is grater then the highest price, delete

    When in the for loop, following cases can be seeen

    1) price of current vehicle is less than previous hPrice
        ----> no operation required
    2) price of current vehicle is more than previous hPrice
       -----> delete previous entry/entries in the list, replace hPrice and add
              new model to modelNames
    3) price of current vehicle is same as previous hPrice (new vehicle is also
       of same price)
       -----> add new model to modelNames list
*/


void ModelNameHighestPrice(Container &data)
{
    float hPrice = data.front().price();
    std::list<std::string> modelName;

    for(Car& c : data)
    {
        if(c.price() > hPrice)
        //case 2
        {
            hPrice = c.price();
            modelName.clear();
            // modelName.erase(modelName.begin(),modelName.end());
            modelName.push_back(c.model());
        }

        if(c.price() == hPrice)
        //case 3
        {
            modelName.push_back(c.model());
        }
        std::cout<<std::endl<<"Heighest Price: "<<std::endl;
        for(std::string name : modelName)
        {
            std::cout << name <<"\n";
        }
    }
}

Container CarsAboveThershold(Container &data, float thershold)
{
    Container result;
    for(Car& c : data)
    {
        if(c.price() > thershold)
        {
            result.push_back(c);
        }
    }
    return result;

}
