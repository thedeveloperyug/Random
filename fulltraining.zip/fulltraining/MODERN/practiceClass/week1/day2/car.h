#ifndef CAR_H
#define CAR_H

#include<iostream>
#include "cartype.h"

class Car
{
private:
    std::string _id;
    std::string _model;
    CarType _type;
    float _price;
    int _fuelCapacity;

public:
    //diasbled default constructor
    Car() = delete;

    //enalbled shallow copy constructor
    Car(const Car&) = default;

    //a function which returns a Car& called "operator=" which accepts one const
    //Car lvalue reference is disabled.

    Car& operator=(const Car&) = delete;

    //Move Constructor for copy without copy.
    Car(Car&&) = delete;

    Car& operator=(Car&&) = delete;

    //Parametrized Constructor
    Car(std::string id,std::string model, CarType type,float price,int fuelCap);

    ~Car() = default;

    std::string id() const { return _id; }
    void setId(const std::string &id) { _id = id; }

    std::string model() const { return _model; }
    void setModel(const std::string &model) { _model = model; }

    CarType type() const { return _type; }
    void setType(const CarType &type) { _type = type; }

    float price() const { return _price; }
    void setPrice(float price) { _price = price; }

    int fuelCapacity() const { return _fuelCapacity; }
    void setFuelCapacity(int fuelCapacity) { _fuelCapacity = fuelCapacity; }

    friend std::ostream &operator<<(std::ostream &os, const Car &rhs);
};

std::string DisplayEnum(CarType type);

//** If you want  to make a array of stack allocated the Your default constructor require be there.

#endif // CAR_H
