#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H
#include "car.h"
#include<list>


using Container = std::list<Car>;

/*
    createObjects accepts on container by lvalue reference and return void
*/

void createObjetcs(Container& data );

/*
    function should return the average price of all units passed in input container
*/

float AveragePrice(Container& data);

/*
    function takes container as input, finds all units with highest price
    and prints their _model string
*/

void ModelNameHighestPrice(Container& data);

/*
    function to return a container of all units whose price is above a thershold

*/

Container CarsAboveThershold(Container& data, float thershold);

#endif // FUNCTIONALITIES_H
