#include "car.h"
#include "functionalities.h"
#include<list>

using Container = std::list<Car>;

int main()
{
    Container data;
    createObjetcs(data);

    //a function to find average price
    std::cout<<"Average Price is "<<AveragePrice(data) <<std::endl;
    
    //function to find car with highest price and print its _model
    ModelNameHighestPrice(data);

    //a fucntion to find and print the returned list of all cars which are above a threshold
    Container result = CarsAboveThershold(data, 500000.0f);

    std::cout<<"Printing the result of above threshold function: ";

    for(Car c : result)
    {
        std::cout << c <<" ";
    }
}