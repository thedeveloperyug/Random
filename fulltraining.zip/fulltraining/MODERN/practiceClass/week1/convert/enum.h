#ifndef ENUM_H
#define ENUM_H

#include<iostream>

enum Employeetype
{
    IT,
    HR,
    MANAGER
};

#endif // ENUM_H
