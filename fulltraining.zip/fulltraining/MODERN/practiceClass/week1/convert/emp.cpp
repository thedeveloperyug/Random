#include "emp.h"
#include<iostream>


Employee::Employee(int eId, std::string eName, Employeetype eType, float sal)
: empId(eId),empName(eName),empType(eType),salary(sal)
{
}

std::ostream &operator<<(std::ostream &os, const Employee &rhs)
{
        os << "empId: " << rhs.empId
           << " empName: " << rhs.empName
           << " empType: " << rhs.empType
           << " salary: " << rhs.salary;
        return os;
    }
Employee::~Employee()
{
    std::cout<<"Destructor with ID:"
       <<this->empId
       <<" is destroyed\n";
}


