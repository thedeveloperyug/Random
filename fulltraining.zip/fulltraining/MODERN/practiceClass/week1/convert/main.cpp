#include<iostream>
#include "emp.h"
#include<vector>
#include<array>


//equivalant

using dept=Employeetype; // new_name = old_name;

void magic(Employee obj)
{
    std::cout << obj;
}

int main()
{
    int *ptr;
    std::cout<< *ptr;  //It called Undefined Behaviour UB...Not called Garbage value.

    //There is a keyword in modern cpp that blocks a compiler for using a constructor for implict type conversion(implicit) * Opp to Exiplicity

    Employee e1(101);

    magic(e1);  //call by value..

    magic(100);    // It create error because of explicit conversion concept..




    // Employee* e1 = new Employee();
   
    // Employee emp1(101,"John",Employeetype::HR, 35.0f);
    //  std::cout << emp1 << "\n";
    // return 0;

    // auto n1=10;   //Compiler will try to guess the value by initialization.

//**** -std=c++17
}