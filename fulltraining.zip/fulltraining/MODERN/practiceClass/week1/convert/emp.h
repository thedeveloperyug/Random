#ifndef EMP_H
#define EMP_H

#include <iostream>
#include "enum.h"

class Employee
{
    int empId;
    std::string empName;
    Employeetype empType;
    float salary;

public:
    Employee() = default;//delete--for Disable the constructor   //it will take default value --  Defalut Constructor.
    
    Employee& operator= (const Employee& );  //e1 = e2;  e2 is const Employee&
    
    Employee(const Employee& ) = default;  //Default Copy Constructor.
    
    Employee(int, std::string, Employeetype,float);

    //parameterized constructor that takes one int.

    explicit Employee(int id) : empId(id) {}
    
    ~Employee();

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);

};

#endif // EMP_H
