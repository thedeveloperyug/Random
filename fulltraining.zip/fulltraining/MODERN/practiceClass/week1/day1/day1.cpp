#include <iostream>
#include <list>
#include <vector>

struct Demo
{
    int value;
};

class Employee
{
private:
    int _eid {-1};  //inclass data member means initiazilation in class only.

public:
    Employee(int id) : _eid(id) {}
    Employee(const Employee &) = delete;
    Employee() = default;
    ~Employee() {}
};

int main()
{
    int a[5] {1, 2, 3, 4, 5};
    int n1 {10};

    struct Demo d1
    {
        10
    };

    int *ptr{nullptr};

    Employee e1{};

    // Employee* e2 = new Employee();

    std::list<int> data{1, 2, 3};

    std::vector<int> arr{1,2,3,4,5};

    for(int val : arr)      
    {
        std::cout<<val<<std::endl;    // for every integer called val inside my list arr print that 'val' .
    }
}


/* 
  

*/