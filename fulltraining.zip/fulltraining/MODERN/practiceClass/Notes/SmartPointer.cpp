#include<iostream>
#include "Employee.h"

#include<memory>


int main()
{
    Employee* e2 = new Employee(101);
    std::unique_ptr<Employee> e1 = std::make_unique<Employee>(101);

    //reset : swap with some other pointer

    e1.reset(e2);    // copy to e2 and release e1 resource.
}

// std::unique_ptr<Employee>  -----> a Template class
// e1 : Object of Template class !!

// std::make_unique<Employee>  ------> maker function or relay function (send value to Constructor)

/*
   RAII : Resource Accquisition is initialization..

-----> Moment at the initialize the object we have to accqire the memmory at that time only.
-- This is Principal of Compiler team
*/