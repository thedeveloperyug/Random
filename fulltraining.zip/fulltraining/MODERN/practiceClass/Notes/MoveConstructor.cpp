#include<iostream>

#include "Employee.h"

#include<memory>


int main()
{
    std::unique_ptr<Employee>e1 = std::make_unique<Employee>(101);

    std::unique_ptr<Employee>e2 (std::move(e1));

    //Invalid because e1 is moved alreadt! std::cout << e1.get();

    e1 = std::make_unique<Employee>(1345,"Shivam");  //new resource attached to e1.

}