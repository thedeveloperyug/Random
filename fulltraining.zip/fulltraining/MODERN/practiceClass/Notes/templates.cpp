#include<iostream>

/*

   I want to perform an operation that can work for potentially infinite type

*/

template <typename T>

void display(T something) {
    std::cout << something <<std::endl;
}

template<typename T>
void addition(T n1,T n2) {
    std::cout<< n1+ n2;
}

template<typename A,typename B>
void sum(A n1, B n2) {
    std::cout << n1 + n2 <<"\n";
}

int  main()
{
    int n1 = 10;
    display<int>(n1);

    float f1 = 10.21f;

    display<float>(f1);

///////////First T T Have Problem that we need to pass same data types/////

    addition<int>(10,20);
    addition<int>(10.0f,20.88f);

////////// We can pass different parameters/////

    sum<int,float> (10, 23.45f);
    sum<int,int> (100,200);
}