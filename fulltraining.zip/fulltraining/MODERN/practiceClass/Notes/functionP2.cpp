#include<iostream>
#include<functional>
#include<list>

void operation(std::list<int> data, std::function<int(int)>fun) {

    
    for(int &a:data){
        std::cout<<"\nIn Operation out: ";
        std::cout<<fun(a)<<std::endl;
    }
}

// int square(int number) {
//         std::cout << number * number;  
// }

int main()
{
    int n1=10;

    // int square(int number) {
    //     std::cout << number * number;    In C++ we cannot make a function in another function
    // }

//Note: Capture clause in lamda is used to access veriable or local can be acces 

    operation(
        std::list <int> {1,2,3,4,5},

        [&n1](int number) /*mutable*/ {                  // note: mutable use for only read the data.
            // std::cout<<  number * number<<std::endl;
            return number*number;
        }

        );

}