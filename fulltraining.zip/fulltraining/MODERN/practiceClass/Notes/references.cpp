


/*

    lvalue reference (int& n1)
    rvalue reference (int&& n2)

    
    e.g:   int n1= 10
           int& n2 = n1;

    SYMBOL TABLE
    NAME    address   Content   ALTERNATE NAMES
    n1       0x100H    10        n2

*/

#include <iostream> 

int main()
{
    //array of references cannot be Created

    int n1 = 10;
    int& n2 = n1;

    int * ptr = &n1;
    int*& refptr = ptr;




    // int& arr [2] {n2};   // Not Allowed because by taking reference how we create memmory.\

    //references to reference don't work as ecpected !!! (NOT A GOOD STATEMENT)
    int& n3 = n2;
    
    n1 = 100;
    n2 = 2000;
    n3 = 5000;

    std::cout<<n2;

}