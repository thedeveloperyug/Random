#include<iostream>

struct Employee
{
    int _id;

    Employee(int id) : _id(id) {}
};

void magic(const Employee& obj)
{
    std::cout<< obj._id << "\n";
}

int main()
{
    Employee e1 {10};   //creating a struct variable e1 with 10 as _id
    magic(e1);  //magic with lvalue e1, e1 binds to obj inside magic by reference
    magic( Employee {101} );   //temporary (rvalue)
}

/*
   lvalues can bind to lvalue reference
   rvalues can bind to rvalue reference OR const lvalue reference
*/