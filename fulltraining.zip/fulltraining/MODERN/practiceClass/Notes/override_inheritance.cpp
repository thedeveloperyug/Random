#include <iostream>

class Parent
{
private:
    /* data */
public:
    Parent(/* args */) {}
    ~Parent() {}

    virtual void Display () = 0;
};


class Child final : public Parent
{
private:

public:

    Child() {}
    ~Child() {}

    void Display() override {
        std::cout << "Child Display function called!" << '\n';
    }
};

class NewChild : public Child   // Final class which we can not override from that class.
{
private:
    /* data */
public:
    NewChild (/* args */) {}
    ~NewChild () {}
};

