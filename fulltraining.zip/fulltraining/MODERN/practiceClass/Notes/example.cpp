/*
   
     What do you do with DATA/VARIABLE ?

     int n = 10;

     1> variable have a type --->type is declared!

     magic(10)
     magic(std::function< int (int)> fun )

     2> variable are passed as argument to functions

     std::function< int (int)> magic(int number);

     3> variable are returned as return value from functions

       std::function< int (int)> magic(int number);

     4> variables can also be stored in other data containers

       std::function<int (int) > f1 ;
       std::function<int(int) > f2 = f1;

     5> variables can also be stored in other data containers

     //stud list of stud function wrapper to function that take int & return int 

     std::list < std::function<int(int) >   > data {f1, f2}; 
*/