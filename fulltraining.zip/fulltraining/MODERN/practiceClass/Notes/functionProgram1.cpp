#include<iostream>

#include <functional>   // header for function programing



// first - class function

/*
   Assume there is one person
   person is given container and given an operation
   person tries to apply operatio on data

   e.g : data is [1,2,3,4,5] operation : square
   e.g data is [1,2,3,4,5] operation is : factorial
 
*/

using func = std::function< int (int)>;  //means its return type is int and parameter we passes will be int only

int square(int number) {
    return number * number ;
}

int cube (int number) {
    return number * number * number;
}

void operation( int* ptr,int N, std::function< int (int)> fun,func fun2 ) {   // std::function< int (int)> *** Functional Wrapper ***

    /*
       for 0 to 4, do the following
       find element at ith offset from ptr address
       pass it to fun
    */
    for(int i=0; i<N; i++)
    {
      std::cout <<  fun(ptr[i]) <<" ";
    }
    std::cout<<std::endl;

    for(int i=0; i<N; i++)
    {
      std::cout <<  fun2(ptr[i]) <<" ";
    }
}


int main()
{
    int arr [5] {1,2,3,4,5};

    // std::cout<<"\nNormal cube is: "<<cube(5)<<std::endl;

    // int (*ptr1) (int) = &square;

    int (*ptr2) (int) = &cube;  // std::function< int (int)> = &cube;

    operation(arr,5,ptr2,[&](int x){return x * x;});  //address of first location of arr, arr size and address of cube and square 
}
