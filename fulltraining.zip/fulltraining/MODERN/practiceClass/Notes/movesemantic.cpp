#include<iostream>

#include <memory>

#include"Employee.h"


//it accepts a unique ptr to Employee and prints its value..
void magic(std::unique_ptr<Employee>& ptr)
{

}


void Demo(std::unique_ptr<Employee>&& ptr)
{

}

int main()
{
    auto e1 = std::make_unique<Employee>(101);
    
    magic(e1);

    /*
      to convert anything into a temporary (rvalue), std::move..
    */

    Demo(std::move(e1));  // by rvalue reference.

    Demo(std::make_unique<Employee>(102));

    // Note:-  after the move operation do not try to access the original resource because it was deleted.
}


/*
  step 1: main()
  step 2:we create e1 (unique pointer to Employee) [Resource acquired 4 bytes memory]
  step 3:Call to magic [funcition accepts unique ptr to Employee] ()
        --this works because we never copied oringnal unique ptr e1
        --

*/


// Within one sequence point value of one variable can not be modified more then one.