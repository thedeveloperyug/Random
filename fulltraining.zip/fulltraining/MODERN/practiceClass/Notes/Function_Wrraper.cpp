#include <iostream>
#include<functional>
#include<list>

using FnType = std::function<int(int)>;
/*
   I want to create a list of three functions

   a) a lambda function that takes an integer, returns its square
   b) a global function (top-level function) that takes an integer,
   returns lsit factorial (return -1 if intiger is negative or greater than 10)
   c) a temporary function take an integer and return its cube
*/

int factorial(int number)
{
    if(number <0 || number >10)
    {
        return -1;
    }

    else {
        int fact = 1;
        for(int count = 2;count<=number;count++) {
            fact *=count;
        }
        return fact;
    }
}

int main()
{
    std::list <FnType>data;
    data.push_back(&factorial);
    
    auto f1 = [](int number) { return number * number;};

    data.push_back( f1 );

    data.push_back( [](int number) {return number * number*number;} );

    // std::cout<< f1(10);

    for(FnType& fn : data ) {
        std::cout<< f1(10)<<" ";
    }
}

/*
     struct Lambda {
        operator() (int number) {
            return number * number ;
        }
     }
*/