#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include<iostream>

class Employee
{
private:
    int _eid;
    std::string _ename;
public:
    Employee() = default;  // Default Constructor..

    Employee(const Employee&) = default;  //Copy Constructor..

    Employee(Employee&&) = default;    //Move Copy Constructor..

    Employee& operator=(const Employee&) = default;  //"operator=" for copy Constructor..

    Employee& operator=(Employee&&) = default;   // "operator=" for move Constructor..

    ~Employee() = default;  // Destructor

    explicit Employee(int id,std::string ename ) : _eid(id),_ename(ename) {}

    void Demo() {
        std::cout << "\n\tDemo function called from base class";
    }
};

#endif // EMPLOYEE_H

