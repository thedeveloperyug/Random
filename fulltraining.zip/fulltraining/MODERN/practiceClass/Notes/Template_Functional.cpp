#include<functional>
#include<iostream>


template<typename T>
std::function <T> fn;

int main()
{
    fn<int(int)> = [](int number) {return number * number;};

    fn<float(int)> = [](int number) {return (float)number * number;};

    fn<float(int)>(10);
}