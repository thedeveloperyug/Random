#include<iostream>

/*

   Create 2 lamda function
   a) f1 : which is a function to take int, return square
   b) f2 : which is a function to take int, return cube

   Create a vector of 5 integer [10,20,30,40,50]

   Now, run the code to produce the following scope

   100 1000
   400 8000
   9000 270000
   1600 6400000 ...

*/

#include<vector>
#include<list>
#include<functional>

using FnType = std::function<int(int)>;

int main()
{
    std::vector<int>data {10,20,30,40,50};
    auto f1= [](int number){return (number * number); }; // lambda expression
    auto f2=[](int number) {return number * number * number;}; //lambda with explicit type deduction.

    std::list <FnType>fns {f1,f2};

    for(int val : data) {
        for(FnType& fn : fns) {
            std::cout << fn(val)<<"\t";
        }
        std::cout<<std::endl;
    }


    //option 2:

    for(int val : data){
        std::cout << [](int number){return (number * number); }(val)
        <<"\t"
        << [](int number) {return number * number * number;} (val)
        <<"\n";

    }


}

