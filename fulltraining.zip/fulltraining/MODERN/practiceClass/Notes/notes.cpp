


classes  &  template classes
  
     -- with special member function  & overload operators

-- Automatic  vs  heap  allocations

-- Smart pointers for resource management

-- reference semantic (lvalues & rvalues)
-MOVE SEMANTICS

-- I am not happy with references!!!!   // STL CONTAINERS DON'T WORK WITH RAW REFERENCES (REGULAR)

- reference_wrapper

-STL algorithms = inbuild function for finding the average 

--I need more ways to arrange my data!

-> Linear, LIFO, FIFO,Tress,Graphs,indexed,hash,balance tree : STL CONTAINERS

-- I can attach a pointer to everything! WHY NOT Function ?

-- std::function<T>  /*wrapper*/  : smart pointer for function.

-- Lambda function (temporary function)

-- can Compiler give me a gurranty that it will
take efforts to prevent a copy in the background?   -> guranted copy-elision (c++ 17)

-- How Do I Handle NOTHING? NULL DATA? Absense Of Data ?  -> std::optional wrapper

-- FUNCTIONAL POLIMERPHISM {using virtual function}  -> (using std::variant & std::visit)

std::any  -> used for store any type of files i.e .txt, .cpp, etc...

--concurrency mechanisms : using feachers for faster the program or to use our 100% cpu power.

***  WEEK - 1  ***
Completed;

starting-> WEEK 2:

Three paradigms of programings

-- Structures Programing!
-- Object oriented Programing!!
-- Functional Programing !!! *

-- Build Your solutions by the following principal
   "Always think about data, operation to be performed, and how to apply operation on data"

-- auto : determine the type os a veriable based on initial value

auto n1 = 10; //n1 is determine the type of a verialble based on initial value
n1 = 100;
n1 = "Harshit"  //error : type was already fixed as int

auto f1 = [](int number) {std::cout << number;};

   // f1 is a lambda function (with f1 as an object o fan internal class
   // Lambda) that takes one integer and returns void

-- template : allows you to determine a standered format of code structure that can be used by the compiler to 
   create more code at compiler time.





