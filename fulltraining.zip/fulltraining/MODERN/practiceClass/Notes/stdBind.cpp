/*

f(x,y)
f of x,y

   mathematician : funtion f is mapped to x & y
   programmer : function f takes input of x & y


   g(f(x,y)) is g(x) with y mapped or g(y) with x mapped

*/

#include<iostream>
#include<functional>


void formula(int x, int y, int z)
{
   std::cout << ( (x+y) - z ) <<std::endl;
}

struct Actor
{
   void DoSomethingYou (int x, int y, int z) {
   std::cout << ( (x+y) - z ) <<std::endl;
   }
};


using namespace std::placeholders;

int main()
{
   //partial implementation of formula where x is set to 100 already

   auto partial_formula_f1 = std::bind(&formula,100,_1,_2);   //x=100

   partial_formula_f1(29,45);   //let this is index of an array

   auto partial_formula_f2 = std::bind(&formula,100,_3,_2);   //x=100

   partial_formula_f2(29,45,55,56);   //let this is index of an array

   auto partial_formula_f3 = std::bind(&formula,_1,200,_2);   //x=100

   partial_formula_f3(29,45,55,56);   //let this is index of an array

   /*
      rules : formula has 3 parameters
          _1 means x is left for user to decide
            : pick
   */

  auto partial_function_swap = std::bind(&formula, _3,_2,_1);

  /*
     rules : formula has 3 parameters

     _3 means x is decided by the user
        : pick the 3rd parameter and map to x

     _2 means y is decided by the user
        : pick the 2nd parameter and map to y
     
     _3 means z is decided by the user
        : pick the 1st parameter and map it to z

  */

// Class function called like this below in bind

     Actor a1;
     auto class_fund_bind = std::bind(&Actor::DoSomethingYou, &a1, _3, _2, _1 );

     auto f1 = std::bind(functionaName, ContainerData, 101);
                           lamdaFun      data          fixValue

   f1();


}

/*
   
   bind does the following

   a) fixes the value
*/