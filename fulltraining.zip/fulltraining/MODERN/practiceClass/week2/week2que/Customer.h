#ifndef CUSTOMER_H
#define CUSTOMER_H

#include<iostream>
#include<functional>
#include "Account.h"
#include<memory>

using Pointer = std::shared_ptr<Account>;
using RefType = std::reference_wrapper<Pointer>;


class Customer
{
private:
    std::string _name {""};
    int _age = -1;
    RefType _account ;

public:
    
    Customer() = delete;

    Customer(const Customer&) = delete;

    Customer& operator=(Customer&) = delete;

    Customer(Customer&&) = delete;

    std::string name() const { return _name; }

    int age() const { return _age; }

    Customer& operator=(Customer&&) = delete;

    Customer(std::string name,int _age,RefType account);

    ~Customer() {}

    RefType account() const { return _account; }

    friend std::ostream &operator<<(std::ostream &os, const Customer &rhs);
};

#endif // CUSTOMER_H
