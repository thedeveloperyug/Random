#include "Account.h"

std::ostream &operator<<(std::ostream &os, const Account &rhs) {
    os << "_id: " << rhs._id
       << " _name: " << rhs._name
       << " _category: "<< DisplayAccount(rhs._category);
    return os;
}

std::string DisplayAccount(AccountType type)
{
    if(type == AccountType::BASIC)
       return "BASIC";
    else
       return "PRIMIUM";
}

Account::Account(int id)
  :_id(id)
{
}

Account::Account(int id, AccountType category)
  : _id(id), _category(category)
{
}


//this Constructor accepts 3 parameters int, string and AccountType
//It transfer int and AccountType to another constructor of the same class
//AND deals with the remaining parameter string

Account::Account(int id, std::string name, AccountType category)
  :Account(id,category)
{
    this->_name = name;
}
