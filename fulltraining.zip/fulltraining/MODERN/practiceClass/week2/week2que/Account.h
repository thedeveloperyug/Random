#ifndef ACCOUNT_H
#define ACCOUNT_H

#include<iostream>
#include "AccountType.h"

class Account
{
private:
    int _id;
    std::string _name;
    AccountType _category;
public:
    Account() = delete;    //  Account() = delete; we can set constructor as default

    Account(const Account&) = delete;

    Account& operator=(Account&) = delete;

    Account(Account&&) = delete;

    Account& operator=(Account&&) = delete;

    ~Account() = default;

    explicit Account(int id);

    explicit Account(int id,AccountType category);

    explicit Account(int id,std::string name,AccountType category);

    int id() const { return _id; }

    std::string name() const { return _name; }

    AccountType category() const { return _category; }

    friend std::ostream &operator<<(std::ostream &os, const Account &rhs);



};

std::string DisplayAccount(AccountType type);

#endif // ACCOUNT_H


/*
   Customer
      a) Shivam | 27 | [[[Account ka reference]]]
      b) [[[Shivam]]]
*/