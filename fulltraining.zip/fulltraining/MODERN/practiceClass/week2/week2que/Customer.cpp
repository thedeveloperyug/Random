#include "Customer.h"


//We have name, age and 
Customer::Customer(std::string name, int age, RefType account)
  : _name(name), _age(age), _account(account)
{


}

std::ostream &operator<<(std::ostream &os, const Customer &rhs) {
    os << "_name: " << rhs._name
       << " _age: " << rhs._age
       << " _account: " << *(rhs._account).get();
    return os;
}
