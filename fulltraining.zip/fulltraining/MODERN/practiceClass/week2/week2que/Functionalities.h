#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<vector>
#include "Customer.h"
#include<memory>
#include<functional>

using CustomerContainer = std::vector<std::shared_ptr<Customer>>;
using AccountContainer = std::vector<std::shared_ptr<Account>>;

void Operation(CustomerContainer& data , std::function<void(CustomerContainer&)>fn);

void CreateObject(CustomerContainer& data, AccountContainer& accs);

#endif // FUNCTIONALITIES_H
