#ifndef ACCOUNTTYPE_H
#define ACCOUNTTYPE_H

enum class AccountType
{
    PREMIUM = 1,
    BASIC = 0
};

#endif // ACCOUNTTYPE_H
