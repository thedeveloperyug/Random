#include "Functionalities.h"
#include "Customer.h"
#include "Account.h"
#include "Account.h"


void Operation(CustomerContainer &data, std::function<void(CustomerContainer & data)> fn)
{
    fn(data);
}

void CreateObject(CustomerContainer &data, AccountContainer &accs)
{
    accs.push_back( std::make_shared<Account>(101, AccountType::BASIC));
    accs.push_back( std::make_shared<Account>(102, AccountType::BASIC));
    accs.push_back( std::make_shared<Account>(103, AccountType::BASIC));

    data.push_back( std::make_shared<Customer>("Shivam",27, std::ref(accs[0]))) ;
    data.push_back( std::make_shared<Customer>("Harshit",26, std::ref(accs[1]))) ;
    data.push_back( std::make_shared<Customer>("Rohan",28, std::ref(accs[2]))) ;

    
}
