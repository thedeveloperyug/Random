#include "Functionalities.h"

using CustomerContainer = std::vector<std::shared_ptr<Customer>>;
using AccountContainer = std::vector<std::shared_ptr<Account>>;
using CustomerPointer = std::shared_ptr<Customer>;

#include<numeric>
#include<algorithm>


int main()
{
    CustomerContainer data;
    AccountContainer accs;

    CreateObject(data, accs);

    Operation(data, [&](CustomerContainer& data) {std::cout << *data[0]; });

    Operation(
        data,
        [&](CustomerContainer& data) { 
        float ans = std::accumulate(data.begin(), data.end(),0.0f,
        [](float total, CustomerPointer& Custom) {
            return total + Custom->age();
        });
         
        std::cout<<"\nAverage age is: "<<ans/data.size()<<std::endl;

        }
    );

    Operation(
        data,
        [&](CustomerContainer& data){
            auto itr = std::min_element(
                data.begin(),
                data.end(),
                [](CustomerPointer& c1, CustomerPointer& c2) {
                    return c1->age() < c2->age();
                }
            );

            std::cout<<"Min element of Customer is: "<<**itr<<std::endl;
        }
    );

    
}