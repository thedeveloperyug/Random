#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include<iostream>
#include<memory>

class Employee
{
private:
    int _id;
    float _salary;
public:
    Employee() = delete;
    Employee(const Employee&) = delete;
    Employee& operator=(const Employee&) = delete;
    Employee(Employee&&) = default;
    Employee& operator=(Employee&&) = delete;
    ~Employee() = default;

    Employee(int id, float salary);

    float salary() const { return _salary; }

};

using Pointer = std::unique_ptr<Employee>;

float CalculateTax(const Pointer& obj);

#endif // EMPLOYEE_H
