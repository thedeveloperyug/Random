#include "employee.h"

Employee::Employee(int id, float salary)
 :_id(id),_salary(salary)
{
}

float CalculateTax(const Pointer& obj)
{
    return obj->salary() * 0.1f;
}
