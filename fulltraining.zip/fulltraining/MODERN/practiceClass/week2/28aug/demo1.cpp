#include "employee.h"

#include <functional>
#include<memory>
#include<vector>

using Pointer = std::unique_ptr<Employee>;

void MappingFunction(std::vector<Pointer>& data,const std::function<float(const Pointer&)>& fn){
    for(auto& val : data) {
        std::cout<<" "<<fn(val) <<std::endl;
    }
}

int main() 
{
    std::vector<Pointer> data;

    auto e1 = std::make_unique<Employee>(101,4331.0f);

    auto e2 (std::move(e1));  //auto e2 = std::move(e1)
    data.push_back(std::move(e2));

    data.push_back(std::make_unique<Employee>(101, 98764.0f));
    data.push_back(std::make_unique<Employee>(102, 68764.0f));
    // data.push_back(std::make_unique<Employee>(103, 78764.0f));
    // data.push_back(std::make_unique<Employee>(104, 85764.0f));
    // data.push_back(std::make_unique<Employee>(105, 32764.0f));

    // data.push_back(std::move(e1));
    

    MappingFunction(data, CalculateTax );

    MappingFunction(data, [](const Pointer& obj) {return obj->salary() * 0.25f;});
    
    
}