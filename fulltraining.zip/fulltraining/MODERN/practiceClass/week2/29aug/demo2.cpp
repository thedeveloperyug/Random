#include "employee.h"
#include <vector>
#include <functional>
#include <memory>
#include <algorithm>  //min_element, max_element
#include <numeric>    //accumulate

using Pointer = std::unique_ptr<Employee>;
using SmartContainer = std::vector<Pointer>;
using RegularContainer = std::vector<Employee*>;

int main()
{
    RegularContainer regData {
        new Employee(101, 10000.0f),
        new Employee(102, 290000.0f),
        new Employee(111, 190000.0f),
        new Employee(122, 490000.0f),
        new Employee(133, 390000.0f)
    };

    SmartContainer smartData;
    smartData.push_back( std::make_unique<Employee>(103, 98700.0f));
    smartData.push_back( std::make_unique<Employee>(104, 98700.0f));
    smartData.push_back( std::make_unique<Employee>(105, 98700.0f));

    //Total slary of employee RegularContainer

    float combied_salary = std::accumulate(
        regData.begin(),
        regData.end(),
        0.0f,
        [](float ans, Employee* emp) {return ans + emp->salary();}
    );

    std::cout<< "Average of regData salary " <<combied_salary / regData.size();

    //Total slary of employee SmartContainer

    float combied_salary = std::accumulate(
        regData.begin(),
        regData.end(),
        0.0f,
        [](float ans, Pointer& emp) {return ans + emp->salary();}
    );

    //find employee with max salary

    auto itr = std::max_element(
        regData.begin(),
        regData.end(),
        [](Employee* e1,Employee* e2) {return e1->salary() < e2->salary();}
    );

    std::cout<<std::endl<<"Max salary amoung "<<**itr <<"\n";

    auto position_itr = std::max_element(
        smartData.begin(),
        smartData.end(),
        [](Pointer& e1,Pointer& e2) {return e1->salary() < e2->salary();}
    );

    std::cout<<"smart Max salary "<<**position_itr<<"\n";

}
