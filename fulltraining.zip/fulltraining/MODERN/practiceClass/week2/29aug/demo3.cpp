#include "employee.h"  //because data is of employees
#include "Project.h"  //because OBVIO YAAR!! Project bhi hai!
#include<functional>  //Because function programing genusis!

#include<iostream>  // Print karwana hai!
#include<memory>
#include<vector>

using Pointer = std::unique_ptr<Employee>;
using Container = std::vector<Pointer>;
using ProjectContainer = std::vector<std::unique_ptr<Project>>;

void CreateObject(Container& data, ProjectContainer& project_data) {
    project_data.push_back(std::make_unique<Project>("Honda"));

        data.push_back(
            std::make_unique<Employee>(101,19000.0f, std::ref(project_data[0] ))
        );
}

int main()
{
    Container data;
    ProjectContainer project_data;

    CreateObject(data, project_data);
}