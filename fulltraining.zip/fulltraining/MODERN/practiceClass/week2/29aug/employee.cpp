#include "employee.h"
#include<functional>
#include "Project.h"
#include<memory>
#include<functional>

using RefType = std::reference_wrapper<Project>;
using Pointer = std::unique_ptr<Employee>;


Employee::Employee(int id, float salary,RefType pr)
 :_id(id),_salary(salary),_active_project(pr)
{
}

std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "_id: " << rhs._id
       << " _salary: " << rhs._salary
       << " _active_project: " << rhs._active_project;
    return os;
}

float CalculateTax(const Pointer& obj)
{
    return obj->salary() * 0.1f;
}


