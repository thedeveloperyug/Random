#include<iostream>
#include<vector>

#include<functional>
#include<algorithm>
#include<numeric>

using Container = std::vector<float>;
using Ftype = std::function<float(Container)>;

int main()
{
    Container data {1.0f,45.6f,9.0f,56.7f};

    float ans = std::accumulate(data.begin(), data.end(), 0.0f);  //accumulator which add all the data.

    float product = std::accumulate(data.begin(), data.end(), 1.0f,
    [](float ans,float value) { return ans * value;});

//this gives position of max element
//if there are multiple max elements, it will give position of first max

    auto itr1 = std::max_element(data.begin(), data.end());

    std::cout<< *itr1;

    auto itr2 = std::max_element(data.begin(), data.end());

    std::cout<< *itr2;

    float avg = ans/data.size();

    std::cout<< avg;
}




//reduce
/*
Init

    0  10  20  30  40  50     it will contain the answer of the current point
    |   |   |
            |
            |
            |
            |
            |      
     10
      |
        30....

*/