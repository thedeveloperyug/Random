#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include<iostream>
#include<memory>
#include<functional>
#include "Project.h"

using RefType = std::reference_wrapper<Project>;

class Employee
{
private:
    int _id;
    float _salary;
    RefType _active_project;

public:
    Employee() = delete;
    Employee(const Employee&) = delete;
    Employee& operator=(const Employee&) = delete;
    Employee(Employee&&) = delete;   
    Employee& operator=(Employee&&) = delete;
    ~Employee() = default;

    Employee(int id=0, float salary=0, RefType pr);

    float salary() const { return _salary; }

    int id() const { return _id; }

    RefType activeProject() const { return _active_project; }

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);

    

    

};

using Pointer = std::unique_ptr<Employee>;

float CalculateTax(const Pointer& obj);

#endif // EMPLOYEE_H
