/*

   Create a container of 3 function

   --One that takes a vector of floats, return average
   --One that takes a vector of floats, return max
   --One that takes a vector of floats, return total of first three elements
*/

#include<iostream>
#include<vector>

#include<functional>

using Container = std::vector<float>;
using Ftype = std::function<float(Container)>;

auto f1 = [](Container& data) {
    //...exception pending!
    float total = 0.0f;
    for(auto& val : data)
    {
        total += val;
    }
    return total/data.size();
};


int main()
{
    Container data {1.0f,45.6f,9.0f,56.7f};
    std::vector <Ftype> fns {
       
    };
}