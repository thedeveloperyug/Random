#include<iostream>
#include<functional>


struct Employee
{
    int _id;
    std::reference_wrapper<std::string> _project;

    Employee(int id,std::reference_wrapper<std::string>pr)
    :_id(id),_project(pr) {}

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);

    

};


int main()
{
    std::string name = std::string("Harshit");
    Employee e1(101,std::ref(name));

    std::cout<<e1<<" ";
    
}

inline std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "_id: " << rhs._id
       << " _project: " << (rhs._project.get());
    return os;
}


//What do std::decay();
