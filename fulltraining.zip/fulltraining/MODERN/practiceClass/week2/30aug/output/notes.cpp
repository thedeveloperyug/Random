defination : std::ref can "Pass" something
as a __cpp_rvalue_references


How Does IT DO IT ?  It construct a reference_wrapper for thing written in the wrapper

Where 