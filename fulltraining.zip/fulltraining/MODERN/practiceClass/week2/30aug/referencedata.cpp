#include<iostream>
#include<functional>
#include<memory>



void magic(int& data) {
    std::cout<<"Data adress is: "<< &data;
    std::cout<<"Data value is: "<<data;

}

void old_function_without_reference(int& data) {
    std::cout<<"\nData adress is: "<< &data;
    std::cout<<"\nData value is: "<<data;
}


int main()
{
    int n1 = 10;

    std::cout<<"First time \n";

    old_function_without_reference(n1);

    std::cout<<"\nn1 adress is: "<< &n1;
    std::cout<<"\nn1 value is: "<<n1;

    std::cout<<"\n\nSecond time \n";

    old_function_without_reference(std::ref(n1));

    std::cout<<"\nn1 adress is: "<< &n1;
    std::cout<<"\nn1 value is: "<<n1;


    
/*
    magic(n1);  //valid 
    magic(10);  //Invalid: 10 is rvalue, we need lvalue
    magic(&n1);  //Invalid: &n1 is a Pointer
    magic(std::unique_ptr<int>(n1));  //Invalid : we are passing a rvalue (smart pointer)
    magic(std::ref(n1));  //redundant use of ref 
*/    
}

//Note: Modern CPP likes to put the data into the boxes and we can not put the reference in the 
//because it does not exit so we have to cheat with the compiler we use pointer of the data
//just like a reference that time use of reference wrapper.
