#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include "CabRide.h"
#include "CabRideType.h"
#include<memory>
#include<list>
#include<functional>
#include<numeric>
#include<algorithm>

using Pointer = std::shared_ptr<CabRide>;
using Container = std::list<Pointer>;


//Function for Creating the Object
void CreateObject(Container& data);

void HigherOrder(Container& data,std::function<void(Container&)> fn);

void HigherOrder(Container& data,std::function<void(Container&,float)> fn, float value);

//Function for printing the instances whose type is matched
void PrintInstancesType(Container& data);

void AveragePrinting(Container& data,float thershold);

void AverageOfRating(Container& data,float thershold);

void CountCabRide(Container& data);

void ConditionCheck(Container& data);



#endif // FUNCTIONALITIES_H
