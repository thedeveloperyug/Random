#include "Functionalities.h"

void CreateObject(Container &data)
{
    data.push_back(std::make_shared<CabRide>("cb101",100.0f,CabRideType::CARD,5.0f,2,"Sohan",1.5f));
    data.push_back(std::make_shared<CabRide>("cb201",300.0f,CabRideType::CASH,15.0f,4,"Mohan",4.5f));
    data.push_back(std::make_shared<CabRide>("cb301",500.0f,CabRideType::UPI,10.0f,5,"Rohan",5.0f));
    data.push_back(std::make_shared<CabRide>("cb401",200.0f,CabRideType::CARD,12.0f,6,"Sandi",3.5f));
}

void HigherOrder(Container &data, std::function<void(Container &)> fn)
{
    for(auto& i: data)
    {
        fn(data);
    }
}

void HigherOrder(Container& data,std::function<void(Container&,float)> fn,float value)
{

   for(auto& i : data)
   {
        fn(data,value);
   }
}

void PrintInstancesType(Container &data)
{
    std::for_each(
        data.begin(),
        data.end(),
        [](const Pointer& p) {
            if(p->ridePaymentType() == CabRideType::CASH)
            std::cout<<*p<<std::endl;
        }
    );
}

void AveragePrinting(Container &data, float thershold)
{
    int count =0;
    auto sum = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [&](float total=0.0f,Pointer& p) {
            if(p->rideDriverRating() > thershold)
            {
                count++;
                return total + p->rideDistance();
            }
            else 
            return total;
        }
    );
    std::cout<<"\nAverage of ride distance: "<<sum/count<<std::endl;
}

void AverageOfRating(Container &data, float thershold)
{
    int count =0;
    auto sum = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [&](float total=0.0f,Pointer& p) {
            if(p->rideDistance() > thershold)
            {
                count++;
                return total + p->rideDriverRating();
            }
            else 
            return total;
        }
    );
    std::cout<<"\nAverage of ride Rating: "<<sum/count<<std::endl;
}

void CountCabRide(Container &data)
{
    auto itr = std::count_if(
        data.begin(),
        data.end(),
        [](const Pointer& p) {
            return p->rideFare() > 150;
        }
    );

    std::cout<<"\nCount of CabRide: "<<itr<<std::endl;
}

void ConditionCheck(Container &data)
{
    if(data.empty()){
        throw std::runtime_error("Data empty \n");
    }

    auto flag = std::all_of(
        data.begin(),
        data.end(),
        [](Pointer& p){
            return p->ridePassengerCount() > 4;
        }
    );

    if(flag == 1){
        std::cout << "\nTRUE";
    }else{
        std::cout << "\nFALSE";
    }
}
