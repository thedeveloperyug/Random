#include"CabRide.h"
#include<memory>
#include<algorithm>
#include<numeric>
#include<list>
#include<functional>

using CabPointer = std::shared_ptr<CabRide>;
using CabContainer = std::list<CabPointer>;

/*
    A function to create 4 instances of CabRide type in a container
*/

void CreateObjects(CabContainer& data);

/*
    A higher order function that accepts
        - data container of cabride instances
        - a function wrapper that wrap 
            - input : a data container
            - output : void
*/

void HigherOrderFunction(CabContainer& data, const std::function<void(const CabContainer)>& fn);

/*
    A higher order function that accepts(overloaded)
        - data container of cabride instances
        - a function wrapper that wrap 
            - input : a data container & float
            - output : void
*/

void HigherOrderFunction(CabContainer& data, const std::function<void(const CabContainer, float)>& fn);

/*
    A function that prints details of the instances whose payment type is cash
*/

void PrintDetails(CabContainer& data);

/*
    A function that finds and prints average ride_distance of instances whose rating is above threshold parameter
*/

void FindAverageDistance(CabContainer& data, float rat);

/*
    A function to print average rating whose distance is passed as threshold
*/

void FindAverageRating(CabContainer& data, float dist);

/*
    A function to find and print the count of cabride instance whose fare is atleast 150
*/

void CountFare(CabContainer& data);

/*
    A function to find whether all instances have passenger count above 4 or not
*/

void CheckPassengerCount(CabContainer& data);


