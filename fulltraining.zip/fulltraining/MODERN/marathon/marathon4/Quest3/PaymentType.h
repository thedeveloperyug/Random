enum class PaymentType{
    CASH, 
    UPI,
    CARD
};