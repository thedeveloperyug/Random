#include"Functionalities.h"

using CabPointer = std::shared_ptr<CabRide>;
using CabContainer = std::list<CabPointer>;

/*
    A function to create 4 instances of CabRide type in a container
*/

void CreateObjects(CabContainer& data){
    CabPointer c1 = std::make_shared<CabRide>("101", 150.0f, PaymentType::CARD, 14.0f, 2, "Raju", 3);

    CabPointer c2 = std::make_shared<CabRide>("102", 200.0f, PaymentType::CASH, 15.0f, 2, "Ramest", 4);
    
    CabPointer c3 = std::make_shared<CabRide>("103", 175.0f, PaymentType::UPI, 16.0f, 4, "Riya", 3);

    CabPointer c4 = std::make_shared<CabRide>("104", 180.0f, PaymentType::CASH, 17.0f, 2, "Rajesh", 2);

    data.push_back(c1);
    data.push_back(c2);
    data.push_back(c3);
    data.push_back(c4);

}

/*
    A higher order function that accepts
        - data container of cabride instances
        - a function wrapper that wrap 
            - input : a data container
            - output : void
*/
void HigherOrderFunction(CabContainer &data, const std::function<void(const CabContainer)> &fn)
{
    for(auto& val : fn){
        val(data);
        std::cout << "\n";
    }
}

/*
    A higher order function that accepts(overloaded)
        - data container of cabride instances
        - a function wrapper that wrap 
            - input : a data container & float
            - output : void
*/

void HigherOrderFunction(CabContainer &data, const std::function<void(const CabContainer, float)> &fn)
{
    for(auto& val : fn){
        val(data, 5.0f);
        std::cout << "\n";
    }
}


/*
    A function that prints details of the instances whose payment type is cash
*/

void PrintDetails(CabContainer &data)
{
    if(data.empty()){
        throw std::runtime_error("Data empty \n");
    }

    CabContainer result(data.size());

    auto itr = std::copy_if(
        data.begin(),
        data.end(),
        result.begin(),
        [](CabPointer& c){
            return c->ridePaymentType() == PaymentType::CASH;
        }
    );

    result.resize(std::distance(result.begin(), itr));

    for(auto& val : result){
        std::cout << *val << "\n";
    }
    
}

/*
    A function that finds and prints average ride_distance of instances whose rating is above threshold parameter
*/
void FindAverageDistance(CabContainer &data, float rat)
{
    if(data.empty()){
        throw std::runtime_error("Data empty \n");
    }

    int count = 0;

    float total = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [&](float val, CabPointer& c){
            if(c->rideDriverRating() > rat){
                return val + c->rideDistance();
                count++;
            }
        }
    );

    std::cout << "Average distance is: " << total / count << "\n";

}

/*
    A function to print average rating whose distance is passed as threshold
*/

void FindAverageRating(CabContainer &data, float dist)
{
    if(data.empty()){
        throw std::runtime_error("Data empty \n");
    }

    int count = 0;

    float total = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [&](float val, CabPointer& c){
            if(c->rideDistance() > dist){
                return val + c->rideDriverRating();
                count++;
            }
        }
    );

    std::cout << "Average rating is: " << total / count << "\n";

}

/*
    A function to find and print the count of cabride instance whose fare is atleast 150
*/

void CountFare(CabContainer &data)
{
    if(data.empty()){
        throw std::runtime_error("Data empty \n");
    }

    int val = std::count_if(
        data.begin(),
        data.end(),
        [](CabPointer& c){
            return c->rideFare() >= 150.0f;
        }
    );

    std::cout << "Instances whose fare is atleast 150 are: " << val << "\n";
}

/*
    A function to find whether all instances have passenger count above 4 or not
*/

void CheckPassengerCount(CabContainer &data)
{
    if(data.empty()){
        throw std::runtime_error("Data empty \n");
    }

    bool flag = std::all_of(
        data.begin(),
        data.end(),
        [](CabPointer& c){
            return c->ridePassengerCount() > 4;
        }
    );

    if(flag == 1){
        std::cout << "TRUE";
    }else{
        std::cout << "FALSE";
    }

}
