#include "Functionalities.h"
#include<functional>

using CabPointer = std::shared_ptr<CabRide>;
using CabContainer = std::list<CabPointer>;

using functions_set_A = std::vector<std::function<void(Container)>>;

using functions_set_B = std::vector<std::function<void(Container, float)>>;

using namespace std::placeholders;

int main()
{
    CabContainer data;

    try
    {
        CreateObjects(data);

    }
    catch(const std::exception e){
        std::cerr << e.what() << '\n';
    }

    try{
    functions_set_A fun;

    fun.push_back(&PrintDetails);
    fun.push_back(&CountFare);
    fun.push_back(&CheckPassengerCount);

    for(auto& val : fun){
        HigherOrderFunction(data, val);
    }

    auto partial_fun_1 = std::bind(&FindAverageDistance,_1,4.5);
    partial_fun_1(data);

    auto partial_fun_2 = std::bind(&FindAverageRating,_1,6.1);
    partial_fun_2(data);

    functions_set_B fun2;

    fun2.push_back(&partial_fun_1);
    fun2.push_back(&partial_fun_2);

    for(auto& val : fun2){
        HigherOrderFunction(data, val);
    }
    }
    catch(const std::exception e){
        std::cerr << e.what() << '\n';
    }

}