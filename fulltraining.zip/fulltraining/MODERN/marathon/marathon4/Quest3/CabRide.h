#ifndef CABRIDE_H
#define CABRIDE_H

#include<iostream>
#include"PaymentType.h"
class CabRide{
private:    
    std::string _ride_id;
    float _ride_fare;
    PaymentType _ride_payment_type;
    float _ride_distance;
    int _ride_passenger_count;
    std::string _ride_driver_name;
    float _ride_driver_rating;
    float _ride_gst_amount;

public:
    CabRide() = delete;                           // deleted default constructor
    CabRide(const CabRide &) = delete;             // deleted copy constructor
    CabRide &operator=(const CabRide &) = delete;  // deleted copy assignment operator
    CabRide &operator=(const CabRide &&) = delete; // deleted move assignment operator
    CabRide(CabRide &&) = delete;                  // deleted move constructor
    ~CabRide() = default;                         // enabled destructor

    CabRide(std::string id, float fare, PaymentType type, float dist, int count, std::string driver_name, float rating);

    std::string rideId() const { return _ride_id; }

    float rideFare() const { return _ride_fare; }

    PaymentType ridePaymentType() const { return _ride_payment_type; }

    float rideDistance() const { return _ride_distance; }

    int ridePassengerCount() const { return _ride_passenger_count; }

    float rideDriverRating() const { return _ride_driver_rating; }

    float rideGstAmount() const { return _ride_gst_amount; }

    friend std::ostream &operator<<(std::ostream &os, const CabRide &rhs);

};

std::string DisplayEnum(PaymentType type);

#endif // CABRIDE_H
