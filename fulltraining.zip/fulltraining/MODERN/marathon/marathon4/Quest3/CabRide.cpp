#include "CabRide.h"
std::ostream &operator<<(std::ostream &os, const CabRide &rhs) {
    os << "_ride_id: " << rhs._ride_id
       << " _ride_fare: " << rhs._ride_fare
       << " _ride_payment_type: " << DisplayEnum(rhs._ride_payment_type)
       << " _ride_distance: " << rhs._ride_distance
       << " _ride_passenger_count: " << rhs._ride_passenger_count
       << " _ride_driver_name: " << rhs._ride_driver_name
       << " _ride_driver_rating: " << rhs._ride_driver_rating
       << " _ride_gst_amount: " << rhs._ride_gst_amount;
    return os;
}
std::string DisplayEnum(PaymentType type)
{
    if(type == PaymentType::CARD){
        return "CARD";
    }else if(type == PaymentType::CASH){
        return "CASH";
    }else{
        return "UPI";
    }
}

CabRide::CabRide(std::string id, float fare, PaymentType type, float dist, int count, std::string driver_name, float rating)
            : _ride_id(id), _ride_fare(fare), _ride_payment_type(type), _ride_distance(dist), _ride_passenger_count(count), _ride_driver_name(driver_name), _ride_driver_rating(rating)
{
    if(count >= 1 && count <= 6){
        _ride_passenger_count = count;
    }else{
        throw std::runtime_error("Enter valid passenger count \n");
    }

    if(rating >= 1 && rating <= 5){
        _ride_driver_name = rating;
    }else{
        throw std::runtime_error("Enter valid rating \n");
    }

    _ride_gst_amount = 0.33 * _ride_fare;


}
