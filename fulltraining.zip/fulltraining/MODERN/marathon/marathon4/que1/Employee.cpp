#include "Employee.h"

Employee::Employee(int _id, std::string _name, float _salary, SystemPointer _system, int _age, Department _department, int _experience_months)
: _id(_id),_name(_name),_salary(_salary),_system(_system),_age(_age),_department(_department),_experience_months(_experience_months)
{
    if(_id < 1 && _id > 999)
    {
        throw std::runtime_error("Invalid Id number");
    }
    if(_salary < 70000.0f && _salary < 100000.0f)
    {
        throw std::runtime_error("Invalid slary");
    }
    if(_experience_months < 10)
    {
        throw std::runtime_error("no exprince");
    }
}
std::ostream &operator<<(std::ostream &os, const Employee &rhs) {
    os << "_id: " << rhs._id
       << " _name: " << rhs._name
       << " _salary: " << rhs._salary
       << " _system: " << *rhs._system.get()
       << " _age: " << rhs._age
       << " _department: " <<DisplayDepartment(rhs._department)
       << " _experience_months: " << rhs._experience_months;
    return os;
}

std::string DisplayDepartment(Department type)
{
    if(type == Department::ACCOUNTS)
    {
        return "ACCOUNTS";
    }
    else if(type == Department::ADMIN)
    {
        return "ADMIN";
    }
    else if(type == Department::HR)
    {
        return "HR";
    }
    else if(type == Department::IT)
    {
        return "IT";
    }
    else
    {
        return "SECURITY";
    }
}
