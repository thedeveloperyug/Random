#ifndef DEPARTMENT_H
#define DEPARTMENT_H

enum class Department
{
    IT,
    ADMIN,
    HR,
    ACCOUNTS,
    SECURITY
};

#endif // DEPARTMENT_H
