#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include<iostream>
#include "Department.h"
#include "System.h"
#include<memory>

using SystemPointer = std::shared_ptr<System>;

class Employee
{
private:
    int _id;
    std::string _name;
    float _salary;
    SystemPointer _system;
    int _age;
    Department _department;
    int _experience_months;
public:
    Employee() = delete;   //Default Constructor

    Employee(const Employee&) = delete;    //Copy Constructor Disable

    Employee& operator=(const Employee&) = delete;    //Copy assigment Disable

    Employee(Employee&&) = delete;    // Move Constructor Disable

    Employee& operator=(Employee&&) = delete;   //Move assigment

    ~Employee() = default;   //Distructor default

    int id() const { return _id; }

    std::string name() const { return _name; }

    float salary() const { return _salary; }

    SystemPointer system() const { return _system; }

    int age() const { return _age; }

    Department department() const { return _department; }

    int experienceMonths() const { return _experience_months; }

    Employee(int _id,std::string _name,float _salary,SystemPointer _system,int _age,Department _department,int _experience_months);

    friend std::ostream &operator<<(std::ostream &os, const Employee &rhs);

};

std::string DisplayDepartment(Department type);

#endif // EMPLOYEE_H
