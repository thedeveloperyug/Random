#ifndef SYSTEMTYPE_H
#define SYSTEMTYPE_H

enum class SystemType
{
    _8GB,
    _16GB,
    _32GB

};

#endif // SYSTEMTYPE_H
