#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include "System.h"
#include "Employee.h"
#include "Department.h"
#include "SystemType.h"
#include<array>
#include<memory>
#include<algorithm>
#include<numeric>
#include<optional>

using PointerEmployee = std::shared_ptr<Employee>;
using Container = std::array<PointerEmployee,5>;

//Function to create object in array container
void CreateObject(Container& data);

//Function to find and return the average salary of Employee whose branch is IT
float AverageSalaryOfIT(Container& data);

//Function to print the instances whose salary is highest
void InstaceWithHighestSalary(Container& data);

//Function to check the wheather all of the Container object age is above 25..
bool AgeIsAbove(Container& data);

//Function to return the container in which instances matches the condition
std::optional<std::vector<PointerEmployee>> InstanceMatchingTheCondition(Container& data);

//Function to find the count of instances whose salary is above 80000.0f and age is less then 30
int CountInstancesWithHigherThan80K(Container& data);

#endif // FUNCTIONALITIES_H
