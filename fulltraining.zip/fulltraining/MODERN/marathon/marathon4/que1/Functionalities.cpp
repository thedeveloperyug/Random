#include "Functionalities.h"

//Function to create object in array container
void CreateObject(Container &data)
{
    data[0] = std::make_shared<Employee>(101,"Raju",70000.0f,std::make_shared<System>(SystemType::_16GB,500,"S101"),19,Department::IT,10);
    data[1] = std::make_shared<Employee>(102,"Sohan",80000.0f,std::make_shared<System>(SystemType::_32GB,500,"S101"),25,Department::ADMIN,15);
    data[2] = std::make_shared<Employee>(103,"Mohan",75000.0f,std::make_shared<System>(SystemType::_8GB,500,"S101"),30,Department::HR,20);
    data[3] = std::make_shared<Employee>(104,"Ram",100000.0f,std::make_shared<System>(SystemType::_16GB,500,"S101"),40,Department::IT,13);
    data[4] = std::make_shared<Employee>(105,"Riya",90000.0f,std::make_shared<System>(SystemType::_32GB,500,"S101"),50,Department::SECURITY,14);
}

float AverageSalaryOfIT(Container &data)
{
    if(data.empty())
    {
        throw std::runtime_error("data is empty");
    }
    int count=0;
    auto sum = std::accumulate(
        data.begin(),
        data.end(),
        0.0f,
        [&](float total = 0.0f,const PointerEmployee& s) {
            if(s->department() == Department::IT)
            {
                count++;
                return total + s->salary();
            }
            else
            {
                return total;
            }
        }
    );
    return sum/count;
}

//Function to print the instances whose salary is highest
void InstaceWithHighestSalary(Container &data)
{
    if(data.empty())
    {
        throw std::runtime_error("data is empty");
    }
    auto itr = std::max_element(
        data.begin(),
        data.end(),
        [](const PointerEmployee& e1,const PointerEmployee& e2) {
            return e1->salary() < e2->salary();
        }
    );

    float highestsal= 0.0f;

    highestsal = itr->get()->salary();

    for(auto i: data)
    {
        if(i->salary() == highestsal)
        {
            std::cout<<"With Highest Salary: "<<*i<<std::endl;
        }
    }
}

//Function to check the wheather all of the Container object age is above 25..
bool AgeIsAbove(Container &data)
{
    if(data.empty())
    {
        throw std::runtime_error("data is empty");
    }
    auto itr = std::all_of(
        data.begin(),
        data.end(),
        [](const PointerEmployee& e) {
            return e->age() > 25;
        }
    );

    return itr;
}

//Function to return the container in which instances matches the condition
std::optional<std::vector<PointerEmployee>> InstanceMatchingTheCondition(Container &data)
{
    if (data.empty())
    {
        throw std::runtime_error("data is emty");
    }
    std::vector<PointerEmployee> result(data.size());

    auto itr = std::copy_if(
        data.begin(),
        data.end(),
        result.begin(),
        [](const PointerEmployee& e) {
            return e->system().get()->memory() == SystemType::_16GB  && e->system().get()->diskSpace() == 10 && e->department() ==Department::IT;
        }
    );

    result.resize(std::distance(result.begin(),itr));

    if(result.empty())
    {
        return std::nullopt;
    }
    return result;
    
}

//Function to find the count of instances whose salary is above 80000.0f and age is less then 30
int CountInstancesWithHigherThan80K(Container &data)
{
    if(data.empty())
    {
        throw std::runtime_error("data is emty");
    }
    auto itr = std::count_if(
        data.begin(),
        data.end(),
        [](const PointerEmployee& e){return e->salary()>80000.0f && e->age() < 30;}
    );

    return itr;
}
