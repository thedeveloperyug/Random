#ifndef SYSTEM_H
#define SYSTEM_H

#include<iostream>
#include "SystemType.h"

class System
{
private:
    SystemType _memory;
    int _disk_space;
    std::string _allocation_number;
public:
    System() = delete;   //Default Constructor

    System(const System&) = delete;    //Copy Constructor Disable

    System& operator=(const System&) = delete;    //Copy assigment Disable

    System(System&&) = delete;    // Move Constructor Disable

    System& operator=(System&&) = delete;   //Move assigment

    ~System() = default;   //Distructor default

    SystemType memory() const { return _memory; }

    int diskSpace() const { return _disk_space; }

    std::string allocationNumber() const { return _allocation_number; }

    System(SystemType _memory,int _disk_space,std::string _allocation_number);

    friend std::ostream &operator<<(std::ostream &os, const System &rhs);

};

std::string DisplaySystemType(SystemType type);

#endif // SYSTEM_H
