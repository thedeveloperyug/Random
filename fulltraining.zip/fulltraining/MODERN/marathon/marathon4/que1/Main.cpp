#include<iostream>
#include "System.h"
#include "Employee.h"
#include "Department.h"
#include "SystemType.h"
#include<array>
#include<memory>
#include<algorithm>
#include<numeric>
#include "Functionalities.h"

using PointerEmployee = std::shared_ptr<Employee>;
using Container = std::array<PointerEmployee,5>;

int main()
{
    Container data;

    try
    {
        CreateObject(data);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        std::cout<<"Average Salary WHose Department is IT: "<<AverageSalaryOfIT(data)<<std::endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        InstaceWithHighestSalary(data);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        std::cout<<"Wheather all age is above 25: "<<AgeIsAbove(data)<<std::endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        std::cout<<"Count: "<<CountInstancesWithHigherThan80K(data)<<std::endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
       std::optional<std::vector<PointerEmployee>> result = InstanceMatchingTheCondition(data);

       if(result.has_value()){
       for(auto& i: result.value())
       {
        std::cout<<*i<<std::endl;
       }
       }
       else
       {
        std::cout<<"data is emty";
       }
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    
    
    
    
    
    
    
}

    