#include "System.h"

System::System(SystemType _memory, int _disk_space, std::string _allocation_number)
: _memory(_memory),_disk_space(_disk_space),_allocation_number(_allocation_number)
{
}
std::ostream &operator<<(std::ostream &os, const System &rhs) {
    os << "_memory: " <<DisplaySystemType(rhs._memory)
       << " _disk_space: " << rhs._disk_space
       << " _allocation_number: " << rhs._allocation_number;
    return os;
}

std::string DisplaySystemType(SystemType type)
{
    if(type ==SystemType::_8GB)
    {
        return "8GB";

    }
    else if(type == SystemType::_32GB)
    {
        return "32GB";
    }
    else 
    {
        return "16GB";
    }
}
