#include "Task.h"

Task::Task(std::string _task_description, int _allocated_days, int _allocated_resource, TaskType _category)
:_task_description(_task_description),_allocated_days(_allocated_days),_allocated_resource(_allocated_resource),_category(_category)
{

}
std::ostream &operator<<(std::ostream &os, const Task &rhs) {
    os << "_task_description: " << rhs._task_description
       << " _allocated_days: " << rhs._allocated_days
       << " _allocated_resource: " << rhs._allocated_resource
       << " _category: " <<DisplayTaskCategory(rhs._category);
    return os;
}

std::string DisplayTaskCategory(TaskType type)
{
    if(type == TaskType::BUG_FIX)
    {
        return "BUG_FIX";
    }
    else if(type == TaskType::FEATURE_ADDITION)
    {
        return "FEATURE_ADDITION";
    }
    else
    {
        return "REFACTOR";
    }
}
