#ifndef PROJECTALLOCATEDRESOURCE_H
#define PROJECTALLOCATEDRESOURCE_H

#include<iostream>
#include "Task.h"
#include<vector>
#include<memory>

using PointerTask = std::shared_ptr<Task>;
using TaskContainer = std::vector<PointerTask>;

class ProjectAllocatedResource
{
private:
    std::string _id;
    std::string _name;
    TaskContainer _tasks;
    float _billing_amount;
    float _expense_cap;
public:
    ProjectAllocatedResource() = delete;   //Default Constructor

    ProjectAllocatedResource(const ProjectAllocatedResource&) = delete;    //Copy Constructor Disable

    ProjectAllocatedResource& operator=(const ProjectAllocatedResource&) = delete;    //Copy assigment Disable

    ProjectAllocatedResource(ProjectAllocatedResource&&) = delete;    // Move Constructor Disable

    ProjectAllocatedResource& operator=(ProjectAllocatedResource&&) = delete;   //Move assigment

    ~ProjectAllocatedResource() = default;   //Distructor default

    std::string id() const { return _id; }

    std::string name() const { return _name; }

    float billingAmount() const { return _billing_amount; }

    float expenseCap() const { return _expense_cap; }

    ProjectAllocatedResource(std::string _id,std::string _name,TaskContainer _tasks,float _billing_amount,float _expense_cap);

    TaskContainer tasks() const { return _tasks; }

    

    friend std::ostream &operator<<(std::ostream &os, const ProjectAllocatedResource &rhs);

    
};

#endif // PROJECTALLOCATEDRESOURCE_H
