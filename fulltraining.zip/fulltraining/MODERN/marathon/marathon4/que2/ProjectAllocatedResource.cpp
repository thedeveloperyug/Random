#include "ProjectAllocatedResource.h"


ProjectAllocatedResource::ProjectAllocatedResource(std::string _id, std::string _name, TaskContainer _tasks, float _billing_amount, float _expense_cap)
: _id(_id),_name(_name),_tasks(_tasks),_billing_amount(_billing_amount),_expense_cap(_expense_cap)
{
    for(auto i: _tasks)
    {
        if(i->taskDescription().size() < 10)
        {
            throw std::runtime_error("invalide");
        }
    }

    for(auto i : _tasks)
    {
        if(i->allocatedDays() > 10)
        {
            throw std::runtime_error("invalid");
        }
    }
}

std::ostream &operator<<(std::ostream &os, const ProjectAllocatedResource &rhs) {
    os << "_id: " << rhs._id
       << " _name: " << rhs._name
       << " _tasks: " ;
       for(auto i : rhs._tasks)
       {
        os <<*i<<std::endl;
       }
    os   << " _billing_amount: " << rhs._billing_amount
       << " _expense_cap: " << rhs._expense_cap;
    return os;
}
