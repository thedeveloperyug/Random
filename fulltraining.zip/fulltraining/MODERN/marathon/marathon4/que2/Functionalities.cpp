#include "Functionalities.h"

void CreateObject(Container &Pdata)
{

    Pdata[0] = std::make_shared<ProjectAllocatedResource>("Emp101","Kunal",std::vector<PointerTask> {std::make_shared<Task>("Moderncppbatch1",3,1,TaskType::BUG_FIX)},5000.0f,1000.0f);
    Pdata[1] = std::make_shared<ProjectAllocatedResource>("Emp102","Rohan",std::vector<PointerTask> {std::make_shared<Task>("Javacppbatch2",5,5,TaskType::FEATURE_ADDITION),std::make_shared<Task>("Pythoncppbatch3",2,2,TaskType::REFACTOR),std::make_shared<Task>("Matlabcppbatch4",7,3,TaskType::BUG_FIX)},10000.0f,3000.0f);
    Pdata[2] = std::make_shared<ProjectAllocatedResource>("Emp103","Jaya",std::vector<PointerTask> {std::make_shared<Task>("Pythoncppbatch3",2,2,TaskType::REFACTOR)},15000.0f,5000.0f);
    Pdata[3] = std::make_shared<ProjectAllocatedResource>("Emp104","Raman",std::vector<PointerTask> {std::make_shared<Task>("Matlabcppbatch4",7,3,TaskType::BUG_FIX)},8000.0f,2000.0f);

}

//Function to Display the Count of instances
void CountInstanceDisplay(Container &Pdata)
{
    if(Pdata.empty())
    {
        throw std::runtime_error("data is empty");
    }
    auto count = std::count_if(
        Pdata.begin(),
        Pdata.end(),
        [](const PointerProject& p) {
            return p->tasks().size() > 2;
        }
    );
    std::cout<<"Count of task above 3: "<<count<<std::endl;
}

//Function to find the highest expance cap
void HighestExpenseCap(Container &data)
{
    if(data.empty())
    {
        throw std::runtime_error("data is emty");
    }
    auto itr = std::max_element(
        data.begin(),
        data.end(),
        [](const PointerProject& p1,const PointerProject& p2) {
            return p1->expenseCap() < p2->expenseCap();
        }
    );

    std::cout<<"Highest expenses_Cap: "<< *itr->get()<<std::endl;

    
}

//Function to return the bool wheather any of task have all BUG
bool TaskOfBug(Container &data)
{
    if(data.empty())
    {
        throw std::runtime_error("data is empty");
    }
    auto flag = std::any_of(
        data.begin(),
        data.end(),
        [](const PointerProject& p) {
           auto itr = std::all_of(
            p->tasks().begin(),
            p->tasks().end(),
            [](const PointerTask& t) {
                return t->category() == TaskType::BUG_FIX;
            }
           );
           return itr;
        }
    );

    return flag;
}

//Function for return the enum and whose maximum billinf amount
std::vector<TaskType> CategoryWithMaximumBilling(Container &data)
{
    if(data.empty())
    {
        throw std::runtime_error("data is emty");
    }
    auto itr = std::max_element(
        data.begin(),
        data.end(),
        [](const PointerProject& p1,const PointerProject& p2) {
            return p1->billingAmount() < p2->billingAmount();
        }
    );

    std::vector<TaskType> type ;

    for(auto i : data)
    {
        for(auto j : i->tasks())
        {
            if(i->billingAmount()==itr->get()->billingAmount())
            {
                type.push_back(j.get()->category());
            }
        }
    }

    return type;
}

//Function for return the container with sorted billing amount
Container SortedByBillAmount(Container &data)
{
    if(data.empty())
    {
        throw std::runtime_error("data is empty");
    }
    std::sort(
        data.begin(),
        data.end(),
        [](const PointerProject& p1,const PointerProject& p2) {
            return p1->expenseCap() < p2->expenseCap();
        }
    );
std::cout<<"\nexpense sorted: ";
    for(auto i: data)
    {
        std::cout<<i->expenseCap()<<" ";
    }

    return data;

    
}
