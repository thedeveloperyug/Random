#ifndef TASK_H
#define TASK_H

#include<iostream>
#include "TaskType.h"

class Task
{
private:
    std::string _task_description;
    int _allocated_days;
    int _allocated_resource;
    TaskType _category;
public:
    Task() = delete;   //Default Constructor

    Task(const Task&) = delete;    //Copy Constructor Disable

    Task& operator=(const Task&) = delete;    //Copy assigment Disable

    Task(Task&&) = delete;    // Move Constructor Disable

    Task& operator=(Task&&) = delete;   //Move assigment

    ~Task() = default;   //Distructor default

    Task(std::string _task_description,int _allocated_days,int _allocated_resource,TaskType _category);

    std::string taskDescription() const { return _task_description; }

    int allocatedDays() const { return _allocated_days; }

    int allocatedResource() const { return _allocated_resource; }

    TaskType category() const { return _category; }

    friend std::ostream &operator<<(std::ostream &os, const Task &rhs);
    
};

std::string DisplayTaskCategory(TaskType type);

#endif // TASK_H
