#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include "Task.h"
#include "ProjectAllocatedResource.h"
#include "TaskType.h"
#include<array>
#include<numeric>
#include<algorithm>

using PointerProject = std::shared_ptr<ProjectAllocatedResource>;
using Container = std::array<PointerProject,4>;


//Function to Create Object
void CreateObject(Container& Pdata);

//Function to Display the Count of instances
void CountInstanceDisplay(Container& Pdata);


//Function to find the highest expance cap
void HighestExpenseCap(Container& data);


//Function to return the bool wheather any of task have all BUG
bool TaskOfBug(Container& data);

//Function for return the enum and whose maximum billinf amount
std::vector<TaskType> CategoryWithMaximumBilling(Container& data);

//Function for return the container with sorted billing amount
Container SortedByBillAmount(Container &data );



#endif // FUNCTIONALITIES_H
