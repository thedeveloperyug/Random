#include<iostream>
#include "Task.h"
#include "ProjectAllocatedResource.h"
#include "TaskType.h"
#include<array>
#include "Functionalities.h"

using PointerProject = std::shared_ptr<ProjectAllocatedResource>;
using Container = std::array<PointerProject,4>;

using TaskContainer = std::vector<std::shared_ptr<Task>>;

int main()
{
    Container Pdata;
    TaskContainer Tdata;
    //create 3 tasks with different types and assign them to projects
    try
    {
        CreateObject(Pdata);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        CountInstanceDisplay(Pdata);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        HighestExpenseCap(Pdata);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        std::cout<<"Any of instance have all BUG_FIX: "<<TaskOfBug(Pdata)<<std::endl;
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }

    try
    {
        
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    
    try
    {
        std::vector<TaskType> type = CategoryWithMaximumBilling(Pdata);

    std::cout<<"\nTypes are: ";
        for(auto& i: type)
        {
            std::cout<<DisplayTaskCategory(i)<<std::endl;
        }
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    

    try
    {
        std::array<PointerProject,4> result = SortedByBillAmount(Pdata);

        for(auto& i: result)
        {
            std::cout<<*i<<std::endl;
        }
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
    
    
    
}