#ifndef TASKTYPE_H
#define TASKTYPE_H

enum class TaskType
{
    REFACTOR,
    BUG_FIX,
    FEATURE_ADDITION
};

#endif // TASKTYPE_H
