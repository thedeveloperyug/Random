#ifndef PAYMENTMODE_H
#define PAYMENTMODE_H

enum class PaymentMode
{
    UPI,
    CASH,
    CARD,
    WALLET
};

#endif // PAYMENTMODE_H
