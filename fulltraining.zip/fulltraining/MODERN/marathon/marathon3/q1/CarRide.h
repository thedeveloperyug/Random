#ifndef CARRIDE_H
#define CARRIDE_H

#include<iostream>
#include "CabRideType.h"
#include<variant>
#include "PaymentMode.h"

class CarRide
{
private:
    std::variant<int,std::string> _id;
    CabRideType _type;
    PaymentMode _payment_mode;
    float _fare;
    std::string _drop_location;
    std::string _pickup_location;

public:
    CarRide() = delete;

    CarRide(const CarRide&) = delete;

    CarRide& operator=(const CarRide&) = delete;

    CarRide(CarRide&&) = delete;

    CarRide& operator=(CarRide&&) = delete;

    ~CarRide() = default;    

    CarRide(std::variant<int,std::string> id,CabRideType type,PaymentMode payment_mode,float fare,std::string drop_location,std::string pickup_location);

    std::variant<int,std::string> id() const { return _id; }

    CabRideType type() const { return _type; }

    PaymentMode paymentMode() const { return _payment_mode; }

    float fare() const { return _fare; }

    std::string dropLocation() const { return _drop_location; }

    std::string pickupLocation() const { return _pickup_location; }

    friend std::ostream &operator<<(std::ostream &os, const CarRide &rhs);

};
/* Function for Displaying the enum values*/
std::string DisplayRideType(CabRideType type);  

//Function for Displaying the Payment Mode
std::string DisplayPaymentMode(PaymentMode mode);

#endif // CARRIDE_H
