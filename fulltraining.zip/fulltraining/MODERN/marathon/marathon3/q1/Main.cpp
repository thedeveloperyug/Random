#include<iostream>
#include "CarRide.h"
#include "CabRideType.h"
#include "PaymentMode.h"
#include<memory>
#include<vector>
#include<variant>
#include "Functionalities.h"

using Pointer = std::shared_ptr<CarRide>;
using Container = std::vector<Pointer>;
using ContainerOfId = std::vector<std::variant<int,std::string>>;

using modeArray = std::array<PaymentMode,2>;

int main()
{
    Container data;

    ContainerOfId id;

    modeArray modearr;

    CreateObject(data);

    id.push_back(101);
    id.push_back(303);
    

    CabRideType type = TypePassingId(data,303);

    std::cout<<"******************************************"<<std::endl;

    try
    {
        std::cout<<DisplayRideType(type);
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    

    

    modearr = PaymentModeWithMaxMinFare(data);

    try
    {
     std::cout<<"\nPayment Mode with Max and Min value: ";
    for(int i=0;i<2;i++)
    {
        std::cout<<DisplayPaymentMode(modearr[i])<<" ";
    }
    }
    catch(const std::exception& e)
    {
        std::cerr << e.what() << '\n';
    }
    
   

    std::cout<<std::endl;

    std::cout<<"Average of fare Id's: "<<AverageFareWhoseId(data,id)<<std::endl;

    Container result;
    result = PickLocationNInstance(data,3);

    std::cout<<"PickUpLocation: ";

    for(auto r:result)
    {
        std::cout<<r->pickupLocation()<<" ";
    }

    std::cout<<CombinedFareOfInstance(data,CabRideType::LOCAL,PaymentMode::CARD)<<std::endl;



}