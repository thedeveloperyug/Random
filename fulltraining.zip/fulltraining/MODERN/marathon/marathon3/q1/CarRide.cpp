#include "CarRide.h"

CarRide::CarRide(std::variant<int, std::string> id, CabRideType type, PaymentMode payment_mode, float fare, std::string drop_location, std::string pickup_location)
:_id(id),_type(type),_payment_mode(payment_mode),_fare(fare),_drop_location(drop_location),_pickup_location(pickup_location)
{

}
std::ostream &operator<<(std::ostream &os, const CarRide &rhs) {
    os << "_id: ";
    std::visit([&](auto&& a){os << a;},rhs._id);
    os   << " _type: " <<DisplayRideType(rhs._type)
       << " _payment_mode: " <<DisplayPaymentMode(rhs._payment_mode)
       << " _fare: " << rhs._fare
       << " _drop_location: " << rhs._drop_location
       << " _pickup_location: " << rhs._pickup_location;
    return os;
}

std::string DisplayRideType(CabRideType type)
{
    if(type == CabRideType::LOCAL)
       return "LOCAL";
    else if(type == CabRideType::OUTSTATION)
       return "OUTSTATION";
    else
       return "RENT";
}

std::string DisplayPaymentMode(PaymentMode mode)
{
    if(mode == PaymentMode::CARD)
       return "CARD";
    else if(mode == PaymentMode::CASH)
       return "CASH";
    else if(mode == PaymentMode::UPI)
       return "UPI";
    else
       return "WALLET";
}
