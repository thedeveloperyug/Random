#include<iostream>
#include "CarRide.h"
#include "CabRideType.h"
#include "PaymentMode.h"
#include<memory>
#include<vector>
#include<variant>
#include<array>

using modeArray = std::array<PaymentMode,2>;

using Pointer = std::shared_ptr<CarRide>;
using Container = std::vector<Pointer>;

/*
  using Constainer of Id we can take vector of varient
*/
using ContainerOfId = std::vector<std::variant<int,std::string>>;

/*
  A Function for Creating the object
*/

void CreateObject(Container& data);

/*
  A Function for returnig the CarRideType by passing the Id as Argument
*/

CabRideType TypePassingId(Container& data,std::variant<int,std::string> id);

/*
  A Function for return the array of enum type for Payment Mode 
*/

modeArray PaymentModeWithMaxMinFare(Container& data);

/* 
  A Function for Calculating the Average fare whose id is pass as argument
*/

float AverageFareWhoseId(Container& data,ContainerOfId id);

/*
   A Function for finding the PickUp location for N Instance by passing the Container and N value 
*/

Container PickLocationNInstance(Container& data,int N);

/*
  A Function for Calculating the Fare of Combined Fare of Instances Whose Cab type Enum and Mode type
  enum is passed as agrgument
*/
float CombinedFareOfInstance(Container& data,CabRideType type,PaymentMode mode);