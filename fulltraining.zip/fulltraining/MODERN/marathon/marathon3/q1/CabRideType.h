#ifndef CABRIDETYPE_H
#define CABRIDETYPE_H

enum class CabRideType
{
    RENT,
    OUTSTATION,
    LOCAL
};

#endif // CABRIDETYPE_H
