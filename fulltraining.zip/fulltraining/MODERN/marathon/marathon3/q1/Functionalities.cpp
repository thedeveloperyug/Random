#include "Functionalities.h"

/*
  A Function for Creating the object
*/

void CreateObject(Container& data)
{
    data.push_back(std::make_shared<CarRide>(101,CabRideType::LOCAL,PaymentMode::CARD,200.0f,"Hinjewadi","Marunji"));
    data.push_back(std::make_shared<CarRide>(202,CabRideType::LOCAL,PaymentMode::CARD,500.0f,"pune","Mumbai"));
    data.push_back(std::make_shared<CarRide>(303,CabRideType::OUTSTATION,PaymentMode::CASH,700.0f,"punjab","Delhi"));
    data.push_back(std::make_shared<CarRide>(404,CabRideType::OUTSTATION,PaymentMode::UPI,1000.0f,"Bihar","Patna"));
    data.push_back(std::make_shared<CarRide>(505,CabRideType::RENT,PaymentMode::WALLET,2000.0f,"Hinjewadi","Marunji"));

}

/*
  A Function for returnig the CarRideType by passing the Id as Argument
*/

CabRideType TypePassingId(Container &data, std::variant<int, std::string> id)
{
    if(data.empty()) {
        throw std::runtime_error("NO DATA FOUND\n");
    }

    CabRideType type;
    
    for(Pointer& p : data)
    {
        if(id == p->id())
        {
            type = p->type();
        }
    }

    return type;
}
/*
  A Function for return the array of enum type for Payment Mode 
*/

modeArray PaymentModeWithMaxMinFare(Container &data)
{
    if(data.empty()) {
        throw std::runtime_error("NO DATA FOUND\n");
    }

    modeArray arr;
    float Max=data.front()->fare(),Min=data.front()->fare();

    for(Pointer& p: data)
    {
        if(Max > p->fare())
        {
        Max = p->fare();
        arr[0]=p->paymentMode();
        }
    }

    for(Pointer& p: data)
    {
        if(Min < p->fare())
        {
        Min = p->fare();
        arr[1]=p->paymentMode();
        }
    }

    return arr;
}
/* 
  A Function for Calculating the Average fare whose id is pass as argument
*/

float AverageFareWhoseId(Container &data, ContainerOfId id)
{
    if(data.empty()) {
        throw std::runtime_error("NO DATA FOUND\n");
    }
    int sum=0.0f;

    for(Pointer& p:data)
    {
        for(auto i : id)
        {
            if(i == p->id())
            {
                sum += p->fare();
            }
        }
    }
    return sum/id.size();
    
}


/*
   A Function for finding the PickUp location for N Instance by passing the Container and N value 
*/

Container PickLocationNInstance(Container &data, int N)
{
     if(data.empty()) {
        throw std::runtime_error("NO DATA FOUND\n");
    }

    if(N < 0 || N > data.size()) {
        throw std::runtime_error("N is Invalid!");
    }
    
    Container result;
    int count = N;

    for(Pointer& p: data)
    {
        if(count > 0)
        {
            result.push_back(p);
            count--;
        }
    }

    return result;
}

/*
  A Function for Calculating the Fare of Combined Fare of Instances Whose Cab type Enum and Mode type
  enum is passed as agrgument
*/

float CombinedFareOfInstance(Container &data, CabRideType type, PaymentMode mode)
{
    if(data.empty()) {
        throw std::runtime_error("NO DATA FOUND\n");
    }
    float fare = 0.0f;
    for(Pointer& p : data)
    {
        if(type == p->type() && mode == p->paymentMode())
        {
            fare += p->fare();
        }

    }
    return fare;
}
