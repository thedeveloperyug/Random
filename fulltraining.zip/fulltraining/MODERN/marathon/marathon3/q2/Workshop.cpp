#include "Workshop.h"

Workshop::Workshop(std::variant<int, std::string> centre_id, int service_point_count, WorkshopType type, int attendant_count, float evaluation_amount, int current_cases)
: _centre_id(centre_id),_service_point_count(service_point_count),_type(type),_attendant_count(attendant_count),_evaluation_amount(evaluation_amount),_current_cases(current_cases)
{
    
}

std::ostream &operator<<(std::ostream &os, const Workshop &rhs) {
    os << "_centre_id: ";
    std::visit([&](auto&& a){os << a;},rhs._centre_id);
    os   << " _service_point_count: " << rhs._service_point_count
       << " _type: " <<DisplayEnumWork(rhs._type)
       << " _token_number: " << rhs._token_number
       << " _attendant_count: " << rhs._attendant_count
       << " _evaluation_amount: " << rhs._evaluation_amount
       << " _current_cases: " << rhs._current_cases;
    return os;
}

std::string DisplayEnumWork(WorkshopType type)
{
    if(type == WorkshopType::REPAIRS)
       return "REPAIRS";
    else if(type == WorkshopType::SERVICE)
       return "SERVICE";
    else
       return "BOTH";
}
