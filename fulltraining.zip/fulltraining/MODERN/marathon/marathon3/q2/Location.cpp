#include "Location.h"

Location::Location(std::string name, RefType workshop)
: _name(name),_workshop(workshop)
{
}
std::ostream &operator<<(std::ostream &os, const Location &rhs) {
    os << "_name: " << rhs._name
       << " _workshop: " << *(rhs._workshop.get());  
    return os;
}
