#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include "Workshop.h"
#include "WorkshopType.h"
#include "Location.h"
#include <vector>
#include <memory>
#include<mutex>

using LPointer = std::shared_ptr<Location>;
using LContainer = std::vector<LPointer>;

using WPointer = std::shared_ptr<Workshop>;
using WContainer = std::vector<WPointer>;

void CreateObject(LContainer& lData,WContainer& wData,std::variant<int,std::string> centre_id,int service_point_count,WorkshopType type,int attendant_count,float evaluation_amount,int current_cases,std::string name);

void InstanceHighestAttendant(LContainer& ldata);

void PrintBoolNInstances(LContainer& ldata);

#endif // FUNCTIONALITIES_H
