#ifndef WORKSHOP_H
#define WORKSHOP_H

#include<iostream>
#include "WorkshopType.h"
#include<variant>

class Workshop
{
private:
    std::variant<int,std::string> _centre_id;
    int _service_point_count;
    WorkshopType _type;
    int _token_number;
    int _attendant_count;
    float _evaluation_amount;
    int _current_cases;

public:
    Workshop() = delete ;  //Default Constructor Disable

    Workshop (const Workshop&) = delete; //Copy Constructor Disable

    Workshop& operator=( Workshop&) = delete; //Copy assigment operator Enable;

    Workshop(Workshop&&) = delete;  //Move Constructor Disable

    Workshop& operator=(Workshop&&) = delete;  //Move assigment operator Disable

    ~Workshop() = default;   // Distructor should be Enable

    Workshop( std::variant<int,std::string> centre_id,int service_point_count,WorkshopType type,int attendant_count,float evaluation_amount,int current_cases);

    std::variant<int,std::string> centreId() const { return _centre_id; }

    int servicePointCount() const { return _service_point_count; }

    WorkshopType type() const { return _type; }

    int tokenNumber() const { return _token_number; }

    int attendantCount() const { return _attendant_count; }

    float evaluationAmount() const { return _evaluation_amount; }

    int currentCases() const { return _current_cases; }

    friend std::ostream &operator<<(std::ostream &os, const Workshop &rhs);

};

std::string DisplayEnumWork(WorkshopType type);

#endif // WORKSHOP_H
