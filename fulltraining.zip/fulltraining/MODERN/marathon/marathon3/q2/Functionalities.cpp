#include "Functionalities.h"

std::mutex mt;
    

void CreateObject(LContainer &lData, WContainer &wData, std::variant<int, std::string> centre_id, int service_point_count, WorkshopType type, int attendant_count, float evaluation_amount, int current_cases, std::string name)
{
    WPointer w1 = std::make_shared<Workshop>(
        centre_id,
        service_point_count,
        type, 
        attendant_count,
        evaluation_amount,
        current_cases
        );

        mt.lock();

        wData.push_back(std::move(w1));

        LPointer l1 (
             std::make_shared<Location>(
            name,
            std::ref(wData[0])
          ) 
        );

        lData.push_back(std::move(l1));

        mt.unlock();
}

void InstanceHighestAttendant(LContainer &ldata)
{

    int highest = ldata.front()->workshop().get()->attendantCount();
    for(LPointer& p: ldata)
    {
        if(highest > p->workshop().get()->attendantCount())
        {
            highest=p->workshop().get()->attendantCount();
        }
    } 

    mt.lock();

    for(LPointer& p: ldata)
    {
        if(highest == p->workshop().get()->attendantCount())
        {
            for(LPointer& p: ldata)
            {
                std::cout<<*p<<" ";
            }
        }
    } 
    mt.unlock();

}



void PrintBoolNInstances(LContainer &ldata, int n)
{
    for(LPointer p:ldata)
    {
        if(p->workshop().get()->attendantCount() > n)
        {
            std::cout<<"True";
        }
        else
        std::cout<<"False";
    }
}
