#include<iostream>
#include "Workshop.h"
#include "WorkshopType.h"
#include "Location.h"
#include <vector>
#include <memory>
#include "Functionalities.h"
#include<thread>

using LPointer = std::shared_ptr<Location>;
using LContainer = std::vector<LPointer>;

using WPointer = std::shared_ptr<Workshop>;
using WContainer = std::vector<WPointer>;

int main()
{
    LContainer lData;
    WContainer wData;

    std::thread arr[4];

    arr[0] = std::thread ( 
    CreateObject,
    std::ref(lData),
    std::ref(wData),
    101,
    15,
    WorkshopType::SERVICE,
    6,
    2000.0f,
    3,
    "Mumbai"
    );

    arr[1] = std::thread ( 
    CreateObject,
    std::ref(lData),
    std::ref(wData),
    102,
    10,
    WorkshopType::SERVICE,
    5,
    1500.0f,
    2,
    "Pune"
    );

    arr[2] = std::thread ( 
    CreateObject,
    std::ref(lData),
    std::ref(wData),
    103,
    20,
    WorkshopType::SERVICE,
    7,
    1000.0f,
    2,
    "Pune"
    );

    arr[3] = std::thread ( 
    CreateObject,
    std::ref(lData),
    std::ref(wData),
    104,
    25,
    WorkshopType::SERVICE,
    8,
    3000.0f,
    2,
    "Punjab"
    );

    for(int i=0;i<4;i++)
    {
        arr[i].join();
    }

    std::thread t2( InstanceHighestAttendant,std::ref(lData));

    t2.join();

    // std::thread t3( PrintBoolNInstances,std::ref(lData),5);

    // t3.join();




}