#ifndef LOCATION_H
#define LOCATION_H

#include<iostream>
#include "Workshop.h"
#include "WorkshopType.h"
#include<memory>

using WorkPointer = std::shared_ptr<Workshop>;
using RefType = std::reference_wrapper<WorkPointer>;

class Location
{
private:
    std::string _name;
    RefType _workshop;
public:
    Location() = delete ;  //Default Constructor Disable

    Location (const Location&) = delete; //Copy Constructor Disable

    Location& operator=( Location&) = delete; //Copy assigment operator Enable;

    Location(Location&&) = delete;  //Move Constructor Disable

    Location& operator=(Location&&) = delete;  //Move assigment operator Disable

    ~Location() = default;   // Distructor should be Enable

    Location(std::string name,RefType workshop);

    std::string name() const { return _name; }

    RefType workshop() const { return _workshop; }

    friend std::ostream &operator<<(std::ostream &os, const Location &rhs);

};

#endif // LOCATION_H
