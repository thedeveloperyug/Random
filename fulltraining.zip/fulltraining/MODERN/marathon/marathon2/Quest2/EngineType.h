

#ifndef ENGINETYPE_H
#define ENGINETYPE_H

enum class EngineType
{
  ICE = 1,
  HYBRID = 2,
  ELECTRIC = 3
};

#endif // ENGINETYPE_H
