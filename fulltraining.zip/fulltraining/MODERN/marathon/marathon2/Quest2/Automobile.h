

#ifndef AUTOMOBILE_H
#define AUTOMOBILE_H

#include "AutomobileType.h"
#include <vector>
#include <functional>
#include <memory>
#include <ostream>
#include "Engine.h"

using Type_pressure_container = std::vector<float>;
using EnginePointer = std::shared_ptr<Engine>;
using EngineRefernce = std::reference_wrapper<EnginePointer>;
class Automobile
{
private:
    /* data */
    int _id;
    Type_pressure_container _tyrePressure;
    AutomobileType _type;
    EngineRefernce _engine;

public:
    Automobile() = default;                             // DEFAULT constructor is enabled
    Automobile(const Automobile &) = delete;            // COPY constructor is disabled
    Automobile(Automobile &&) = delete;                 // Move constructor is disabled
    Automobile &operator=(const Automobile &) = delete; // assignment overload is disabled
    Automobile &operator=(Automobile &&) = delete;      // move assignment is disabled
    ~Automobile() = default;                            // destructor is enabled

    // getter

    // parametrized constructor
    Automobile(int id, Type_pressure_container tyrePressure, AutomobileType type, EngineRefernce engine);

    Type_pressure_container tyrePressure() const { return _tyrePressure; }

    AutomobileType type() const { return _type; }

    EngineRefernce engine() const { return _engine; }

    int id() const { return _id; }

    friend std::ostream &operator<<(std::ostream &os, const Automobile &rhs);

};
std::string DisplayAutomobileType(AutomobileType _type);

#endif // AUTOMOBILE_H
