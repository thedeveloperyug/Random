#include "Functionality.h"
#include <vector>
#include <functional>
#include "Automobile.h"

std::vector<EnginePointer> EngineContainer;

void CreateObject(AutomobileContainer &data)
{
    EngineContainer.push_back(std::make_shared<Engine>(EngineType::ELECTRIC, 3000, 30.0f));
    EngineContainer.push_back(std::make_shared<Engine>(EngineType::HYBRID, 2000, 25.0f));
    EngineContainer.push_back(std::make_shared<Engine>(EngineType::ELECTRIC, 3000, 28.0f));

    data.push_back(std::make_shared<Automobile>(101, Type_pressure_container{10, 20, 30}, AutomobileType::COMMUTE, EngineContainer[0]));

    data.push_back(std::make_shared<Automobile>(102, Type_pressure_container{10, 20, 30}, AutomobileType::COMMUTE, EngineContainer[1]));

    data.push_back(std::make_shared<Automobile>(103, Type_pressure_container{5, 10, 45}, AutomobileType::SPECIAL_PURPOSE, EngineContainer[2]));
}

void Operation(AutomobileContainer &data, Fwr fn, int sec)
{
    fn(data, sec);
}