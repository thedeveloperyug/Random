#ifndef AUTOMOBILETYPE_H
#define AUTOMOBILETYPE_H

#include<iostream>

enum class AutomobileType{
  TRANSPORT=1,
  COMMUTE=2,
  SPECIAL_PURPOSE=3
};

#endif // AUTOMOBILETYPE_H
