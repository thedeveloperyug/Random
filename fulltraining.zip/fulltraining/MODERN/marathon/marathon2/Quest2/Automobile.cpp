#include "Automobile.h"

std::string DisplayAutomobileType(AutomobileType _type)
{
    if (_type == AutomobileType::COMMUTE)
        return "Commute";
    else if (_type == AutomobileType::SPECIAL_PURPOSE)
        return "Special Purpose";
    else
        return "Transport";
}

Automobile::Automobile(int id, Type_pressure_container tyrePressure, AutomobileType type, EngineRefernce engine)
    : _id(id), _tyrePressure(tyrePressure), _type(type), _engine(engine)
{
}

std::ostream &operator<<(std::ostream &os, const Automobile &rhs)
{
    os << "_id: " << rhs._id
       << " _tyrePressure: ";
    for (auto it : rhs.tyrePressure())
        os << it;

    os << " _type: " << DisplayAutomobileType(rhs._type);
    os << " _engine: " << *rhs._engine.get();
    return os;
}
