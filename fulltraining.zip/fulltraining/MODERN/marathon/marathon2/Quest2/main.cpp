#include <iostream>
#include "Functionality.h"
#include "Automobile.h"
#include <functional>
#include <memory>

using namespace std::placeholders;
using AutomobilePointer = std::shared_ptr<Automobile>;
using AutomobileContainer = std::vector<AutomobilePointer>;
// std::vector<EnginePointer> EngineContainer;

using Fwr = std::function<void(AutomobileContainer, int)>;

int main()
{
    // creating object
    AutomobileContainer AutoMobileData;
    CreateObject(AutoMobileData);

    auto l1 = [](AutomobileContainer AutoMobileData, int id)
    {
        std::cout << "The Type whose id matches is:" << std::endl;
        for (auto it : AutoMobileData)
        {
            if (id == it->id())
            {
                std::cout << DisplayAutomobileType(it->type()) << std::endl;
                break;
            }
        }
    };

    auto l2 = [](AutomobileContainer AutoMobileData, int power_value)
    {
        std::cout << "The power value instances is:" << std::endl;
        for (auto it : AutoMobileData)
        {
            if (it->engine().get()->horsepower() > power_value)
            {
                std::cout << *it << std::endl;
            }
        }
    };

    auto l3 = [](AutomobileContainer AutoMobileData, int capacity_value)
    {
        std::cout << "The instances of Automotive value is:" << std::endl;
        for (auto it : AutoMobileData)
        {
            if (it->engine().get()->fuelcapacity() > capacity_value)
            {
                std::cout << *it << std::endl;
            }
        }
    };

    // using lamda function wrapper
    // Operation(AutoMobileData, l1, 101);  // functionality 1 for type by id
    // Operation(AutoMobileData, l2, 2000); // functionality 2 for instances whose horse power is above threshold
    // Operation(AutoMobileData, l3, 20.0f); // functionality 3 instances whose fuel capacity is above
std::cout<<"-----------------------------usuing bind-------------------------------"<<std::endl;
    // binding//
    auto b1 = std::bind(l1, _1, 100);
    auto b2 = std::bind(l2, _1, 400);

    b1(AutoMobileData);
    b2(AutoMobileData);

    return 0;
}