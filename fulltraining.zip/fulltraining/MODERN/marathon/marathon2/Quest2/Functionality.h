#ifndef FUNCTIONALITY_H
#define FUNCTIONALITY_H

#include "Automobile.h"
#include <memory>

using EnginePointer = std::shared_ptr<Engine>;
using AutomobilePointer = std::shared_ptr<Automobile>;
using AutomobileContainer = std::vector<AutomobilePointer>;

using Fwr = std::function<void(AutomobileContainer, int)>;

// function to create 5 objects of Automobile

void CreateObject(AutomobileContainer &data);

// higher order function
void Operation(AutomobileContainer &data, Fwr fn,int sec);

#endif // FUNCTIONALITY_H
