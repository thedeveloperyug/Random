#ifndef ENGINE_H
#define ENGINE_H

#include<iostream>
#include"EngineType.h"
class Engine
{
private:
    /* data */
    EngineType _type;
    int _horsepower;
    float _fuelcapacity;
    
public:
    Engine() = default; // DEFAULT constructor is enabled
    Engine(const Engine &) = delete;  // COPY constructor is disabled
    Engine(Engine &&) = delete; // Move constructor is disabled
    Engine &operator=(const Engine &) = delete; //assignment overload is disabled
    Engine &operator=(Engine &&) = delete; //move assignment is disabled
    ~Engine() = default; //destructor is enabled

    EngineType type() const { return _type; }

    int horsepower() const { return _horsepower; }

    float fuelcapacity() const { return _fuelcapacity; }

    //parametrized constructor
    Engine(EngineType type,int horsepower,float fuelcapacity);

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);


    
};

std::string DisplayEngineType(EngineType _type);


#endif // ENGINE_H
