#include "Engine.h"

std::string DisplayEngineType(EngineType _type)
{
    if (_type == EngineType::ELECTRIC)
        return "Electric";
    else if (_type == EngineType::HYBRID)
        return "Hybrid";
    else
        return "ice";
}

Engine::Engine(EngineType type, int horsepower, float fuelcapacity)
    : _type(type), _horsepower(horsepower), _fuelcapacity(fuelcapacity)
{
    if (fuelcapacity < 20 || fuelcapacity > 50)
        std::runtime_error("Fuel capicity should be in the range of 20-50");
}

std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "_type: " << DisplayEngineType(rhs._type)<<std::endl;
    os<< " _horsepower: " << rhs._horsepower<<std::endl;
    os<< " _fuelcapacity: " << rhs._fuelcapacity<<std::endl;
    return os;
}

