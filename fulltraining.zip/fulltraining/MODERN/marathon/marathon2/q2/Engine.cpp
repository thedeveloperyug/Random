#include "Engine.h"

Engine::Engine(EngineType type, int horsepower, float fuel_capacity)
: _type(type), _horsepower(horsepower),_fuel_capacity(fuel_capacity)
{
    if(_fuel_capacity < 20  || _fuel_capacity > 50)
    {
        throw std::runtime_error("Fuel Capacity is Invalid");
    }
}
std::ostream &operator<<(std::ostream &os, const Engine &rhs) {
    os << "_type: " <<DisplayEngineType(rhs._type)
       << " _horsepower: " << rhs._horsepower
       << " _fuel_capacity: " << rhs._fuel_capacity;
    return os;
}

std::string DisplayEngineType(EngineType type)
{
    if(type == EngineType::ELECTRIC)
       return "ELECTRIC";
    else if(type == EngineType::HYBRID)
       return "HYBRID";
    else
       return "ICE";
}
