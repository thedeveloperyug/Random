#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include<iostream>
#include "Automobile.h"
#include "Engine.h"
#include "AutomobileType.h"
#include "EngineType.h"
#include<memory>
#include<vector>
#include<functional>

using AutomobileContainer = std::vector<std::shared_ptr<Automobile>>;
using EngineContainer = std::vector<std::shared_ptr<Engine>>;
using Tyre_Presure = std::vector<float>;


/*  Function for Creating the Object  */

void CreateObject(AutomobileContainer& autodata,EngineContainer& engdata);


/*  A Higher Order Function that takes Automobile Container object and a function wrapper */


void HigherOrder1(AutomobileContainer& autodata,std::string id, std::function<void(AutomobileContainer&,std::string)> fn);

void HigherOrder2(AutomobileContainer& autodata,int P,std::function<void (AutomobileContainer&,int)> fn);

void HigherOrderfuel(AutomobileContainer& autodata,int P,std::function<void (AutomobileContainer&,int)> fn);





#endif // FUNCTIONALITIES_H
