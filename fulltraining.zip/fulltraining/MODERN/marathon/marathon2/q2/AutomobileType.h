#ifndef AUTOMOBILETYPE_H
#define AUTOMOBILETYPE_H

enum class AutomobileType
{
    TRANSPOST,
    COMMUTE,
    SPECIAL_PURPOSE
};

#endif // AUTOMOBILETYPE_H
