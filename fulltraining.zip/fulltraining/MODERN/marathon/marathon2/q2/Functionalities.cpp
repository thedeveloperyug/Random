#include "Functionalities.h"

void CreateObject(AutomobileContainer &autodata, EngineContainer &engdata)
{
    


    engdata.push_back(std::make_shared<Engine>(EngineType::ELECTRIC,300,30.0f));
    engdata.push_back(std::make_shared<Engine>(EngineType::ICE,500,40.0f));
    engdata.push_back(std::make_shared<Engine>(EngineType::ELECTRIC,400,35.0f));
    engdata.push_back(std::make_shared<Engine>(EngineType::HYBRID,600,45.0f));
    engdata.push_back(std::make_shared<Engine>(EngineType::HYBRID,800,50.0f));


    autodata.push_back(std::make_shared<Automobile>("ID101",std::vector<float>{2.0f,3.5f,4.0f,5.0f,1.0f},AutomobileType::COMMUTE,std::ref(engdata[0])));
    autodata.push_back(std::make_shared<Automobile>("ID201",std::vector<float>{2.0f,3.5f,4.0f,5.0f,1.0f},AutomobileType::COMMUTE,std::ref(engdata[1])));
    autodata.push_back(std::make_shared<Automobile>("ID301",std::vector<float>{2.0f,3.5f,4.0f,5.0f,1.0f},AutomobileType::COMMUTE,std::ref(engdata[2])));
    autodata.push_back(std::make_shared<Automobile>("ID401",std::vector<float>{2.0f,3.5f,4.0f,5.0f,1.0f},AutomobileType::COMMUTE,std::ref(engdata[3])));
    autodata.push_back(std::make_shared<Automobile>("ID501",std::vector<float>{2.0f,3.5f,4.0f,5.0f,1.0f},AutomobileType::COMMUTE,std::ref(engdata[4])));
}


void HigherOrder1(AutomobileContainer &autodata, std::string id, std::function<void(AutomobileContainer& , std::string)> fn)
{
     fn(autodata, id);
}

void HigherOrder2(AutomobileContainer &autodata, int P, std::function<void(AutomobileContainer &, int)> fn)
{
    fn(autodata,P);
}

void HigherOrderfuel(AutomobileContainer &autodata, int P, std::function<void(AutomobileContainer &, int)> fn)
{
    fn(autodata,P);
}
