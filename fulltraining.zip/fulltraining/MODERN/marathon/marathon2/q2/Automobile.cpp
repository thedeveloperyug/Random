#include "Automobile.h"

Automobile::Automobile(std::string id, std::vector<float> tyre_pressure_reading, AutomobileType type, RefType engine)
: _id(id),_tyre_pressure_reading(tyre_pressure_reading),_type(type),_engine(engine)
{
    
}

std::ostream &operator<<(std::ostream &os, const Automobile &rhs) {
    os << "_id: " << rhs._id
       << " _type: " <<DisplayAutomobileType(rhs._type)
          << " _engine: " << *(rhs._engine.get());
       for(auto i : rhs.tyrePressureReading())
      os << " _tyre_pressure_reading: " << i;
       
    return os;
}


std::string DisplayAutomobileType(AutomobileType type)
{
    if(type == AutomobileType::COMMUTE)
       return "COMMUTE";
    else if(type == AutomobileType::SPECIAL_PURPOSE)
       return "SPECIAL_PURPOSE";
    else
       return "TRANSPORT";
}

