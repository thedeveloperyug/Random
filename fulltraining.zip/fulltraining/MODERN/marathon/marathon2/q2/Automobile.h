#ifndef AUTOMOBILE_H
#define AUTOMOBILE_H

#include<iostream>
#include "AutomobileType.h"
#include "Engine.h"
#include<vector>
#include<memory>

using Pointer = std::shared_ptr<Engine>;
using RefType = std::reference_wrapper<Pointer>;


class Automobile
{
private:
    std::string _id;
    std::vector<float> _tyre_pressure_reading;
    AutomobileType _type;
    RefType _engine;
public:
    Automobile() = delete;   //Default Constructor

    Automobile(const Automobile&) = delete;  //Copy Constructor

    Automobile& operator=(const Automobile&) = delete;   //Copy assignment

    Automobile(Automobile&&) = delete;    //Move Constructor

    Automobile& operator=(Automobile&&) = delete;   //Move assigment

    ~Automobile() = default;   //Default Distructor

    Automobile(std::string id,std::vector<float> tyre_pressure_reading,AutomobileType type,RefType engine);

    std::string id() const { return _id; }

    std::vector<float> tyrePressureReading() const { return _tyre_pressure_reading; }

    AutomobileType type() const { return _type; }

    RefType engine() const { return _engine; }

    friend std::ostream &operator<<(std::ostream &os, const Automobile &rhs);

    
};

/* Function for Displaying the Automobile Enum Type */

std::string DisplayAutomobileType(AutomobileType type);





#endif // AUTOMOBILE_H
