#ifndef ENGINE_H
#define ENGINE_H

#include<iostream>
#include "EngineType.h"

class Engine
{
private:
    EngineType _type;
    int _horsepower;
    float _fuel_capacity; 

public:
    Engine() = delete;   //Default Constructor

    Engine(const Engine&) = delete;  //Copy Constructor

    Engine& operator=(const Engine&) = delete;   //Copy assignment

    Engine(Engine&&) = delete;    //Move Constructor

    Engine& operator=(Engine&&) = delete;   //Move assigment

    ~Engine() = default;   //Default Distructor

    Engine(EngineType type,int horsepower,float fuel_capacity);

    EngineType type() const { return _type; }

    int horsepower() const { return _horsepower; }

    float fuelCapacity() const { return _fuel_capacity; }

    friend std::ostream &operator<<(std::ostream &os, const Engine &rhs);

    
};

//function for Displaying the Enum of Engine

std::string DisplayEngineType(EngineType type); 

#endif // ENGINE_H
