#include<iostream>
#include "Functionalities.h"
#include "Automobile.h"
#include<functional>

using namespace std::placeholders;


using AutomobileContainer = std::vector<std::shared_ptr<Automobile>>;
using EngineContainer = std::vector<std::shared_ptr<Engine>>;
using Tyre_Presure = std::vector<float>;



int main()
{
    AutomobileContainer autodata;
    EngineContainer engdata;
    Tyre_Presure tp;

    CreateObject(autodata,engdata);

    auto f1 = ([](AutomobileContainer& autodata,std::string id){
        std::cout<<" "<<std::endl;
        try
        {
            for(auto &i : autodata){
            if(id == i->id())
            {
               AutomobileType type = i->type();
               std::cout<<"Type: "<<DisplayAutomobileType(type)<<std::endl;
            }
            
        }
        }
        catch(const std::exception& e)
        {
            std::cerr << e.what() << '\n';
        }
        
        
    });

    auto f2  = ([](AutomobileContainer& autodata,int P){

        try
        {
            for(auto &i : autodata){
            if(P == i->engine().get()->horsepower())
            {
                std::cout<<*i<<std::endl;
            }
          }    
        }
        catch(const std::exception& e)
        {
            std::cerr << e.what() << '\n';
        }
        
        
    });

    // HigherOrderfuel(autodata,40);

    auto f3 = (40,[](AutomobileContainer& autodata,int P){

        try
        {
            for(auto &i : autodata){
            if(P == i->engine().get()->fuelCapacity())
            {
                std::cout<<*i<<std::endl;
            }
        }   
        }
        catch(const std::exception& e)
        {
            std::cerr << e.what() << '\n';
        }
        
         
    });



    

   auto partial_function_f1 = std::bind(f1,_1,"ID101");   

   partial_function_f1 (autodata);  

   auto partial_function_f2 = std::bind(f2,_1,600);   

   partial_function_f2(autodata);





}