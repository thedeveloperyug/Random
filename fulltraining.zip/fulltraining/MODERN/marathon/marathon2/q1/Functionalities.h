#ifndef FUNCTIONALITIES_H
#define FUNCTIONALITIES_H

#include "Product.h"
#include "ProductType.h"
#include<memory>
#include<vector>
#include<functional>


using Pointer = std::shared_ptr<Product>;
using Container = std::vector<Pointer>;

using FunWrap = std::function<void (Pointer&)>;
using Fcontainer = std::vector<FunWrap>;

/*
   Function for Create 5 Object
*/

void CreateObject(Container& data);

/*
   Function for showing the results by passing the container data and and lambda function as argument..
*/

void ShowResults(Container& data,FunWrap& fn);

#endif // FUNCTIONALITIES_H
