#ifndef PRODUCTTYPE_H
#define PRODUCTTYPE_H

enum class ProductType
{
    FMCG,
    FURNITURE,
    ELECTRONIC
};

#endif // PRODUCTTYPE_H
