#include "Product.h"

std::ostream &operator<<(std::ostream &os, const Product &rhs) {
    os << "_id: " << rhs._id
       << " _name: " << rhs._name
       << " _rating: " << rhs._rating
       << " _price: " << rhs._price
       << " _type: " << DisplayEnum(rhs._type);
    return os;
}

std::string DisplayEnum(ProductType type)
{
    if(type == ProductType::ELECTRONIC)
       return "ELECTRONIC";
    else if(type == ProductType::FMCG)
       return "FMCG";
    else
       return "FURNITURE";
}

Product::Product(std::string id, std::string name, float rating, float price, ProductType type)
: _id(id),_name(name),_rating(rating),_price(price),_type(type)
{
    if(_rating < 1  || _rating >5)
    {
        throw std::runtime_error("Rating Mismatch");
    }
}


