#ifndef PRODUCT_H
#define PRODUCT_H

#include<iostream>
#include "ProductType.h"

class Product
{
private:
    std::string _id;
    std::string _name;
    float _rating;
    float _price;
    ProductType _type;
public:
    Product() = delete;   //Default Constructor

    Product(const Product&) = delete;    //Copy Constructor Disable

    Product& operator=(const Product&) = delete;    //Copy assigment Disable

    Product(Product&&) = delete;    // Move Constructor Disable

    Product& operator=(Product&&) = delete;   //Move assigment

    ~Product() = default;   //Distructor default

//Parametrized Constructor
    Product(std::string id,std::string name,float rating,float price,ProductType type);

    std::string id() const { return _id; }

    std::string name() const { return _name; }

    float rating() const { return _rating; }

    float price() const { return _price; }

    ProductType type() const { return _type; }

//os Operator Overload

    friend std::ostream &operator<<(std::ostream &os, const Product &rhs);

};

/*
   Function for Display the Enum Part
*/

std::string DisplayEnum(ProductType type);

#endif // PRODUCT_H
