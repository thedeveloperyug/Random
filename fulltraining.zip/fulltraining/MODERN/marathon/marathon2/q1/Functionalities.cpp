#include "Functionalities.h"

void CreateObject(Container &data)
{
    data.push_back(std::make_shared<Product>("P101","Frizee",1.0f,10000.0f,ProductType::ELECTRONIC));
    data.push_back(std::make_shared<Product>("P102","Washingmachine",1.0f,15000.0f,ProductType::ELECTRONIC));
    data.push_back(std::make_shared<Product>("P103","Table",2.0f,10000.0f,ProductType::FURNITURE));
    data.push_back(std::make_shared<Product>("P104","Shirt",3.0f,5000.0f,ProductType::FMCG));
    data.push_back(std::make_shared<Product>("P105","Chair",4.0f,10000.0f,ProductType::FURNITURE));
}
/*Object is Created*/

void ShowResults(Container &data, FunWrap& fn)
{
    if(data.empty())                       //If Data will Empty it will throw error.
    {
        throw std::runtime_error("Data is Empty");
    }
    for(auto& i : data)
    {
        fn(i);    //Perform Function on Every Data
    }
}
//Result View Succesfully.
