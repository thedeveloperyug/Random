#include "Functionalities.h"
#include "Product.h"
#include "ProductType.h"
#include<functional>
#include<iostream>


using Pointer = std::shared_ptr<Product>;
using Container = std::vector<Pointer>;

using FunWrap = std::function<void (Pointer&)>;
using Fcontainer = std::vector<FunWrap>;


int main()
{
    Container data;

//Calling the Create Object function by reference

    CreateObject(data);

//Lambda Function for finding the Tax

    auto f1 = [](Pointer instance){
        std::cout<<"Tax: "<<instance->price() * 0.01f<<" ";
        
    };

    
//Lamda for showing the price or rating
    auto f2 = [](Pointer instance){
        if(instance->type() == ProductType::ELECTRONIC)
        std::cout<<"\nProduct Price: "<<instance->price() * 0.02f<<std::endl<<"Rating time: "<<3 * instance->price();
    };

//Lamda for boolian expression

    auto f3 = [](Pointer instance){
        if(instance->price() > 20000.0f)
        std::cout<<"True"<<" ";
        else
        std::cout<<"False"<<" ";
        if(instance->rating() >= 3)
        std::cout<<"True";
        else
        std::cout<<"False"<<" ";
        if(instance->price() <= 1000 * instance->rating())
        std::cout<<"True"<<" ";
        else
        std::cout<<"False"<<" ";
    };

//Pushing the function data into function Container
    Fcontainer fundata;
    fundata.push_back(f1);
    fundata.push_back(f2);
    fundata.push_back(f3);

//Calling the function one-one by loop
    for(auto f : fundata)
    {
        try
        {
            ShowResults(data,f);
        }
        catch(const std::exception& e)
        {
            std::cerr << e.what() << '\n';
        }
        
        
    }

}