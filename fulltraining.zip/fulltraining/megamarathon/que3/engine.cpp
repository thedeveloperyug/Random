#include "engine.h"
#include<iostream>

Engine::Engine(int cId,std::string cBrand,Cartype Cartype, float cPrice, Enginetype Etype, int eHorse, int eTorque)
: Car()
{

}

void Engine::Accept()
{
}

void Engine::display()
{
}
