#ifndef ENGENUM_H
#define ENGENUM_H

#include<iostream>

enum Enginetype
{
    ITC,
    HYBRID,
    NA
};

#endif // ENGENUM_H
