#ifndef ENUM_H
#define ENUM_H

#include<iostream>

enum Cartype
{
    SEDAN,
    SUV,
    SPORTS,
    HATCHBACK,
    NA
};

#endif // ENUM_H
