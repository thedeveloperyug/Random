#ifndef ENGINE_H
#define ENGINE_H

#include<iostream>
#include "car.h"
#include "engenum.h"


class Engine : public Car
{
    std::string engineNumber;
    enum Enginetype engineType;
    int engineHorsepower;
    int engineTorque;
    public:
    Engine(std::string,Enginetype,int,int);
    void Accept();
    void display();
};

#endif // ENGINE_H
