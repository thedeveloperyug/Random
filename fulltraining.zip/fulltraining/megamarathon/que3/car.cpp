#include "car.h"

Car::Car()
{
    carId=101;
    carBrand="Honda";
    Cartype::SUV;
    carPrice=1500000.00;
       
}