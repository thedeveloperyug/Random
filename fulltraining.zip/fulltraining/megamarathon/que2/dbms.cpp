#include "dbms.h"
#include<iostream>
#include<cstring>


class UnderflowException : public std::exception
{
    char message[50];

    public:
    UnderflowException() { }
    UnderflowException(const char *p)
    {
        strcpy(message,p);
    }
    char * getMessage()
    {
        return message;
    }
};
class OverflowException : public std::exception
{
    char  message[50];

    public:
    OverflowException() { }
    OverflowException(const char *ptr)
    {
        strcpy(message,ptr);
    }
    char * getmessage()
    {
        return message;
    }
};

MyQueue::MyQueue(int size)  //Parameterized Constructor
{
    this->size=size;
    rear=-1;
    front=0;
    pointer=new int[size];
}
bool MyQueue::isFull()   //Checking Queue is Full or not
{
    return rear==size-1;

}
bool MyQueue::isEmpty()  // Checking Queue is Empty or not
{
    return rear==-1;
}


void MyQueue::Push(int element)  //Push the elements into the Queue
{
    if(!isFull())
    {
        pointer[rear++] = element;
        return ;
    }
    else 
    throw OverflowException("Queue is Full");
}

int MyQueue::pop()  //Pop into the Queue.
{
    if(!isEmpty())
    {
        return pointer[front++];
    }
    else
       throw "Queue is Empty";
}

void MyQueue::display()  //Displaying the elements..
{
    std::cout<<"Elements are: ";
    for(int i=front;i<rear;++i)
    {
        std::cout<<pointer[i]<<" ";
        
    }
    
}

MyQueue::~MyQueue()  //Destructor Called..
{
   delete[]pointer;
}
