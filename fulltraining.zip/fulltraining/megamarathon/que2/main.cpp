#include<iostream>
#include "dbms.h"

void createObject()
{

    MyQueue q1(3);
    int num,ele=0;
    
    while(1)
    {
        std::cout<<std::endl;
        std::cout<<" 1.push\n";
        std::cout<<" 2.pop\n";
        std::cout<<" 3.Display\n";
        std::cout<<" 4.Exit\n";
        int choice;
        std::cout<<"Enter your choice: ";
        std::cin>>choice;
        switch(choice)
        {
            case 1:
                std::cout<<"Enter the value your want to Push"<<std::endl;
                std::cin>>num;
                 try
                 {
                    q1.Push(num);
                    std::cout<<"\nValue pushed into the Queue"<<std::endl;
                 }
                 catch(const std::exception& e)
                 {
                    std::cerr << e.what() << '\n';
                 }
                 break;
            case 2:
                try
                {
                    ele=q1.pop();
                    std::cout<<"\nValue Poped from the Queue: "<<ele<<std::endl;
                }
                catch(const std::exception& e)
                {
                    std::cerr << e.what() << '\n';
                }
                break;
            case 3:
                   q1.display();
                   break;
            case 4:
                exit(1);
                break;
            default:
                std::cout<<"Invalid Choice!"<<std::endl;
                break;   
                 
              
        }
    }
    
}
int main()
{
   createObject();
}