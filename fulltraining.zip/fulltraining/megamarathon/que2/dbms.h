#ifndef DBMS_H
#define DBMS_H

#include <iostream>

class MyQueue
{
    int size;
    int front;
    int rear;
    int *pointer;

public:
    MyQueue();
    MyQueue(int);
    void Push(int);
    int pop();
    void display();
    ~MyQueue();
    bool isFull();
    bool isEmpty();
};

#endif // DBMS_H
