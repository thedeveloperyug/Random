#include "job.h"
#include<iostream>

void addJobPosting(JobPosting obj[],int size)
{
    int i=size-1;
    std::string jobPost;
    std::cout<<"enter the job post: ";
    std::cin>>jobPost;
        obj[i].accept();
}
void searchByCompany(JobPosting obj[],int size)
{
    std::string searchName;
    std::cout<<"\nEnter the name of Company: ";
    std::cin>>searchName;
    for(int i=0;i<size;i++)
    {
        if(obj[i].getCompany()==searchName)
        {
            std::cout<<"\nCompany Name found!"<<std::endl;
            obj[i].display();
            return ;
        }
        
    }
    std::cout<<"Company name not found!"<<std::endl;
        return ;
}
void searchByLocation(JobPosting obj[],int size)
{
    std::string searchLocation;
    std::cout<<"Enter the Location: ";
    std::cin>>searchLocation;
    for(int i=0;i<size;i++)
    {
        if(obj[i].getLocation()==searchLocation)
        {
            std::cout<<"\nLocation Found!"<<std::endl;
            obj[i].display();
            return ;
        }
    }
    std::cout<<"Location not found!"<<std::endl;
        return ;
    
}

void createObject()
{
    int N;
    std::cout<<"Enter the size of Job Posting: ";
    std::cin>>N;

    JobPosting job[N];
    int num=0;
    while(1)
    {
        std::cout<<std::endl;
        std::cout<<" 1.Apply Job\n";
        std::cout<<" 2.Display\n";
        std::cout<<" 3.Search By Company\n";
        std::cout<<" 4.Search by Location\n";
        std::cout<<" 5.Add Job Posting\n";
        std::cout<<" 6.Exit"<<std::endl;
        int choice;
        std::cout<<"Enter the choice: ";
        std::cin>>choice;
        switch(choice)
        {
            case 1:
               if(num<N)
               {
                job[num].accept();
                num++;
               }
               break;
            case 2:
               std::cout<<"****The Details are****"<<std::endl;
               for(int i=0;i<N;i++)
               job[i].display();
               break;
            case 3:
               searchByCompany(job,N);
               break;
            case 4:
               searchByLocation(job,N);
               break;
            case 5:
               
               addJobPosting(job,N);
               break;
            case 6:
               exit(1);
               break;
            default:
              std::cout<<"Invalid Input!"<<std::endl;
              break;;
               
        }

    }
    

}

int main()
{
    createObject();


}