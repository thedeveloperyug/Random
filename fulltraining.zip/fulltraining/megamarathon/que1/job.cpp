#include "job.h"
#include<iostream>

JobPosting::JobPosting()  
{
    
}

JobPosting::JobPosting(std::string title2, std::string company2, std::string location2, std::string Description2)
{
    
}

void JobPosting::display()
{
    std::cout<<std::endl;
    std::cout<<"Title= "<<title<<std::endl;
    std::cout<<"Company= "<<company<<std::endl;
    std::cout<<"Location= "<<location<<std::endl;
    std::cout<<"Description= "<<Description<<std::endl;

}

void JobPosting::accept()
{
    std::cout<<"\n Enter the Title: ";
    std::cin>>title;
    std::cout<<"\n Enter the Company name: ";
    std::cin>>company;
    std::cout<<"\n Enter the Location: ";
    std::cin>>location;
    std::cout<<"Enter Description: ";
    std::cin>>Description;
}

JobPosting::~JobPosting()
{
    std::cout<<"\nDestructor called"<<std::endl;
}
