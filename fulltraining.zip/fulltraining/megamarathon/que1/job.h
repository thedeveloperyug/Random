#ifndef JOB_H
#define JOB_H

#include<iostream>

class JobPosting
{
    std::string title;
    std::string company;
    std::string location;
    std::string Description;

    public:
    JobPosting();  //Default Constructor
    JobPosting(std::string,std::string,std::string,std::string);  //Parameterized Constructor.

    //Getter Setter functions.

    std::string getTitle() const { return title; }
    void setTitle(const std::string &title_) { title = title_; }

    std::string getCompany() const { return company; }
    void setCompany(const std::string &company_) { company = company_; }

    std::string getLocation() const { return location; }
    void setLocation(const std::string &location_) { location = location_; }

    std::string description() const { return Description; }
    void setDescription(const std::string &description) { Description = description; }

    void display();
    void accept();
    ~JobPosting();  //Destructor.
    
};
#endif // JOB_H
