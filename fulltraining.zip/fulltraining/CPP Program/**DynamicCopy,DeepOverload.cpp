#include<iostream>
using namespace std;

class calculator
{
    int *arr;
    int size;
    int *p;
    char *cp1;
    public:
    calculator()
    {
        size=3;
        arr=new int[size];
        p=new int[100];
        
    }
    //destructor cannot overload...
    //destructor is called implicity..

    ~calculator()  //destructor is called when object goes out of scope..
    {
        cout<<"Destructor called"<<endl;
        delete[]arr;  //avoid memmory leakage
        // delete[]p;

    }
    calculator(int s)
    {
        size=s;
        arr=new int[size];
    }
    void accept()
    {
        cout<<"\nEnter element "<<endl;
        for(int i=0;i<size;i++)
        cin>>arr[i];
    }
    void display()
    {
        for(int i=0;i<size;i++)
        {
            cout<<arr[i]<<" ";
        }
        cout<<endl;
    }

           /*   ****** Operator overloading..******** */

 Complex::operator+(Complex b4)
{
    this->real=real+b4.real;
    this->imag=imag+b4.imag;

    return *this;

}
void friend operator<<(std::ostream& op,Car &obj)
{
    std::cout << obj._name <<" " << obj._model_no << "\t" << obj._price << endl ;

}
Car* BookVehicle::operator->() //->operator overload//
{
    return ptr;
}


    // ***Copy Constructor*****It performs deep copy.., we have to never copy the pointers we have to copy the data..
    calculator(calculator & c3)  //copy constructor to avoid dangling constructor.
    {
        size=c3.size;
        arr = new int [size] ;
        for(int i=0;i<size;i++)
        {
            arr[i]=c3.arr[i];
        }
    }
    float calAvg()
    {
        float sum=0;
        for(int i=0;i<size;i++)
        {
            sum+=arr[i];
        }
        return sum/size;
    }
    bool operator==(calculator c3)
    {
        if (this->calAvg()==c3.calAvg())
        return true;
        else
        false;
    }
    bool operator!=(calculator c3)
    {
        if (this->calAvg()==c3.calAvg())
        return true;
        else
        false;
    }
    Complex /*Complex*/::operator+(Complex b4)
{
    this->real=real+b4.real;
    this->imag=imag+b4.imag;

    return *this;

}
};
void print(calculator c2)
{
    c2.display();
}
int main()
{
    calculator c1,c2;  /*a,b,c,d,e,f,c2,c3;  -- it will call destructor for all object.*/ 

    

    c1.accept();
    print(c1);

    // calculator c2(c1);
    // c1.display();

    if(c1==c2)
        cout<<" average Equal"<<endl;
    else
        cout<<" average not Equal"<<endl;

    if(c1!=c2)
    {
        cout<<"\nAgv Not equal\n"<<endl;
    }
    else
    {
        cout<<" average  Equal"<<endl;
    }
    

    // c1.operator!=(c2);



    /* Whenever class contains pointer as a attributes/data member
         - implement destructor to avoid memory leakage
         -implement copy constructor to avoid dangling pointer
    
    suppose we create object of a class in heap memmory which contains pointer as a attribute/data member
    eg:
        Student * s=new Student;

        // we have write delete s;

    */

    // calculator *c=new calculator;
    // delete c; // request to call the destructor..
    return 0;
}
