#include<iostream>
using namespace std;

void fib(int num)
{
    static int n1=0,n2=1,r;
    if(num > 0){
    r=n1+n2;
    n1=n2;
    n2=r;
    cout<<r<<" ";
    fib(num-1);
    }

}

int main()
{
    cout<<0<<" "<<1<<" ";
    fib(8-2);

    return 0;
}

// int main()
// {
//     int n1=0,n2=1,N=7,r;
//     cout<<n1<<" "<<n2<<" ";
//     for(int i=2;i<=N;i++)
//     {
//         r=n1+n2;
//         n1=n2;
//         n2=r;
//         cout<<r<<" ";
//     }
//     return 0;
    
// }