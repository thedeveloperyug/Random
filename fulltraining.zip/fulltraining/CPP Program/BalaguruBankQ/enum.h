#ifndef ENUM_H
#define ENUM_H

#include<iostream>


enum Account
{
    SAVING,
    CURRENT,
    NA
};

#endif // ENUM_H
