#include<iostream>
#include "header.h"

Bank::Bank()
{
    std::cout<<"The values are initialized Sucessfully:"<<std::endl;
    NameofDepositer="Shyam";
    ACnumber=12345678;
    Type_of_Acc="Saving Account";
    BalanceAmount=2000.25;
}
bool Bank::deposit(double amount)
{
    BalanceAmount +=amount;
    if(BalanceAmount)
    return true;
    else
    return false;
}
bool Bank::withdrawal(double amount)
{

    if(BalanceAmount >= 100)
    {
        if((BalanceAmount - amount) >= 100 )
        {
          BalanceAmount -= amount;
          return true;
        }
        else
        return false;
    }
    else
    return false;

}
void Bank::display()
{
    std::cout<<"\nThe Details are:- "<<std::endl;
    std::cout<<"Depositer Name= "<<NameofDepositer<<std::endl;
    std::cout<<"Account Number= "<<ACnumber<<std::endl;
    std::cout<<"Type of Account= "<<Type_of_Acc<<std::endl;
    std::cout<<"Updated Balance= "<<BalanceAmount<<std::endl;
}