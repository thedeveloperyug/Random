#include<iostream>
#include "header.h"

int main()
{
    Bank B;
    if(B.deposit(1000))
    std::cout<<"Deposited sucessfull!"<<std::endl;
    else
    std::cout<<"Getting Error!"<<std::endl;
    if(B.withdrawal(500))
    std::cout<<"Withdrawal Succesfull!"<<std::endl;
    else
    std::cout<<"Error in Withdrawl"<<std::endl;

    B.display();

    return 0;
    
}