#ifndef HEADER_H
#define HEADER_H

#include <iostream>
#include "enum.h"

class Bank
{
    std::string NameofDepositer;
    int ACnumber;
    std::string Type_of_Acc;
    double BalanceAmount;
    enum Account Type;

public:
    Bank();
    bool deposit(double amount);
    bool withdrawal(double amount);
    void display();
};

#endif // HEADER_H
