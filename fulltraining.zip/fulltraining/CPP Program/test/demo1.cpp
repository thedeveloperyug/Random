#include<iostream>
using namespace std;

int x=10;
int main()
{
    int c=0;

    cout<<c;

    return 0;
    
}