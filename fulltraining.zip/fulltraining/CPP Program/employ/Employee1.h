#ifndef EMPLOYEE1_H
#define EMPLOYEE1_H

//what it check ? 

#include <iostream>

class Employee1
{
    int empid;
    std::string ename;
    double salary;
    static int i;

public:
    Employee1();
    Employee1(int eid, std::string enm, double salary);
    void Accept();
    void show();
    ~Employee1();
};

#endif // EMPLOYEE1_H
