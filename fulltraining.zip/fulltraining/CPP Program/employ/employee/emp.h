#ifndef EMP_H
#define EMP_H

#include<iostream>
class Employee{
    int empId;
    std::string empName;
    double empSalary;
    static int count;
    int *increment;
    int cnt;
    public:
        Employee();
        Employee(int eid,std::string ename,double esal);
        ~Employee();
        void display();
        void accept();
};

#endif // EMP_H
