#include "emp.h"
#include<iostream>
int Employee::count=0;
Employee::Employee()
{
    empId=0;
    empName="NA";
    empSalary=0;
    increment=new int[12];
    count++;
    cnt=count;
}

Employee::Employee(int eid, std::string ename, double esal)
{
    empId=eid;
    empName=ename;
    empSalary=esal;
    increment=new int[12];
    count++;
    cnt=count;
}

Employee::~Employee()
{
    delete []increment;
}

void Employee::display()
{
    std::cout<<"*****************************************"<<std::endl;
    std::cout<<"Employee"<<count<<" :"<<std::endl;
    std::cout<<"Employee"<<cnt<<" :"<<std::endl;
    std::cout<<"Employee Id :"<<empId<<std::endl;
    std::cout<<"Name :"<<empName<<std::endl;
    for(int i=0;i<3;i++){
        std::cout<<"Month"<<i+1<<" :"<<increment[i]<<std::endl;
    }
    std::cout<<"Salary :"<<empSalary<<std::endl;
}

void Employee::accept()
{
    std::cout<<"Enter Employee Details\n";
    std::cout<<"Employee Id :";
    std::cin>>empId;
    std::cout<<"Name :";
    std::cin>>empName;
    std::cout<<"INCREMENTS"<<std::endl;
    for(int i=0;i<3;i++){
        std::cout<<"Month"<<i+1<<" :";
        std::cin>>increment[i];
    }
    std::cout<<"Salary :";
    std::cin>>empSalary;
}
