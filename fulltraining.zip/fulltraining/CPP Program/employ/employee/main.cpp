#include<iostream>
#include "emp.h"

int main(){
    // Employee e1,e2;
    // e1.accept();
    // e1.display();
    // e2.accept();
    // e2.display()
    
    Employee *e1;
    e1=new Employee[2];
    for(int i=0;i<2;i++)
    e1->accept();
    for(int i=0;i<2;i++)
    e1->display();
    delete []e1;

    return 0;
}