#include <iostream>
#include "Employee1.h"

/* returntype classname :: functionName(parameters)
{

}
*/

Employee1::Employee1()
{
    i++;
    std::cout<<"Employee "<<i<<": "<<std::endl;
    Accept();

    // empid = 101;
    // ename = "Ram";
    // salary = 30000;
    
}
Employee1::Employee1(int eid, std::string enm, double salary)
{
    empid = eid;
    ename = enm;
    salary = salary;
    
}
void Employee1::Accept()
{
    std::cout<<"Enter Employee Id: ";
    std::cin>>this->empid;
    std::cout<<"\nEnter Name: ";
    std::cin>>this->ename;
    std::cout<<"\nEnter Salary: ";
    std::cin>>this->salary;
    std::cout<<std::endl;


}
void Employee1::show()
{
    for(int i=0;i<5;i++)
    std::cout<<"Employee ID: "<<empid<<"\nName: "<<ename<<"\nSalary: "<<salary<<std::endl;
}
Employee1::~Employee1()
{
    
}

