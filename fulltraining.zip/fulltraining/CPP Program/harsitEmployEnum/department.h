#ifndef DEPARTMENT_H
#define DEPARTMENT_H

enum Department
{
    HR,
    ACCOUNT,
    IT,
    NA
};

#endif // DEPARTMENT_H
