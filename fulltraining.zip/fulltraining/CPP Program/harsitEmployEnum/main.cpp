#include<iostream>
#include "employee.h"
#include "department.h"


void CreateObjects()
{
    //Stack object

    Employee e1; //default constructor
    Employee e1("EMP101",20000.0f,Department::IT); //parameterized constructor
    Employee employeeArr[3]; //Array to store 3 employees on the stack

    //heap
    Employee* eptr1=new Employee(); //defalut constructor
    Employee* eptr2=new Employee("EM102",67000.0f,Department::HR); //parameterized constructor.
    Employee* eArr= new Employee[3]; //address of first allocation
}

int main()
{
    CreateObjects();

    return 0;
}