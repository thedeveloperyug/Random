 #include<iostream>
 #include "employee.h"

Employee::Employee()
{
    employeeId = "";
    employeeSalary = 0.0f;
    employeeDepartment = Department::NA;
}

float Employee::CalculateTax()
{
    employeeId =id;
    employeeSalary = salary;
    employeeDepartment = dept;
}
float Employee::operator+(const Employee &obj)
{

}
{
    return 0.0f;
}
{
    return 0.0f;
}

Employee::~Employee()
{
    std::cout<<"Destructor called"<<std::endl;
}

