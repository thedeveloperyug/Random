#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include<iostream>

#include "department.h"

class Employee
{
private:
    std::string employeeId;
    float employeeSalary;
    enum Department employeeDepartment;
public:
    Employee();
    Employee(std::string id,float salary, enum Department dept);

    ~Employee();

    float CalculateTax();

    float operator+(const Employee &obj);
};

#endif // EMPLOYEE_H
