#include<iostream>
using namespace std;

int main()
{
    int original,reverse =0, remainder,N=123321;
    original = N;

    while (original != 0)
    {
        remainder = original%10;
        reverse = reverse * 10 +remainder;
        original = original/10;
    }
    if(N == reverse)
    {
        cout<<"Number "<<N<<" is Palindrom\n";
    }
    else
    cout<<"Number "<<N<<" is not Palindrom\n";
    
}