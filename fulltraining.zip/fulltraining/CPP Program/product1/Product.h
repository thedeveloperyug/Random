#ifndef PRODUCT_H
#define PRODUCT_H

#include <iostream>

class Product
{
    std::string productName;
    int productId;
    int productPrice;

public:
    Product();
    
    void show();
};

#endif // PRODUCT_H
