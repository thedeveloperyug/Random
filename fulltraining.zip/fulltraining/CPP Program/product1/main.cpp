#include <iostream>
#include "Product.h"

int main()
{
    Product p1;
    p1.show();
    return 0;
}