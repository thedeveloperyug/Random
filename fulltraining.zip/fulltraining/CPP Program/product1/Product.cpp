#include<iostream>
#include "Product.h"

Product::Product()
{
    productName="Realme";
    productId=101;
    productPrice=20000;

}

void Product::show()
{
    std::cout<<productName<<" "<<productId<<" "<<productPrice<<std::endl;
}
