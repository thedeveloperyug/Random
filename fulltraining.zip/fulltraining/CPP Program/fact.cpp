#include<iostream>
using namespace std;

// int main()
// {
//     int N=0;
//     int fact=1;
//     if(N < 0)
//     {
//         std::cout<<"Number is Negetive\n";
//         return 0;
//     }
//     for(int i = 1;i<=N;++i)
//     {
//         fact = fact*i;
//     }
//     std::cout<<"Fact: "<<fact;
// }

int fact(int num)
{
    // if(num < 0)
    // {
    //     cout<<"Number is negetive\n";
    //     exit(1) ;
    // }
    // else
    if(num == 0 || num ==1)
    {
        return 1;
    }
    return num * fact(num-1);
}

int main()
{
    int ans = fact(10);

    cout<<"Fact: "<<ans;

    return 0;
}