#ifndef BOOK_H
#define BOOK_H

#include <iostream>

class Book
{
    std::string name;
    int price;
    std::string author;

public:
    Book();
    Book(std::string Bname,int Bprice,std::string Bauthor);
    void display();
};

#endif // BOOK_H
