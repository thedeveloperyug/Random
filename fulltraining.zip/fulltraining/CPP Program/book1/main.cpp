#include<iostream>
#include "Book.h"

int main()
{
    Book b1;
    b1.display();
    Book b2("Physics",200,"ssinha");
    b2.display();
}