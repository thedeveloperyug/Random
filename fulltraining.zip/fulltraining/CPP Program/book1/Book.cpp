#include<iostream>
#include "Book.h"


Book::Book()
{
    name="Math";
    price=400;
    author="Rsagarwal";
}
Book::Book(std::string Bname,int Bprice,std::string Bauthor)
{
    name=Bname;
    price=Bprice;
    author=Bauthor;
}
void Book::display()
{
    std::cout<<name<<" "<<price<<" "<<author<<std::endl;
}