#ifndef HEADER_H
#define HEADER_H

#include <iostream>

class Complex
{
    float real;
    float imag;

public:
    Complex();
    Complex(float, float);
    Complex(Complex &);
    void display();
    Complex operator+(Complex );
};

#endif // HEADER_H
