#include<iostream>
#include "header.h"

Complex::Complex()
{
    real=0;
    imag=0;
}
Complex::Complex(float real,float imag)
{
    this->real = real ;
    this->imag = imag;
}
// Copy constructor..
Complex::Complex(Complex &c2)
{
    real=c2.real;
    imag=c2.imag;
    

}
void Complex::display()
{
    std::cout<<"\nReal= "<<real<<std::endl<<"Imaginary= "<<imag;
}
// Operator overloading..
Complex Complex::operator+(Complex b4)
{
    this->real=real+b4.real;
    this->imag=imag+b4.imag;

    return *this;

}