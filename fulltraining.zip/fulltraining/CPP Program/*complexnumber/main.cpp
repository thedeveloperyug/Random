#include<iostream>
#include "header.h"


int main()
{
    Complex c1,c3(4.5,6.1),c4(5.5,8.2);
    // c1=c3;
    // c1.display();
   
    c1=c3+c4;

    c1.display();

    return 0;
}